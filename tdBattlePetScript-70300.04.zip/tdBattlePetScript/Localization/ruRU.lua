
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript', 'ruRU')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["ADDON_NAME"] = "Скрипты боевых питомцев"
L["Auto"] = "Авто"
L["Beauty script"] = "Отформатировать скрипт"
L["Create script"] = "Создать скрипт"
L["Debugging script"] = "Отладка скрипта"
L["Edit script"] = "Редактировать скрипт"
L["Export"] = "Экспорт"
L["Font face"] = "Шрифт"
L["Font size"] = "Размер шрифта"
L["Found error"] = "Найдена ошибка"
L["Import"] = "Импорт"
L["New script"] = "Новый скрипт"
L["No script"] = "Нет скрипта"
L["OPTION_GENERAL_NOTES"] = "Общие настройки."
L["OPTION_SCRIPTEDITOR_NOTES"] = "Настройки редактора скриптов."
L["OPTION_SCRIPTSELECTOR_NOTES"] = "Настройки селекторов скриптов."
--[[Translation missing --]]
--[[ L["OPTION_SETTINGS_AUTO_SELECT_SCRIPT_BY_ORDER"] = ""--]] 
L["OPTION_SETTINGS_AUTO_SELECT_SCRIPT_ONLY_ONE"] = "Автоматически выбирать, когда есть только один скрипт"
L["OPTION_SETTINGS_AUTOBUTTON_HOTKEY"] = "Назначение автоматической кнопки"
L["OPTION_SETTINGS_HIDE_MINIMAP"] = "Скрыть иконку у мини-карты"
L["OPTION_SETTINGS_HIDE_MINIMAP_TOOLTIP"] = "Обнаружен аддон \"MinimapButtonBag\", для изменения настройки необходимо перезагрузить интерфейс, нужно ли продолжать?"
L["OPTION_SETTINGS_HIDE_SELECTOR_NO_SCRIPT"] = "Не показывать, если нет скриптов"
L["OPTION_SETTINGS_NO_WAIT_DELETE_SCRIPT"] = "Не ждать перед удалением"
L["OPTION_SETTINGS_TEST_BREAK"] = "Отладка: скрипт проверки тестового сценария"
L["Options"] = "Опции"
L["PLUGINBASE_NOTES"] = "Базовый селектор выбирает обе стороны."
L["PLUGINBASE_TEAM_ALLY"] = "Друг"
L["PLUGINBASE_TEAM_ENEMY"] = "Враг"
L["PLUGINBASE_TITLE"] = "Базовый"
L["PLUGINBASE_TOOLTIP_CREATE_SCRIPT"] = "Базовый: Создание сценария для текущей битвы"
L["Run"] = "Запуск"
L["Save success"] = "Сохранено"
L["Script"] = "Скрипт"
L["Script author"] = "Автор скрипта"
L["Script editor"] = "Редактор скрипта"
L["Script manager"] = "Менеджер скриптов"
L["Script name"] = "Имя скрипта"
L["Script notes"] = "Примечания к скрипту"
L["Script selector"] = "Селектор скриптов"
L["SCRIPT_EDITOR_DELETE_SCRIPT"] = "Вы действительно хотите |cffff0000удалить|r скрипт |cffffd000[%s - %s]|r ?"
L["SCRIPT_EDITOR_LABEL_TOGGLE_EXTRA"] = "Дополнительная информация"
L["SCRIPT_IMPORT_LABEL_COVER"] = "Сценарий уже существует, если вы продолжите - предыдущий сценарий будет перезаписан импортируемым скриптом."
L["SCRIPT_IMPORT_LABEL_EXTRA"] = "Продолжить с расширенной информацией"
L["SCRIPT_IMPORT_LABEL_GOON"] = "Продолжить с перезаписью"
L["SCRIPT_SELECTOR_LOST_TOOLTIP"] = "Разработчик селектора скриптов не назначил функцию `OnTooltipFormatting`"
L["SCRIPT_SELECTOR_NOT_MATCH"] = "Нет селектора скриптов для текущей битвы"
L["Select script"] = "Выбор скрипта"
L["TOGGLE_SCRIPT_MANAGER"] = "Отобразить менеджер скриптов"
L["TOGGLE_SCRIPT_SELECTOR"] = "Отобразить селектор скриптов"
L["TOOLTIP_CREATE_OR_DEBUG_SCRIPT"] = "Создание или отладка скрипта"

--[===[@debug@
--]]
--@end-debug@]===]
