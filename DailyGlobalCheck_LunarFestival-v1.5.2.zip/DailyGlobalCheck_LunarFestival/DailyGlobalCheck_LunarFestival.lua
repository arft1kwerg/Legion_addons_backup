-- Daily Global Check - Lunar Festival plugin
local addonName, addonTable = ...

local plugintitle = "Lunar Festival"
local pluginicon = "Interface\\Icons\\inv_misc_elvencoins"

local questsdata = {}

local list = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = {
				-- Page 1  -- eastern kingdoms
                {
				 {select(2, GetAchievementInfo(912)),8647,8683,8653,8652,8643,8651,8722,8714,8645,8636,8642,8675,8650,8716,8649,8688,8674},
				},
				-- Page 2  -- kalimdor
				{
				 {select(2, GetAchievementInfo(911)),8715,8719,8673,8726,8684,8679,8686,8685,8717,8724,8723,8654,8671,8725,8670,8720,8682,8721,8672,8681,8680},
				},
				-- Page 3  -- northrend
				{
				 {select(2, GetAchievementInfo(1396)),13026,13025,13018,13016,13019,13015,13030,13027,13031,13032,13028,13020,13012,13033,13024,13013,13014,13029},
				},
				-- Page 4  -- cataclysm
				{
				 {select(2, GetAchievementInfo(6006)),29734,29737,29740,29739,29735,29742,29736,29738,29741},
				},
				-- Page 5  -- dungeons and ally/horde
				{
				 {select(2, GetAchievementInfo(910)),8727,8619,8713,8644,8635,8676,13067,13021,13017,13023,13022,13065,13066},
				},
			 },
 }

local function showally()
 local faction = DailyGlobalCheck.player_faction and DailyGlobalCheck.player_faction or UnitFactionGroup("player")
 return faction == "Alliance"
end

local function showhorde()
 local faction = DailyGlobalCheck.player_faction and DailyGlobalCheck.player_faction or UnitFactionGroup("player")
 return faction == "Horde"
end

local function add_faction_orders()
 local o = list["Order"]

 if showally() then
  o[5][2] = {select(2, GetAchievementInfo(915)),8646,8866,8718} -- alliance
 elseif showhorde() then
  o[5][2] = {select(2, GetAchievementInfo(914)),8648,8678,8677} -- horde
 end
end

local function GenerateData()
 local achi = GetAchievementCriteriaInfo
 local q = questsdata
 local l = DailyGlobalCheck.LocalizeSection
 local Z = DailyGlobalCheck.Z
 
 local function addElder(questID, mapID, x, y, showfunc)
  q[questID] = {Z[mapID], l(q, questID, 2, "Elder-"..questID, "quest", questID), nil, nil, {mapID, x, y}, nil, 1, nil, showfunc}
 end
 
 -- q\[(.+)\] \= \{nil\, (.+)\{(.+)\}(.+)\}
 -- addElder\(\1\, \3\)
 
 -- Elders of the Alliance
 addElder(8646, 30 , 34.6, 50.4, showally) -- hammershout stormwind
 addElder(8866, 341, 29.6, 18  , showally) -- bronzebeard ironforge
 addElder(8718, 381, 39.6, 32.4, showally) -- bladeswift darnassus
 
 -- Elders of the Horde
 addElder(8648, 382, 66.6, 38  , showhorde) -- darkcore undercity
 addElder(8678, 362, 73  , 24  , showhorde) -- wheathoof thunder bluff
 addElder(8677, 321, 52.2, 59.8, showhorde) -- darkhorn orgrimmar

 -- Elders of Cataclysm
 addElder(29734, 640, 27.6, 69.2) -- deepforge deepholm
 addElder(29737, 700, 50.8, 70.4) -- firebeard twilight
 addElder(29740, 606, 62.6, 22.8) -- evershade hyjal
 addElder(29739, 606, 26.6, 62  ) -- windsong hyjal
 addElder(29735, 640, 49.6, 54.8) -- stonebrand deepholm
 addElder(29742, 720, 65.4, 18.6) -- menkhaf uldum
 addElder(29736, 700, 51.8, 33  ) -- darkfeather twilight
 addElder(29738, 613, 57.2, 86.2) -- moonlance vashj'ir
 addElder(29741, 720, 31.6, 63  ) -- sekhemi uldum

 -- Elders of Northrend
 addElder(13026, 501, 49  , 14  ) --bluewolf wintergrasp
 addElder(13025, 490, 80.4, 37  ) --lunaro grizzly hills
 addElder(13018, 493, 49.8, 63.6) --sandrene sholazar
 addElder(13016, 486, 33.8, 34.2) --northal borean tundra
 addElder(13019, 488, 48.8, 78  ) --thoim dragonblight
 addElder(13015, 495, 28.8, 73.6) --fargal storm peaks
 addElder(13030, 490, 64.2, 47  ) --whurain grizzly hills
 addElder(13027, 496, 58.8, 56  ) --tauros zul drak
 addElder(13031, 488, 35  , 48.4) --skywarden dragonblight
 addElder(13032, 495, 64.6, 51.2) --muraco storm peaks
 addElder(13028, 495, 41  , 84.6) --graymane storm peaks
 addElder(13020, 495, 31.2, 37.6) --stonebeard storm peaks
 addElder(13012, 486, 59  , 65.6) --sardis borean tundra
 addElder(13033, 495, 57.4, 43.6) --arp borean tundra
 addElder(13024, 493, 63.8, 49  ) --wanikaya sholazar
 addElder(13013, 490, 60.4, 27.6) --beldak grizzly hills
 addElder(13014, 488, 29.8, 55.8) --morthie dragonblight
 addElder(13029, 486, 42.8, 49.6) --pamuya borean tundra

 --Elders of Eastern Kingdoms
 addElder(8647, 19 , 54.3, 49.5)-- Bellowrage	Blasted Lands			
 addElder(8683, 29 , 53.6, 24.5)--Dawnstrider	Burning Steppes			
 addElder(8653, 27 , 53.9, 49.9)--  Goldwell		Dun Morogh				
 addElder(8652, 20 , 61.9, 53.9)--Graveborn		Tirisfal Glades			
 addElder(8643, 26 , 50.0, 48.0)--Highpeak		The Hinterlands			
 addElder(8651, 28 , 21.3, 79.1)--Ironband		Searing Gorge			
 addElder(8722, 22 , 63.5, 36.1)--Meadowrun		Western Plaguelands		
 addElder(8714, 22 , 69.2, 73.5)--Moonstrike	Western Plaguelands		
 addElder(8645, 21 , 45.0, 41.1)-- Obsidian		Silverpine Forest		
 addElder(8636, 29 , 70.1, 45.4)-- Rumblerock	Burning Steppes			
 addElder(8642, 35 , 33.0, 46.0)--Silvervein	Loch Modan				
 addElder(8675, 39 , 56.6, 47.0)--Skychaser		Westfall				
 addElder(8650, 23 , 75.0, 54.0)--Snowcrown		Eastern Plaguelands		
 addElder(8716, 37 , 71.0, 34.3)-- Starglade		Northern Stranglethorn	
 addElder(8649, 30 , 39.8, 63.7)--  Stormbrow		Elwynn Forest			
 addElder(8688, 23 , 35.6, 68.8)--Windrun		Eastern Plaguelands		
 addElder(8674, 673, 39.9, 72.5)-- Winterhoof	The Cape of Stranglethorn

 -- Elders of Kalimdor
 addElder(8715, 41 , 57.0, 53.0) --Elder Bladeleaf
 addElder(8719, 261, 53.0, 35.5)--Elder Bladesing		
 addElder(8673, 9  , 48.3, 53.4)  --Elder Bloodhoof		
 addElder(8726, 281, 53.2, 56.8)--Elder Brightspear		
 addElder(8684, 161, 51.3, 27.8)--Elder Dreamseer		
 addElder(8679, 121, 76.7, 37.9)--Elder Grimtotem		
 addElder(8686, 607, 41.5, 47.5)--Elder High Mountain
 addElder(8685, 121,   62, 31.0)--Elder Mistwalker		
 addElder(8717, 11 , 48.5, 59.3) --Elder Moonwarden	
 addElder(8724, 61 , 77.1, 75.6) --Elder Morningdew	
 addElder(8723, 182, 38.3, 52.9)--Elder Nightwind		
 addElder(8654, 261, 30.8, 13.3)--Elder Primestone		
 addElder(8671, 161, 37.2, 79.1)--Elder Ragetotem		
 addElder(8725, 43 , 35.6, 48.9) --Elder Riversong		
 addElder(8670, 4  , 53.2, 43.6)  --Elder Runetotem		
 addElder(8720, 181, 64.7, 79.3)--Elder Skygleam		
 addElder(8682, 61 , 46.4, 51.0) --Elder Skyseer			
 addElder(8721, 42 , 49.5, 19.0) --Elder Starweave		
 addElder(8672, 281, 60.1, 49.9)--Elder Stonespire		
 addElder(8681, 201, 50.4, 76.1)--Elder Thunderhorn	
 addElder(8680, 11 , 68.4, 70.0) --Elder Windtotem
 
 --Elders of Eastern Kingdoms (Dungeons)
 addElder(8727, 23, 27  , 12)--Farwhisper Stratholme					
 addElder(8619, 28, 35  , 86)--Morndeep Blackrock Depths				
 addElder(8713, 38, 69.5, 53)--Starsong Sunken Temple				
 addElder(8644, 28, 35  , 86)--Stonefort Lower Blackrock Spire
 
 -- Elders of Kalimdor (Dungeons)
 addElder(8635, 101, 30  , 62  )--Splitrock Maraudon		
 addElder(8676, 161, 39.6, 21.7)--Wildmane Zul'Farrak
 --Elders of Northrend (Dungeons)
 addElder(13067, 491, 58, 45)--Chogan'gada Utgarde Pinnacle	
 addElder(13021, 486, 28, 28)--Igasho The Nexus			  	
 addElder(13017, 491, 58, 49)--Jarten Utgarde Keep
 addElder(13023, 496, 28, 90)--Kilias Drak'Tharon Keep	  
 addElder(13022, 488, 27, 48)--Nurgen Azjol-Nerub			
 addElder(13065, 496, 81, 21)--Ohanzee Gundrak				
 addElder(13066, 495, 45, 14)--Yurauk Halls of Stone		
end

list.Initialize = add_faction_orders
list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)
