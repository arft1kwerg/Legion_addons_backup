﻿-- Daily Global Check - WoD Treasure Chests
-- Jadya EU-Well of Eternity
local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z

local playerfaction = UnitFactionGroup("player")
local plugintitle = "WoD Treasure Chests"
local pluginicon = "Interface\\Icons\\TRADE_ARCHAEOLOGY_CHESTOFTINYGLASSANIMALS"
local chests_icon = "Interface\\WorldMap\\TreasureChest_64"
local suff_resources = "|TInterface\\Icons\\inv_garrison_resource:16|t"

local questsdata = {}

local function isquestcompleted(questID)
 if questID == 36463 then -- Admiral Taylor's Coffer Key peeking at coffer's tracking quest
  return IsQuestFlaggedCompleted(36462)
 elseif questID == 36089 or questID == 36072 or questID == 35711 then -- Abu'gar follower quest (the objects' tracking quests are not working)
  return IsQuestFlaggedCompleted(36711)
 end
end

local function showally()
 return playerfaction == "Alliance"
end

local function showhorde()
 return playerfaction == "Horde"
end

local list = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = {
			  -- Frostfire Ridge
			   {{Z[941],34642,34647,34648,34641,33942,34931,34507,33500,32803,34520,33940,34521,33946,33948,33947,34967,34841,34476,36863,33017,33505,33501,33916,34473,33926,33502,34936,34937},},
			  -- Talador
			   {{Z[946],34182,34249,34256,34140,34257,34259,35162,34255,34239,34276,34251,34253,34254,34101,34252,34258,34235,34290,34238,34236,34233,34232,34263,34260,34248,34471,34250,34261},},
			  -- Shadowmoon Valley
			   {{Z[947],35280,34174,35279,33613,35677,33570,37254,36507,33037,33575,33572,33883,33564,35798,35581,33568,33567,33610,33384,33612,33566,33574,33565,33885,35289,33867,33540,33573,33046,33614,33866,33886,33569,33584,33891,35580,35603,35600,33869,35384,33041,35584,35919},},
			  -- Spires of Arak
			   {{Z[948],36398,36399,36395,36397,36400,36367,36453,36456,36365,36340,36410,36403,36406,36405,36407,36454,36450,36463,36462,36458,36451,36420,36402,36421,36243,36447,36364,36362,36445,36411,36446,36361,36247,36444,36246,36455,36798,36418,36366},},
              -- Gorgrond
               {{Z[949],36621,36625,34241,36604,34940,36654,36509,36631,36628,36605,36506,36610,36203,36596,36521,36634,36618,35056,36658,36651,36170,35709,36118,37249},},
			  -- Nagrand 1
               {{Z[950],35648,35646,35662,35616,35591,35577,35583,35954,36036,35692,35643,35951,35955,35765,35969,35597,36050,35953,36077,35986,35660,36857,35661,35622,36089,36072,35711,35976,35682,35678,35593,36073,35695,35673},},
			  -- Nagrand 2
			   {{Z[950],36074,36051,36049,36099,36102,36035,35590,35576,35987,35999,36008,36002,36011,37435,36846,34760,36020,35579,36115,36021,35694,36082,36116,36046,35759,36039,36174,36109,35696,36071,36088},},
			  -- Tanaan Jungle
			   {{Z[945],38809,38814,38657,38601,38760,38761,38762,38758,38701,38788,38602,38771,38639,38320,38732,38735,38741,38754,38731,38638,38629,38757,38755,38208,37956,38686,38679,38640,38591,38593,38678,38776,38426,38704,38779,39470,39469,38773,38821,38822,39075,38703,38283,38739,38705,38740,38863,38702,38742,38682,38334,38683},
			   },
			  },
 }
 
local function GenerateData()
 local q = questsdata
 
 local ffr = Z[941]
 local tal = Z[946]
 local smv = Z[947]
 local soa = Z[948]
 local gor = Z[949]
 local nag = Z[950]
 local tj  = Z[945]

-------- Frostfire Ridge ---------
 q[34642] = {ffr,"Lucky Coin"                       ,nil,nil,{941, 19.2, 12  },nil,1,chests_icon}
 q[34647] = {ffr,"Snow-Covered Strongbox"           ,nil,nil,{941, 24  , 13  },nil,1,chests_icon}
 q[34648] = {ffr,"Gnawed Bone"                      ,nil,nil,{941, 25.5, 20.5},nil,1,chests_icon}
 q[34641] = {ffr,"Sealed Jug"                       ,nil,nil,{941, 9.8 , 45.4},nil,1,chests_icon}
 q[33942] = {ffr,"Supply Dump"                      ,nil,nil,{941, 16.1, 49.8},nil,1,chests_icon}
 q[34931] = {ffr,"Pale Loot Sack"                   ,nil,nil,{941, 21.6, 50.7},nil,1,chests_icon}
 q[34507] = {ffr,"Frozen Frostwolf Axe"             ,nil,nil,{941, 24.2, 48.6},nil,1,chests_icon}
 q[33500] = {ffr,"Slave's Stash"                    ,nil,nil,{941, 27.6, 42.8},nil,1,chests_icon}
 q[32803] = {ffr,"Thunderlord Cache"                ,nil,nil,{941, 34.3, 23.4},nil,1,chests_icon}
 q[34520] = {ffr,"Burning Pearl"                    ,nil,nil,{941, 42.4, 19.7},nil,1,chests_icon}
 q[33940] = {ffr,"Crag-Leaper's Cache"              ,nil,nil,{941, 42.7, 31.7},nil,1,chests_icon}
 q[34521] = {ffr,"Glowing Obsidian Shard"           ,nil,nil,{941, 51  , 22.8},nil,1,chests_icon}
 q[33946] = {ffr,"Survivalist's Cache"              ,nil,nil,{941, 64.7, 25.7},nil,1,chests_icon}
 q[33948] = {ffr,"Goren Leftovers"                  ,nil,nil,{941, 66.8, 26.5},nil,1,chests_icon}
 q[33947] = {ffr,"Grimfrost Treasure"               ,nil,nil,{941, 68.2, 45.8},nil,1,chests_icon}
 q[34967] = {ffr,"Raided Loot"                      ,nil,nil,{941, 37.2, 59.2},nil,1,chests_icon}
 q[34841] = {ffr,"Forgotten Supplies"               ,nil,nil,{941, 43.7, 55.5},nil,1,chests_icon}
 q[34476] = {ffr,"Frozen Orc Skeleton"              ,nil,nil,{941, 57.1, 52.1},nil,1,chests_icon}
 q[36863] = {ffr,"Iron Horde Munitions"             ,nil,nil,{941, 56.7, 71.8},nil,1,chests_icon}
 q[33017] = {ffr,"Iron Horde Supplies"              ,nil,nil,{941, 69  , 69.1},nil,1,chests_icon}
 q[33505] = {ffr,"Wiggling Egg"                     ,nil,nil,{941, 64.4, 65.8},nil,1,chests_icon}
 q[33501] = {ffr,"Spectator's Chest"                ,nil,nil,{941, 24.2, 27.2},nil,1,chests_icon}
 q[33916] = {ffr,"Arena Master's War Horn"          ,nil,nil,{941, 23.1, 25  },nil,1,chests_icon}
 q[34473] = {ffr,"Envoy's Satchel"                  ,nil,nil,{941, 40.9, 20.1},nil,1,chests_icon}
 q[33926] = {ffr,"Lagoon Pool"                      ,nil,nil,{941, 21.9, 9.6 },nil,1,chests_icon}
 q[33502] = {ffr,"Obsidian Petroglyph"              ,nil,nil,{941, 38.4, 37.8},nil,1,chests_icon}
 q[34936] = {ffr,"Lady Sena's Materials Stash"      ,nil,nil,{941, 47.2, 67.6},nil,1,chests_icon, showhorde}
 q[34937] = {ffr,"Lady Sena's Other Materials Stash",nil,nil,{941, 51.5, 66.8},nil,1,chests_icon, showhorde}
 --[0] = {ffr,"Thunderlord Long Spear","","",{[941] = {34.2,23.5}},941,1,chests_icon},
 -- [0] = {ffr,"Young Orc Woman","","",{[941] = {63.4,14.8}},941,1,chests_icon},
 
  -------- Talador ---------
 q[34182] = {tal,"Aarko's Family Treasure",nil,nil,{946, 36.5, 96.1},nil,1,chests_icon}
 q[34249] = {tal,"Farmer's Bounty"        ,nil,nil,{946, 35.5, 96.6},nil,1,chests_icon}
 q[34256] = {tal,"Relic of Telmor"        ,nil,nil,{946, 47  , 91.7},nil,1,chests_icon}
 q[34140] = {tal,"Yuuri's Gift"           ,nil,nil,{946, 40.7, 89.5},nil,1,chests_icon}
 q[34257] = {tal,"Treasure of Ango'rosh"  ,nil,nil,{946, 38.4, 84.5},nil,1,chests_icon}
 q[34259] = {tal,"Bonechewer Remnants"    ,nil,nil,{946, 33.3, 76.8},nil,1,chests_icon}
 q[35162] = {tal,"Teroclaw Nest"          ,nil,nil,{946, 71  , 32  },nil,1,chests_icon}
 q[34255] = {tal,"Webbed Sac"             ,nil,nil,{946, 65.5, 88.6},nil,1,chests_icon}
 q[34239] = {tal,"Curious Deathweb Egg"   ,nil,nil,{946, 66.6, 86.9},nil,1,chests_icon}
 q[34276] = {tal,"Rusted Lockbox"         ,nil,nil,{946, 66  , 85.1},nil,1,chests_icon}
 q[34251] = {tal,"Iron Box"               ,nil,nil,{946, 64.6, 79.2},nil,1,chests_icon}
 q[34253] = {tal,"Draenei Weapons"        ,nil,nil,{946, 55.2, 66.8},nil,1,chests_icon}
 q[34254] = {tal,"Soulbinder's Reliquary" ,nil,nil,{946, 39.5, 55.2},nil,1,chests_icon}
 q[34101] = {tal,"Lightbearer"            ,nil,nil,{946, 68.8, 56.1},nil,1,chests_icon}
 q[34252] = {tal,"Barrel of Fish"         ,nil,nil,{946, 62.4, 48  },nil,1,chests_icon}
 q[34258] = {tal,"Light of the Sea"       ,nil,nil,{946, 38.1, 12.4},nil,1,chests_icon}
 q[34235] = {tal,"Luminous Shell"         ,nil,nil,{946, 52.5, 29.5},nil,1,chests_icon}
 q[34290] = {tal,"Ketya's Stash"          ,nil,nil,{946, 54  , 27.6},nil,1,chests_icon}
 q[34238] = {tal,"Foreman's Lunchbox"     ,nil,nil,{946, 57.4, 28.7},nil,1,chests_icon}
 q[34236] = {tal,"Amethyl Crystal"        ,nil,nil,{946, 62.1, 32.5},nil,1,chests_icon}
 q[34233] = {tal,"Jug of Aged Ironwine"   ,nil,nil,{946, 65.5, 11.3},nil,1,chests_icon,nil,nil,"Cave at sea level"}
 q[34232] = {tal,"Rook's Tacklebox"       ,nil,nil,{946, 65  , 13.3},nil,1,chests_icon}
 q[34263] = {tal,"Pure Crystal Dust"      ,nil,nil,{946, 78.3, 14.4},nil,1,chests_icon}
 q[34260] = {tal,"Aruuna Mining Cart"     ,nil,nil,{946, 82  , 35  },nil,1,chests_icon}
 q[34248] = {tal,"Charred Sword"          ,nil,nil,{946, 77  , 50  },nil,1,chests_icon}
 q[34471] = {tal,"Bright Coin"            ,nil,nil,{946, 73.5, 51.4},nil,1,chests_icon}
 q[34250] = {tal,"Relic of Aruuna"        ,nil,nil,{946, 75.8, 44.7},nil,1,chests_icon}
 q[34261] = {tal,"Keluu's Belongings"     ,nil,nil,{946, 75.7, 41.4},nil,1,chests_icon}
 --[0] = {tal,"Bonechewer Spear","","",{[946] = {37.6,74.9}},946,1,chests_icon},
 
  -------- Shadowmoon Valley ---------
 q[35280] = {smv,"Stolen Treasure"              ,nil,nil,{947, 27.1, 2.6 },nil,1,chests_icon}
 q[34174] = {smv,"Fantastic Fish"               ,nil,nil,{947, 26.5, 5.7 },nil,1,chests_icon}
 q[35279] = {smv,"Sunken Treasure"              ,nil,nil,{947, 28.8, 7.1 },nil,1,chests_icon}
 q[33613] = {smv,"Bubbling Cauldron"            ,nil,nil,{947, 37.2, 23.1},nil,1,chests_icon}
 q[35677] = {smv,"Sunken Fishing boat"          ,nil,nil,{947, 37.2, 26.1},nil,1,chests_icon}
 q[33570] = {smv,"Shadowmoon Exile Treasure"    ,nil,nil,{947, 45.8, 24.6},nil,1,chests_icon}
 q[37254] = {smv,"Mushroom-Covered Chest"       ,nil,nil,{947, 52.9, 24.9},nil,1,chests_icon}
 q[36507] = {smv,"Orc Skeleton"                 ,nil,nil,{947, 67  , 33.5},nil,1,chests_icon}
 q[33037] = {smv,"False-Bottomed Jar"           ,nil,nil,{947, 51.8, 35.5},nil,1,chests_icon}
 q[33575] = {smv,"Demonic Cache"                ,nil,nil,{947, 20.3, 30.6},nil,1,chests_icon}
 q[33572] = {smv,"Rotting Basket"               ,nil,nil,{947, 22.8, 33.9},nil,1,chests_icon}
 q[33883] = {smv,"Shadowmoon Treasure"          ,nil,nil,{947, 28.3, 39.3},nil,1,chests_icon}
 q[33564] = {smv,"Hanging Satchel"              ,nil,nil,{947, 47.1, 46.1},nil,1,chests_icon}
 q[35798] = {smv,"Glowing Cave Mushroom"        ,nil,nil,{947, 48.7, 47.5},nil,1,chests_icon}
 q[35581] = {smv,"Alchemist's Satchel"          ,nil,nil,{947, 55  , 45  },nil,1,chests_icon}
 q[33568] = {smv,"Kaliri Egg"                   ,nil,nil,{947, 57.9, 45.3},nil,1,chests_icon}
 q[33567] = {smv,"Iron Horde Tribute"           ,nil,nil,{947, 37.5, 59.3},nil,1,chests_icon}
 q[33610] = {smv,"Peaceful Offering"            ,nil,nil,{947, 45.2, 60.5},nil,1,chests_icon}
 q[33384] = {smv,"Peaceful Offering"            ,nil,nil,{947, 44.3, 63.3},nil,1,chests_icon}
 q[33612] = {smv,"Peaceful Offering"            ,nil,nil,{947, 44.5, 59.2},nil,1,chests_icon}
 q[33566] = {smv,"Waterlogged Chest"            ,nil,nil,{947, 39.2, 83.8},nil,1,chests_icon}
 q[33574] = {smv,"Vindicator's Cache"           ,nil,nil,{947, 51.1, 79.1},nil,1,chests_icon}
 q[33565] = {smv,"Scaly Rylak Egg"              ,nil,nil,{947, 67.1, 84.3},nil,1,chests_icon}
 q[33885] = {smv,"Cargo of the Raven Queen"     ,nil,nil,{947, 84.5, 44.7},nil,1,chests_icon}
 q[35289] = {smv,"Spark's Stolen Supplies"      ,nil,nil,{971, 51.7, 1   },nil,1,chests_icon,showally}--51.8,1.1 Lunarfall
 q[33867] = {smv,"Astrologer's Box"             ,nil,nil,{947, 49.3, 37.5},nil,1,chests_icon}
 q[33540] = {smv,"Uzko's Knickknacks"           ,nil,nil,{947, 35.9, 40.9},nil,1,chests_icon}
 q[33573] = {smv,"Rovo's Dagger"                ,nil,nil,{947, 36.7, 44.5},nil,1,chests_icon}
 q[33046] = {smv,"Beloved's Offering"           ,nil,nil,{947, 36.8, 41.4},nil,1,chests_icon}
 q[33614] = {smv,"Greka's Urn"                  ,nil,nil,{947, 38.5, 43  },nil,1,chests_icon}
 q[33866] = {smv,"Veema's Herb Bag"             ,nil,nil,{947, 34.2, 43.5},nil,1,chests_icon}
 q[33886] = {smv,"Ronokk's Belongings"          ,nil,nil,{947, 31.3, 39.1},nil,1,chests_icon}
 q[33569] = {smv,"Carved Drinking Horn"         ,nil,nil,{947, 33.5, 39.7},nil,1,chests_icon}
 q[33584] = {smv,"Ashes of A'kumbo"             ,nil,nil,{947, 37.7, 44.3},nil,1,chests_icon}
 q[33891] = {smv,"Giant Moonwillow Cone"        ,nil,nil,{947, 34.5, 46.2},nil,1,chests_icon}
 q[35580] = {smv,"Swamplighter Hive"            ,nil,nil,{947, 55.3, 74.8},nil,1,chests_icon}--Da confermare questID
 q[35603] = {smv,"Mikkal's Chest"               ,nil,nil,{947, 58.9, 22  },nil,1,chests_icon}
 q[35600] = {smv,"Strange Spore"                ,nil,nil,{947, 55.8, 19.9},nil,1,chests_icon,nil,nil,"On top of a Mushroom"}
 q[33869] = {smv,"Armored Elekk Tusk"           ,nil,nil,{947, 41.5, 27.9},nil,1,chests_icon}
 q[33041] = {smv,"Iron Horde Cargo Shipment"    ,nil,nil,{947, 41.7, 60.9},nil,1,chests_icon}
 q[35584] = {smv,"Ancestral Greataxe"           ,nil,nil,{947, 52.8, 48.3},nil,1,chests_icon}
 q[35919] = {smv,"Shadowmoon Sacrificial Dagger",nil,nil,{947, 30  , 45.3},nil,1,chests_icon}
-- Shadowmoon Clan Treasure 33571

  -------- Spires of Arak ---------
 q[36398] = {soa,"Elixir of Shadow Sight"       ,nil,nil,{948, 69.2, 43.3},nil,3,chests_icon}-- Weekly
 q[36399] = {soa,"Elixir of Shadow Sight"       ,nil,nil,{948, 48.9, 62.5},nil,3,chests_icon}-- Weekly
 q[36395] = {soa,"Elixir of Shadow Sight"       ,nil,nil,{948, 43.9, 15  },nil,3,chests_icon}-- Weekly
 q[36397] = {soa,"Elixir of Shadow Sight"       ,nil,nil,{948, 43.8, 24.7},nil,3,chests_icon}--Weekly
 q[36400] = {soa,"Elixir of Shadow Sight"       ,nil,nil,{948, 55.6, 22.1},nil,3,chests_icon}--Weekly
 q[36367] = {soa,"Campaign Contributions"       ,nil,nil,{948, 55.5, 90.8},nil,1,chests_icon}
 q[36453] = {soa,"Coinbender's Payment"         ,nil,nil,{948, 68.4, 89  },nil,1,chests_icon}
 q[36456] = {soa,"Shredder Parts"               ,nil,nil,{948, 60.9, 84.6},nil,1,chests_icon}
 q[36365] = {soa,"Spray-O-Matic 5000 XT"        ,nil,nil,{948, 59.7, 81.3},nil,1,chests_icon}
 q[36340] = {soa,"Ogron Plunder"                ,nil,nil,{948, 58.7, 60.4},nil,1,chests_icon}
 q[36410] = {soa,"Offering to the Raven Mother" ,nil,nil,{948, 61  , 63.9},nil,1,chests_icon}
 q[36403] = {soa,"Offering to the Raven Mother" ,nil,nil,{948, 53.3, 55.6},nil,1,chests_icon}
 q[36406] = {soa,"Offering to the Raven Mother" ,nil,nil,{948, 48.9, 54.7},nil,1,chests_icon}
 q[36405] = {soa,"Offering to the Raven Mother" ,nil,nil,{948, 48.3, 52.6},nil,1,chests_icon}
 q[36407] = {soa,"Offering to the Raven Mother" ,nil,nil,{948, 51.9, 64.4},nil,1,chests_icon} 
 q[36454] = {soa,"Mysterious Mushrooms"         ,nil,nil,{948, 63.6, 67.4},nil,1,chests_icon}
 q[36450] = {soa,"Sethekk Ritual Brew"          ,nil,nil,{948, 71.6, 48.5},nil,1,chests_icon}
 q[36463] = {soa,"An Old Key"                   ,nil,nil,{948, 37.7, 56.4},nil,1,chests_icon,nil,isquestcompleted,"Opens Admiral Taylor's Coffer"}
 q[36462] = {soa,"Admiral Taylor's Coffer"      ,nil,nil,{948, 36.2, 54.4},nil,1,chests_icon,nil,nil,"Needs An Old Key"}
 q[36458] = {soa,"Abandoned Mining Pick"        ,nil,nil,{948, 40.6, 55  },nil,1,chests_icon}
 q[36451] = {soa,"Garrison Workman's Hammer"    ,nil,nil,{948, 41.8, 50.5},nil,1,chests_icon}
 q[36420] = {soa,"Garrison Supplies"            ,nil,nil,{948, 37.2, 47.5},nil,1,chests_icon}
 q[36402] = {soa,"Orcish Signaling Horn"        ,nil,nil,{948, 36.3, 39.4},nil,1,chests_icon}
 q[36421] = {soa,"Sun-Touched Cache"            ,nil,nil,{948, 34.1, 27.5},nil,1,chests_icon}
 q[36243] = {soa,"Outcast's Belongings"         ,nil,nil,{948, 36.8, 17.2},nil,1,chests_icon}
 q[36447] = {soa,"Outcast's Belongings"         ,nil,nil,{948, 42.1, 21.7},nil,1,chests_icon}
 q[36364] = {soa,"Toxicfang Venom"              ,nil,nil,{948, 54.3, 32.5},nil,1,chests_icon}
 q[36362] = {soa,"Shattered Hand Cache"         ,nil,nil,{948, 56.2, 28.2},nil,1,chests_icon}
 q[36445] = {soa,"Assassin's Spear"             ,nil,nil,{948, 49.2, 37.3},nil,1,chests_icon}
 q[36411] = {soa,"Lost Ring"                    ,nil,nil,{948, 47.8, 36.1},nil,1,chests_icon}
 q[36446] = {soa,"Outcast's Pouch"              ,nil,nil,{948, 46.9, 34  },nil,1,chests_icon}
 q[36361] = {soa,"Shattered Hand Lockbox"       ,nil,nil,{948, 47.9, 30.7},nil,1,chests_icon}
 q[36247] = {soa,"Lost Herb Satchel"            ,nil,nil,{948, 50.7, 28.7},nil,1,chests_icon}
 q[36444] = {soa,"Iron Horde Explosives"        ,nil,nil,{948, 50.4, 25.8},nil,1,chests_icon}
 q[36246] = {soa,"Fractured Sunstone"           ,nil,nil,{948, 50.5, 22.1},nil,1,chests_icon}
 q[36455] = {soa,"Waterlogged Satchel"          ,nil,nil,{948, 66.5, 56.5},nil,1,chests_icon}
 q[36798] = {soa,"Rooby's Roo"                  ,nil,nil,{948, 37.3, 50.7},nil,1,chests_icon,nil,nil,"Buy food downstairs, feed dog"}
 q[36418] = {soa,"Ephial's Dark Grimoire"       ,nil,nil,{948, 36.4, 57.8},nil,1,chests_icon}
 q[36366] = {soa,"Sailor Zazzuk's 180-Proof Rum",nil,nil,{948, 59.2, 90.6},nil,1,chests_icon}
 
 --[0] = {soa,"Elixir of Shadow Sight","","",{[948] = {53.1,84.5}},948,1,chests_icon},--Weekly 36401
 --[0] = {soa,"Sailor Zazzuk's 180-Proof Rum","","",{[948] = {59.1,90.6}},948,1,chests_icon},
 
 -- 36381 Spires - Shrine Treasure 01 - Gift of Anzu
 -- 36386 Spires - Shrine Treasure 02 - Gift of Anzu	
 -- 36388 Spires - Shrine Treasure 03 - Gift of Anzu
 -- 36390 Spires - Shrine Treasure 05 - Gift of Anzu
 -- 36392 Spires - Shrine Treasure 06 - Gift of Anzu

 -------- Gorgrond ---------
 q[36621] = {gor,"Explorer Canister"           ,nil,nil,{949, 40.4, 76.6},nil,1,chests_icon} --
 q[36625] = {gor,"Discarded Pack"              ,nil,nil,{949, 42.4, 83.5},nil,1,chests_icon} --
 q[34241] = {gor,"Ockbar's Pack"               ,nil,nil,{949, 43.1, 92.9},nil,1,chests_icon} -- frostwolf reputation?
 q[36604] = {gor,"Stashed Emergency Rucksack"  ,nil,nil,{949, 48.1, 93.4},nil,1,chests_icon} --
 q[34940] = {gor,"Strange Looking Dagger"      ,nil,nil,{949, 53  , 80  },nil,1,chests_icon} --
 q[36654] = {gor,"Remains of Balik Orecrusher" ,nil,nil,{949, 53.1, 74.5},nil,1,chests_icon} --
 q[36509] = {gor,"Odd Skull"                   ,nil,nil,{949, 52.5, 66.9},nil,1,chests_icon} --
 q[36631] = {gor,"Sasha's Secret Stash"        ,nil,nil,{949, 39  , 68.1},nil,1,chests_icon} --
 q[36628] = {gor,"Vindicator's Hammer"         ,nil,nil,{949, 59.4, 63.7},nil,1,chests_icon} --
 q[36605] = {gor,"Remains of Balldir Deeprock" ,nil,nil,{949, 57.8, 56  },nil,1,chests_icon} --
 q[36506] = {gor,"Brokor's Sack"               ,nil,nil,{949, 41.7, 53  },nil,1,chests_icon} --
 q[36610] = {gor,"Suntouched Spear"            ,nil,nil,{949, 45.7, 49.7},nil,1,chests_icon} --
 q[36203] = {gor,"Warm Goren Egg"              ,nil,nil,{949, 48.9, 47.3},nil,1,chests_icon} --
 q[36596] = {gor,"Weapons Cache"               ,nil,nil,{949, 49.3, 43.6},nil,1,chests_icon} --
 q[36521] = {gor,"Petrified Rylak Egg"         ,nil,nil,{949, 46.2, 42.9},nil,1,chests_icon} --
 q[36634] = {gor,"Sniper's Crossbow"           ,nil,nil,{949, 45  , 42.6},nil,1,chests_icon} --
 q[36618] = {gor,"Iron Supply Chest"           ,nil,nil,{949, 43.7, 42.5},nil,1,chests_icon} --
 q[35056] = {gor,"Horned Skull"                ,nil,nil,{949, 42.6, 46.8},nil,1,chests_icon} --
 q[36658] = {gor,"Evermorn Supply Cache"       ,nil,nil,{949, 41.8, 78.1},nil,1,chests_icon} --
 q[36651] = {gor,"Harvestable Precious Crystal",nil,nil,{949, 46.1, 50  },nil,1,chests_icon} --
 q[36170] = {gor,"Femur of Improbability"      ,nil,nil,{949, 40  , 72.3},nil,1,chests_icon} -- frostwolf reputation?
 q[35709] = {gor,"Laughing Skull Cache"        ,nil,nil,{949, 44.2, 74.2},nil,1,chests_icon} --
 q[36118] = {gor,"Pile of Rubble"              ,nil,nil,{949, 44  , 70.6},nil,1,chests_icon} --
 q[37249] = {gor,"Strange Spore"               ,nil,nil,{949, 57  , 65.3},nil,1,chests_icon} --
 --[0] = {gor,"Sunken Treasure","","",{[949] = {71.9,66.6}},949,1,chests_icon}, --
 
 -------- Nagrand ---------
 q[35648] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 64.6, 17.6},nil,1,chests_icon} --
 q[35646] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 70.6, 18.6},nil,1,chests_icon} --
 q[35662] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 87.6, 20.3},nil,1,chests_icon} --
 q[35616] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 88.2, 42.6},nil,1,chests_icon} --
 q[35591] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 77.8, 51.9},nil,1,chests_icon} --
 q[35577] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 50.1, 82.2},nil,1,chests_icon} --
 q[35583] = {nag,"Steamwheedle Supplies"        ,nil,nil,{950, 52.7, 80.1},nil,1,chests_icon} --
 q[35954] = {nag,"Elemental Offering"           ,nil,nil,{950, 66.9, 19.5},nil,1,chests_icon} --
 q[36036] = {nag,"Elemental Shackles"           ,nil,nil,{950, 78.9, 15.5},nil,1,chests_icon} --
 q[35692] = {nag,"Freshwater Clam"              ,nil,nil,{950, 73.1, 21.6},nil,1,chests_icon} --
 q[35643] = {nag,"Mountain Climbers Pack"       ,nil,nil,{950, 70.5, 13.9},nil,1,chests_icon} --
 q[35951] = {nag,"A Pile of Dirt"               ,nil,nil,{950, 73  , 10.9},nil,1,chests_icon} --
 q[35955] = {nag,"Adventurer's Sack"            ,nil,nil,{950, 73.9, 14.1},nil,1,chests_icon} --
 q[35765] = {nag,"Adventurer's Pack"            ,nil,nil,{950, 82.3, 56.6},nil,1,chests_icon} --
 q[35969] = {nag,"Adventurer's Pack"            ,nil,nil,{950, 45.6, 52  },nil,1,chests_icon} --
 q[35597] = {nag,"Adventurer's Pack"            ,nil,nil,{950, 69.9, 52.4},nil,1,chests_icon} --
 q[36050] = {nag,"Adventurer's Pouch"           ,nil,nil,{950, 56.6, 72.9},nil,1,chests_icon} --
 q[35953] = {nag,"Adventurer's Staff"           ,nil,nil,{950, 81.5, 13  },nil,1,chests_icon} --
 q[36077] = {nag,"Adventurer's Mace"            ,nil,nil,{950, 75.8, 62  },nil,1,chests_icon} --
 q[35986] = {nag,"Bone-Carved Dagger"           ,nil,nil,{950, 77.3, 28.2},nil,1,chests_icon} --
 q[35660] = {nag,"Fungus-Covered Chest"         ,nil,nil,{950, 88.9, 18.2},nil,1,chests_icon} --
 q[36857] = {nag,"Smuggler's Cache"             ,nil,nil,{950, 89.1, 33.1},nil,1,chests_icon} --
 q[35661] = {nag,"Brilliant Dreampetal"         ,nil,nil,{950, 81.1, 37.2},nil,1,chests_icon} --
 q[35622] = {nag,"Hidden Stash"                 ,nil,nil,{950, 87.5, 45  },nil,1,chests_icon} --
 q[36089] = {nag,"Abu'gar's Missing Reel"       ,nil,nil,{950, 85.4, 38.7},nil,1,chests_icon,nil,isquestcompleted} --
 q[36072] = {nag,"Abu'gar's Favorite Lure"      ,nil,nil,{950, 38.4, 49.4},nil,1,chests_icon,nil,isquestcompleted} --
 q[35711] = {nag,"Abu'gar's Vitality"           ,nil,nil,{950, 65.9, 61.2},nil,1,chests_icon,nil,isquestcompleted} --
 q[35976] = {nag,"Warsong Supplies"             ,nil,nil,{950, 89.4, 65.8},nil,1,chests_icon} --
 q[35682] = {nag,"Warsong Spear"                ,nil,nil,{950, 76.1, 70  },nil,1,chests_icon} --
 q[35678] = {nag,"Warsong Lockbox"              ,nil,nil,{950, 73  , 70.4},nil,1,chests_icon} --
 q[35593] = {nag,"Warsong Spoils"               ,nil,nil,{950, 80.6, 60.6},nil,1,chests_icon} --
 q[36073] = {nag,"Warsong Helm"                 ,nil,nil,{950, 52.4, 44.4},nil,1,chests_icon} --
 q[35695] = {nag,"Warsong Cache"                ,nil,nil,{950, 51.7, 60.3},nil,1,chests_icon} --
 q[35673] = {nag,"Appropriated Warsong Supplies",nil,nil,{950, 73.1, 75.5},nil,1,chests_icon} --
 
 q[36074] = {nag,"Gambler's Purse"               ,nil,nil,{950, 75.4, 47.1},nil,1,chests_icon} --
 q[36051] = {nag,"Grizzlemaw's Bonepile"         ,nil,nil,{950, 87.1, 72.9},nil,1,chests_icon} --
 q[36049] = {nag,"Ogre Beads"                    ,nil,nil,{950, 81  , 79.8},nil,1,chests_icon} --
 q[36099] = {nag,"Important Exploration Supplies",nil,nil,{950, 75.3, 65.7},nil,1,chests_icon} --
 q[36102] = {nag,"Saberon Stash"                 ,nil,nil,{950, 75.2, 65  },nil,1,chests_icon} --
 q[36035] = {nag,"Polished Saberon Skull"        ,nil,nil,{950, 72.7, 61  },nil,1,chests_icon} --
 q[35590] = {nag,"Goblin Pack"                   ,nil,nil,{950, 73  , 62.2},nil,1,chests_icon} --
 q[35576] = {nag,"Goblin Pack"                   ,nil,nil,{950, 47.2, 74.3},nil,1,chests_icon} --
 q[35987] = {nag,"Genedar Debris"                ,nil,nil,{950, 43.3, 57.5},nil,1,chests_icon} --
 q[35999] = {nag,"Genedar Debris"                ,nil,nil,{950, 48  , 60.1},nil,1,chests_icon} --
 q[36008] = {nag,"Genedar Debris"                ,nil,nil,{950, 48.6, 72.7},nil,1,chests_icon} --
 q[36002] = {nag,"Genedar Debris"                ,nil,nil,{950, 44.6, 67.5},nil,1,chests_icon} --
 q[36011] = {nag,"Genedar Debris"                ,nil,nil,{950, 55.3, 68.2},nil,1,chests_icon} --
 q[37435] = {nag,"Spirit Coffer"                 ,nil,nil,{950, 40.4, 68.6},nil,1,chests_icon} --
 q[36846] = {nag,"Spirit's Gift"                 ,nil,nil,{950, 35.5, 57.2},nil,1,chests_icon} --
 q[34760] = {nag,"Treasure of Kull'krosh"        ,nil,nil,{950, 37.7, 70.6},nil,1,chests_icon} --
 q[36020] = {nag,"Fragment of Oshu'gun"          ,nil,nil,{950, 45.8, 66.3},nil,1,chests_icon} --
 q[35579] = {nag,"Void-Infused Crystal"          ,nil,nil,{950, 50  , 66.5},nil,1,chests_icon} --
 q[36115] = {nag,"Pale Elixir"                   ,nil,nil,{950, 57.8, 62.2},nil,1,chests_icon} --
 q[36021] = {nag,"Pokhar's Thirteenth Axe"       ,nil,nil,{950, 58.3, 59.4},nil,1,chests_icon} --
 q[35694] = {nag,"Golden Kaliri Egg"             ,nil,nil,{950, 58.2, 52.6},nil,1,chests_icon} --
 q[36082] = {nag,"Lost Pendant"                  ,nil,nil,{950, 61.8, 57.4},nil,1,chests_icon} --
 q[36116] = {nag,"Bag of Herbs"                  ,nil,nil,{950, 62.5, 67.1},nil,1,chests_icon} --
 q[36046] = {nag,"Telaar Defender Shield"        ,nil,nil,{950, 64.7, 65.8},nil,1,chests_icon} --
 q[35759] = {nag,"Abandoned Cargo"               ,nil,nil,{950, 67.6, 59.8},nil,1,chests_icon} --
 q[36039] = {nag,"Highmaul Sledge"               ,nil,nil,{950, 67.4, 49  },nil,1,chests_icon} --
 q[36174] = {nag,"Bounty of the Elements"        ,nil,nil,{950, 77.1, 16.6},nil,1,chests_icon} --
 q[36109] = {nag,"Goldtoe's Plunder"             ,nil,nil,{950, 38.3, 58.8},nil,1,chests_icon} --
 q[35696] = {nag,"Burning Blade Cache"           ,nil,nil,{950, 85.4, 53.4},nil,1,chests_icon} --
 q[36071] = {nag,"Watertight Bag"                ,nil,nil,{950, 64.7, 35.8},nil,1,chests_icon} --
 q[36088] = {nag,"Adventurer's Pouch"            ,nil,nil,{950, 56.6, 61.8},nil,1,chests_icon} --
 --[36052] = {nag,"Misplaced Artifacts","","",nil,nil,1}, --

 -------- Tanaan Jungle ---------
 q[38809] = {tj,"Bleeding Hollow Mushroom Stash"      ,nil,nil           ,{945, 49.9, 76.8},nil,1,chests_icon,nil,nil,"Cave entrance at 44.5 77.5"}
 q[38814] = {tj,"Looted Mystical Staff"               ,nil,nil           ,{945, 48.6, 75.1},nil,1,chests_icon,nil,nil,"Cave entrance at 44.5 77.5"}
 q[38657] = {tj,"Forgotten Champion's Blade"          ,nil,nil           ,{945, 41.6, 73.3},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127339:0:0:0:0:0:0:0:0:0:0:0:1:0|h[forgotten]|h"}
 q[38601] = {tj,"Blackfang Island Cache"              ,nil,suff_resources,{945, 61.2, 75.7},nil,1,chests_icon}
 q[38760] = {tj,"Stashed Iron Booty"                  ,nil,suff_resources,{945, 33.9, 78.1},nil,1,chests_icon}
 q[38761] = {tj,"Stashed Iron Booty"                  ,nil,suff_resources,{945, 35  , 77.3},nil,1,chests_icon}
 q[38762] = {tj,"Stashed Iron Booty"                  ,nil,suff_resources,{945, 34.4, 78.3},nil,1,chests_icon}
 q[38758] = {tj,"Ironbeard's Treasure"                ,nil,nil           ,{945, 35.9, 78.6},nil,1,chests_icon,nil,nil,"Jump puzzle start at 35.3 78.3"}
 q[38701] = {tj,"Strange Fruit"                       ,nil,nil           ,{945, 64.6, 42.1},nil,1,chests_icon,nil,nil,"Click loose soil at 64.7 42.9"}
 q[38788] = {tj,"Brazier of Awakening"                ,nil,nil           ,{945, 37.7, 80.7},nil,1,chests_icon}
 q[38602] = {tj,"Crystallized Fel Spike"              ,nil,nil           ,{945, 62  , 71  },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:128217:0:0:0:0:0:0:0:0:0:0:0:1:0|h[shard]|h"}
 q[38771] = {tj,"Book of Zyzzix"                      ,nil,nil           ,{945, 47  , 36  },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127347:0:0:0:0:0:0:0:0:0:0:0:1:0|h[tome]|h"}
 q[38639] = {tj,"The Perfect Blossom"                 ,nil,nil           ,{945, 40.8, 75.6},nil,1,chests_icon,nil,nil,nil,nil,"Loot Mysterious Fruit to take it"} -- item 127347
 q[38320] = {tj,"The Blade of Kra'nak"                ,nil,nil           ,{945, 19.3, 40.9},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127338:0:0:0:0:0:0:0:0:0:0:0:1:0|h[blade]|h"}
 q[38732] = {tj,"Jeweled Arakkoa Effigy"              ,nil,nil           ,{945, 31.4, 31.1},nil,1,chests_icon}
 q[38735] = {tj,"'Borrowed' Enchanted Spyglass"       ,nil,nil           ,{945, 25.3, 50.2},nil,1,chests_icon}
 q[38741] = {tj,"Looted Bleeding Hollow Treasure"     ,nil,nil           ,{945, 26.5, 63  },nil,1,chests_icon}
 q[38754] = {tj,"Axe of the Weeping Wolf"             ,nil,nil           ,{945, 15  , 54.4},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127325:0:0:0:0:0:0:0:0:0:0:0:1:0|h[axe]|h"}
 q[38731] = {tj,"Overgrown Relic"                     ,nil,nil           ,{945, 50.8, 65  },nil,1,chests_icon}
 q[38638] = {tj,"Snake Charmer's Flute"               ,nil,nil           ,{945, 40.6, 79.8},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127333:0:0:0:0:0:0:0:0:0:0:0:1:0|h[flute]|h"}
 q[38629] = {tj,"Polished Crystal"                    ,nil,nil           ,{945, 30.4, 72  },nil,1,chests_icon}
 q[38757] = {tj,"The Eye of Grannok"                  ,nil,nil           ,{945, 15.9, 59.4},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:128220:0:0:0:0:0:0:0:0:0:0:0:1:0|h[trinket]|h"}
 q[38755] = {tj,"Spoils of War"                       ,nil,nil           ,{945, 17.4, 56.9},nil,1,chests_icon} -- garrison resources
 q[38208] = {tj,"Weathered Axe"                       ,nil,nil           ,{945, 15.9, 49.8},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127324:0:0:0:0:0:0:0:0:0:0:0:1:0|h[axe]|h"}
 q[37956] = {tj,"Strange Sapphire"                    ,nil,nil           ,{945, 36.3, 43.4},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127397:0:0:0:0:0:0:0:0:0:0:0:1:0|h[sapphire]|h"}
 q[38686] = {tj,"Rune Etched Femur"                   ,nil,nil           ,{945, 51.7, 24.3},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127341:0:0:0:0:0:0:0:0:0:0:0:1:0|h[femur]|h"}
 q[38679] = {tj,"Jewel of the Fallen Star"            ,nil,nil           ,{945, 58.5, 25.2},nil,1,chests_icon}
 q[38640] = {tj,"Anti Removal Equipment"              ,nil,suff_resources,{945, 37.1, 46.3},nil,1,chests_icon}
 q[38591] = {tj,"Forgotten Sack"                      ,nil,nil           ,{945, 57  , 65.1},nil,1,chests_icon}
 q[38593] = {tj,"Lodged Hunting Spear"                ,nil,nil           ,{945, 54.8, 69.3},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127334:0:0:0:0:0:0:0:0:0:0:0:1:0|h[pole]|h"}
 q[38678] = {tj,"Bleeding Hollow Warchest"            ,nil,nil           ,{945, 22  , 47.8},nil,1,chests_icon}
 q[38776] = {tj,"Sacrificial Blade"                   ,nil,nil           ,{945, 46.8, 42.2},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127328:0:0:0:0:0:0:0:0:0:0:0:1:0|h[blade]|h"}
 q[38426] = {tj,"Tome of Secrets"                     ,nil,nil           ,{945, 32.4, 70.4},nil,1,chests_icon}
 q[38704] = {tj,"Forgotten Iron Horde Supplies"       ,nil,nil           ,{945, 69.7, 56  },nil,1,chests_icon}
 q[38779] = {tj,"Stashed Bleeding Hollow Chest"       ,nil,nil           ,{945, 73.6, 43.2},nil,1,chests_icon}
 q[39470] = {tj,"Dead Man's Chest"                    ,nil,suff_resources,{945, 55  , 90.7},nil,1,chests_icon}
 q[39469] = {tj,"Bejeweled Egg"                       ,nil,nil           ,{945, 65.9, 85  },nil,1,chests_icon}
 q[38773] = {tj,"Fel Drenched Satchel"                ,nil,nil           ,{945, 46.9, 44.4},nil,1,chests_icon}
 q[38821] = {tj,"The Commander's Shield"              ,nil,nil           ,{945, 43.2, 38.3},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127348:0:0:0:0:0:0:0:0:0:0:0:1:0|h[shield]|h"}
 q[38822] = {tj,"Dazzling Rod"                        ,nil,nil           ,{945, 42.9, 35.4},nil,1,chests_icon}
 q[39075] = {tj,"Fel-Tainted Apexis Formation"        ,nil,nil           ,{945, 51.6, 32.6},nil,1,chests_icon,nil,nil,nil,nil,"On cliff edge"}
 q[38703] = {tj,"Scout's Belongings"                  ,nil,nil           ,{945, 50  , 79.6},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:127354:0:0:0:0:0:0:0:0:0:0:0:1:0|h[scout]|h"}
 q[38283] = {tj,"Stolen Captain's Chest"              ,nil,nil           ,{945, 17  , 52.9},nil,1,chests_icon}
 q[38739] = {tj,"Mysterious Corrupted Obelisk"        ,nil,nil           ,{945, 46.3, 72.8},nil,1,chests_icon,nil,nil,nil,nil,"Cave entrance at 47.3 70.6@(Requires garrison campaign)"}
 q[38705] = {tj,"Crystallized Essence of the Elements",nil,nil           ,{945, 47.9, 70.4},nil,1,chests_icon}
 q[38740] = {tj,"Forgotten Shard of the Cipher"       ,nil,nil           ,{945, 63.4, 28.1},nil,1,chests_icon,nil,nil,nil,nil,"Cave entrance at 62 31@(Requires garrison campaign)"}
 q[38863] = {tj,"Partially Mined Apexis Crystal"      ,nil,nil           ,{945, 28.7, 34.1},nil,1,chests_icon}
 q[38702] = {tj,"Discarded Helm"                      ,nil,nil           ,{945, 49.8, 81.1},nil,1,chests_icon}
 q[38742] = {tj,"Skull of the Mad Chief"              ,nil,nil           ,{945, 34.4, 34.3},nil,1,chests_icon}
 q[38682] = {tj,"Censer of Torment"                   ,nil,nil           ,{945, 62.6, 20.6},nil,1,chests_icon}
 q[38334] = {tj,"Jewel of Hellfire"                   ,nil,nil           ,{945, 28.4, 23.1},nil,1,chests_icon}
 q[38683] = {tj,"Looted Bleeding Hollow Treasure"     ,nil,nil           ,{945, 26.7, 44.3},nil,1,chests_icon}
 --[38280] = {tj,"#Skragg's Buried Treasure","","",nil,nil,1,chests_icon},
end

list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)