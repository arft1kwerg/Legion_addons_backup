# BigWigs

## [v98.1-2-gd22f8fa](https://github.com/BigWigsMods/BigWigs/tree/d22f8fa78712cbb474304e3444c1c7c6cf3af14a) (2018-07-17)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v98.1...d22f8fa78712cbb474304e3444c1c7c6cf3af14a)

- Messages: Apply the font after setting it  
- parser: Handle passing CL to :GetOptions  
