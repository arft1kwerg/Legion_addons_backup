
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'koKR')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["LEVELING_FIELD"] = "평준화 대기열"
--[[Translation missing --]]
--[[ L["NO_TEAM_FOR_SCRIPT"] = ""--]] 
L["NOTES"] = "이 스크립트 선택기는 리매치(Rematch) 팀에 연결될 것입니다."
--[[Translation missing --]]
--[[ L["Team:"] = ""--]] 
L["TITLE"] = "리매치(Rematch)"
L["WRITE_SCRIPT"] = "스크립트 쓰기"

--[===[@debug@
--]]
--@end-debug@]===]
