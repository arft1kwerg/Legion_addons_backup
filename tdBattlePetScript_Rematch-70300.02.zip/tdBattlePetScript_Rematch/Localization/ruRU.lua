
local L = LibStub('AceLocale-3.0'):NewLocale('tdBattlePetScript_Rematch', 'ruRU')
if not L then return end

--[===[@debug@
--[[
--@end-debug@]===]
L["LEVELING_FIELD"] = "Слот для прокачивания"
--[[Translation missing --]]
--[[ L["NO_TEAM_FOR_SCRIPT"] = ""--]] 
L["NOTES"] = "Этот скрипт будет связан с командой Rematch."
--[[Translation missing --]]
--[[ L["Team:"] = ""--]] 
L["TITLE"] = "Rematch."
L["WRITE_SCRIPT"] = "Написать скрипт"

--[===[@debug@
--]]
--@end-debug@]===]
