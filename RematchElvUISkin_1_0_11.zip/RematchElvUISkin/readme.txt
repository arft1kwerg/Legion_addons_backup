This addon reskins the Rematch battle pet addon to better blend in with ElvUI.

It requires both Rematch and ElvUI to be installed and enabled and does not include any portion of either addon. If you don't already use both addons then this addon will have no effect.

Rematch can be found here http://www.wowinterface.com/downloads/info22190-Rematch.html.
ElvUI can be found here http://www.tukui.org/about.php?ui=elvui.

- There is nothing to configure or set up. Install this addon and if current versions of both Rematch and ElvUI are enabled, Rematch will be skinned to blend in better with ElvUI.
- If you later decide to go back to the original look, you can disable or uninstall this addon and Rematch will revert to its original look.
- Many large windows in ElvUI are semi-transparent. It's necessary that the background of Rematch in the journal remain opaque. So overall it may not fit perfectly with the rest of the ElvUI but it should be closer than without.
- I don't use ElvUI. If features get added to Rematch that don't get skinned please remind me!

If you have any questions, comments or bugs to report please leave a comment here. Thanks!

08/29/2017 version 1.0.11
- toc update for 7.3

07/13/2017 version 1.0.10
- Changed previous fix to more immediately skin Rematch upon initialization.

07/11/2017 version 1.0.9
- Attempted fix for error with Rematch 4.7.3.

05/18/2017 version 1.0.8
- Fix for need to hit an extra ESC on login (menus created to reskin were not hidden).

03/28/2017 version 1.0.7
- toc update for 7.2

10/30/216 version 1.0.6
- toc update for 7.1

07/16/2016 version 1.0.5
- toc update for 7.0

06/09/2016 version 1.0.4
- Support for new "titlebar" buttons (Close, Minimize/Maximize, Lock, etc) in Rematch 4.4.4

05/23/2016 version 1.0.3
- Journal background made more "Transparent".
- Update for Rematch 4.4.1.

04/17/2016 version 1.0.2
- Fix for lua error (line 462) when used alongside Rematch 4.3.4.

04/14/2016 version 1.0.1
- Partially reskinned pet card and ability card to better fit ElvUI but still retain original style.
- Reskinned title part of menu frames.
- Reskinned the Close and Maximize buttons in the "Minimal Minimized Window" view.
- Reskinned future CollectMe and PetTracker_Journal buttons in upcoming Rematch 4.3.4

04/13/2016 version 1.0.0
- Initial release
