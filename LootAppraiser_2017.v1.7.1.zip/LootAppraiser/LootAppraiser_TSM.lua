-- LootAppraiser_TSM.lua --
local LA = LibStub("AceAddon-3.0"):GetAddon("LootAppraiser")

-- Lua APIs
local tostring, pairs, ipairs, table, tonumber, select, time, math, floor, date, print, type, string, sort = 
	  tostring, pairs, ipairs, table, tonumber, select, time, math, floor, date, print, type, string, sort


local TSMAPI = _G.TSMAPI;

LA.TSM = LA.TSM or {}

--------------------------------
-- Wrapper for TSMAPI methods --
--------------------------------
function LA.TSM:isItemInGroup(itemID, group)
	local path = TSMAPI.Groups:GetPath("i:" .. tostring(itemID))
	return path == group
end


--[[-------------------------------------------------------------------------------------
-- this method encapsulate the spezial price source 'custom'
---------------------------------------------------------------------------------------]]
function LA.TSM:GetItemValue(itemID, priceSource)
	-- special handling for priceSource = 'Custom'
	if priceSource == "Custom" then
		LA:D("    price source (custom): " ..  LA.db.profile.pricesource.customPriceSource)
		return TSMAPI:GetCustomPriceValue(LA.db.profile.pricesource.customPriceSource, itemID)
	end

	-- TSM default price sources
	return TSMAPI:GetItemValue(itemID, priceSource)
end


function LA.TSM:GetItemID(itemString)
	return TSMAPI.Item:ToItemID(itemString, true)
end


function LA.TSM:FormatTextMoney(value) 
	local disabled -- ???
	return TSMAPI:MoneyToString(value, nil, true, true, disabled)
end


function LA.TSM:ParseCustomPrice(value) 
	LA:Print("ParseCustomPrice(value=" .. tostring(value) .. ")")
	return TSMAPI:ValidateCustomPrice(value)
end


function LA.TSM:GetPriceSources()
	return select(1, TSMAPI:GetPriceSources())
end


--[[-------------------------------------------------------------------------------------
-- returns a table with the filtered available price sources
---------------------------------------------------------------------------------------]]
function LA.TSM:GetAvailablePriceSources()
	local priceSources = {}
	local keys = {}

	-- filter
	local tsmPriceSources = LA.TSM:GetPriceSources()

	for k, v in pairs(tsmPriceSources) do
		if LA.PRICE_SOURCE[k] then
			table.insert(keys, k)
		end
	end

	-- add custom
	table.insert(keys, "Custom")
	sort(keys)

	for _,v in ipairs(keys) do
		priceSources[v] = LA.PRICE_SOURCE[v]
	end

	return priceSources
end