-- Daily Global Check - Hallow's End
-- Vildiesel EU-Well of Eternity

local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z

local questsdata = {}

local function isquestcompleted(questID)
 if questID == "ahune" then
  local _, _, completed = GetLFGDungeonRewardCapBarInfo(286)
  return completed == 1 and true or false
 end
end

local list = {
 ["Title"] = "Midsummer",
 ["Icon"]  = "Interface\\Icons\\INV_SummerFest_FireFlower",
 ["Version"] = 1004,
 ["Order"] = {
               { -- page 1
                {DAILY,"ahune","multipleor#11921_11926","multipleor#11924_11925"}
			   },
               { -- page 2
                {"Bonfires "..Z[1007],},
                {"Bonfires "..Z[962],},
			   },
               { -- page 3
                {"Bonfires "..Z[13],},
			   },
			   {-- page 4
			    {"Bonfires "..Z[14],},
			   },
			   {-- page 5
			    {BUG_CATEGORY4,"multipleor#9330_9324","multipleor#9331_9326","multipleor#9332_9325","multipleor#11933_11935"},
			    {"Bonfires "..Z[862],},
			    {"Bonfires "..EXPANSION_NAME3,},
			   },
			   {-- page 6
			    {"Bonfires "..Z[485],},
			    {"Bonfires "..Z[466],},
			   },
             },
 }

local function GenerateQuestsData()
 local l = DailyGlobalCheck.LocalizeSection

 questsdata["ahune"] = {"", select(8, GetAchievementInfo(263)), nil, nil, nil, nil, nil, nil, nil, isquestcompleted}
 questsdata["multipleor#11921_11926"] = {nil, l(questsdata, "multipleor#11921_11926", 2, "More Torch Tossing" , "quest", 11921)}
 questsdata["multipleor#11924_11925"] = {nil, l(questsdata, "multipleor#11924_11925", 2, "More Torch Catching", "quest", 11924)}
 
  -- capital cities
 questsdata["multipleor#9330_9324"]   = {nil, l(questsdata, "multipleor#9330_9324"  , 2, "Stormwind/Orgrimmar"    , "quest", faction == "Horde" and 9330 or 9324)  , nil,nil,nil,nil,1} -- sw / orgri
 questsdata["multipleor#9331_9326"]   = {nil, l(questsdata, "multipleor#9331_9326"  , 2, "Ironforge/Undercity"    , "quest", faction == "Horde" and 9331 or 9326)  , nil,nil,nil,nil,1} -- if / uc
 questsdata["multipleor#9332_9325"]   = {nil, l(questsdata, "multipleor#9332_9325"  , 2, "Darnassus/Thunder Bluff", "quest", faction == "Horde" and 9332 or 9325)  , nil,nil,nil,nil,1} -- darn / tb
 questsdata["multipleor#11933_11935"] = {nil, l(questsdata, "multipleor#11933_11935", 2, "Exodar/Silvermoon"      , "quest", faction == "Horde" and 11933 or 11935), nil,nil,nil,nil,1} -- ex / sm
 
 local p, g
 local function bonfire(a, h, z, x, y)
  local questID = h and ("multipleor#"..a.."_"..h) or a
  local t = list.Order[p][g]
  questsdata[questID] = {nil, Z[z], nil, nil, {z, x, y}, nil, 1}
  t[#t + 1] = questID
  return questsdata[questID]
 end

 -- Broken Isles
 p = 2
 g = 1
 bonfire(44574, nil, 1015, 48.25, 29.74) -- azsuna
 bonfire(44575, nil, 1018, 44.88, 57.93) -- val'sharah
 bonfire(44576, nil, 1024, 55.52, 84.45) -- highmountain
 bonfire(44577, nil, 1017, 32.49, 42.14) -- stormheim
 bonfire(44613, 44624, 1033, 23.01, 58.31) -- suramar A
 bonfire(44627, 44614, 1033, 30.31, 45.26) -- suramar H
 
 -- Draenor
 p = 2
 g = 2
 bonfire(44579, 44582, 947, 42.62, 35.99) -- shadowmoon
 bonfire(44583, 44580, 941, 72.68, 65.21) -- frostfire
 bonfire(44570, nil, 948, 48.01, 44.72) -- spires
 bonfire(44571, nil, 946, 43.45, 71.80) -- talador
 bonfire(44572, nil, 950, 80.54, 47.70) -- nagrand
 bonfire(44573, nil, 949, 43.91, 93.77) -- gorgrond

 -- Kalimdor
 p = 3
 g = 1
 
 bonfire(11824, 11753, 41 ,  54.7, 52.8) -- teldrassil(A)
 bonfire(11806, 11735, 464,  44.7, 52.5) -- azuremyst (A)
 bonfire(11809, 11738, 476,  55.9, 68.3) -- bloodmyst (A)
 bonfire(11811, 11740, 42 ,  48.9, 22.6) -- darkshore (A)
 bonfire(11834, 11763, 281,  61.4, 47.1) -- winterspring (A)
 bonfire(11803, 11839, 281,  58.1, 47.3) -- winterspring (H)
 bonfire(28919, 28923, 181,  60  , 53  ) -- azshara (H)
 bonfire(11805, 11734, 43 ,  86.8, 41.5) -- ashenvale (A)
 bonfire(11765, 11841, 43 ,  52  , 66.7) -- ashenvale (H)
 bonfire(28928, 28915, 81 ,  50  , 51  ) -- stonetalon (A)
 bonfire(11780, 11856, 81 ,  52.9, 62.3) -- stonetalon (H)
 bonfire(11769, 11845, 101,  26.2, 77.2) -- desolace (H)
 bonfire(11812, 11741, 101,  65.9, 16.9) -- desolace (A)
 bonfire(11783, 11859, 11 ,  49.8, 54.4) -- northern barrens (H)
 bonfire(28926, 28913, 607,  48.3, 72.4) -- southern barrens (A)
 bonfire(28914, 28927, 607,  40.7, 67.4) -- southern barrens (H)
 bonfire(11770, 11846, 4  ,  52  , 47.2) -- durotar(H)
 bonfire(11777, 11852, 9  ,  52  , 59.5) -- mulgore (H)
 bonfire(11815, 11744, 907,  62  , 40.4) -- dustwallow (A) mapID 141, 851, 906?
 bonfire(11771, 11847, 907,  33.3, 30.8) -- dustwallow (H) mapID 141, 851, 906?
 bonfire(11817, 11746, 121,  46.6, 43.7) -- feralas (A)
 bonfire(11773, 11849, 121,  72.4, 47.6) -- feralas (H)
 bonfire(11833, 11762, 161,  52.6, 30  ) -- tanaris (A)
 bonfire(11802, 11838, 161,  49.8, 28.1) -- tanaris (H)
 bonfire(11831, 11760, 261,  60.5, 33.1) -- silithus (A)
 bonfire(11800, 11836, 261,  50.8, 41.5) -- silithus (H)
 bonfire(28920, 28933, 201,  56  , 66  ) -- un'goro (H)
 bonfire(28932, 28921, 201,  60  , 63  ) -- un'goro (A)
 
 -- Eastern Kingdoms
 p = 4
 g = 1
 
 -- blasted lands
 local data = bonfire(28917, 28930, 992,  46  ,  14   ) -- blasted (H)
 local zidormi_desc = {icon="spells\\HOLY_RUNE_01", desc="Zidormi here"}
 data[5][5] = 992
 data[5][6] = 48.12
 data[5][7] = 7.3
 data[5][8] = zidormi_desc
 data[13] = "Speak to Zidormi to show old Blasted Lands"

 data = bonfire(11808, 11737, 992,  55.3,  15   ) -- blasted (A)
 data[5][5] = 992
 data[5][6] = 48.12
 data[5][7] = 7.3
 data[5][8] = zidormi_desc
 data[13] = "Speak to Zidormi to show old Blasted Lands"
 --

 bonfire(11822, 11751, 36 , 24.5, 53.8) -- redridge (A)
 bonfire(11580, 11584, 21 , 49.6, 38.5) -- silverpine (H)
 bonfire(11816, 11745, 30 , 43  , 63  ) -- elwynn (A)
 bonfire(11583, 11581, 39 , 45  , 62  ) -- westfall (A)
 bonfire(11814, 11743, 34 , 73.3, 54.8) -- duskwood (A)
 bonfire(11813, 11742, 27 , 53.7, 44.9) -- dun morogh (A)
 bonfire(11828, 11757, 40 , 13.3, 47.1) -- wetlands (A)
 bonfire(11820, 11749, 35 , 32  , 40  ) -- loch modan (A)
 bonfire(11768, 11844, 29 , 51.4, 29  ) -- burning (H)
 bonfire(11810, 11739, 29 , 68.5, 60.2) -- burning (A)
 bonfire(28922, 28910, 37 , 51.7, 63.3) -- stranglethorn north (A)
 bonfire(28911, 28924, 37 , 40.7, 51.8) -- stranglethorn north (H)
 bonfire(11832, 11761, 673, 51.8, 67.5) -- stranglethorn cape (A)
 bonfire(11801, 11837, 673, 50.5, 70.6) -- stranglethorn cape (H)
 bonfire(11764, 11840, 16 , 69.2, 42.9) -- arathi (H)
 bonfire(11804, 11732, 16 , 44.6, 46.2) -- arathi (A)
 bonfire(11776, 11853, 24 , 54.5, 49.8) -- hillsbrad (H)
 bonfire(11826, 11755, 26 , 14.5, 49.9) -- hinter (A)
 bonfire(11784, 11860, 26 , 76.6, 74.6) -- hinter (H)
 bonfire(28918, 28931, 22 , 29  , 57  ) -- western plague (H)
 bonfire(11827, 11756, 22 , 43.5, 82.6) -- western plague (A)
 bonfire(11772, 11848, 462, 46.3, 50.3) -- eversong (H)
 bonfire(11786, 11862, 20 , 57  , 52  ) -- tirisfal (H)
 bonfire(11774, 11850, 463, 47  , 25.8) -- ghost (H)
 
 bonfire(28925, 28912, 17 , 18.7, 55.8 ) -- badlands (A)
 bonfire(11766, 11842, 17 , 24  , 37.14) -- badlands (H)
 bonfire(11781, 11857, 38 , 76.6, 14.1 ) -- sorrows (H)
 bonfire(28929, 28916, 38 , 70.2, 14.5 ) -- sorrows (A)
 -- 
 
 p = 5
 g = 2
 
 -- pandaria
 bonfire(32510, 32503, 811, 79.6, 37.2) -- vale eternal (A)
 bonfire(32496, 32509, 811, 79.6, 37.2) -- vale eternal (H)
 bonfire(32497, nil  , 858, 56.1, 69.5) --dread
 bonfire(32499, nil  , 857, 74.0, 9.49) --kra
 bonfire(32500, nil  , 809, 71.1, 90.9) --kun
 bonfire(32498, nil  , 806, 47.2, 47.2) --jade
 bonfire(32501, nil  , 810, 71.5, 56.3) --townlong
 bonfire(32502, nil  , 807, 51.8, 51.4) --valley

 g = 3
 
 -- cataclysm
 bonfire(28950, 28947, 720, 53  , 32  ) -- uldum (A)
 bonfire(28948, 28949, 720, 53  , 34  ) -- uldum (H)
 bonfire(29036, nil  , 640, 49.4, 51.4) -- deepholm
 bonfire(29030, nil  , 606, 62.8, 22.6) -- hyjal
 bonfire(29031, nil  , 615, 49.4, 42  ) -- vash
 bonfire(28945, 28943, 770, 47  , 28  ) -- twilight (A)
 bonfire(28944, 28946, 770, 53  , 46  ) -- twilight (H)

 p = 6
 g = 1
  
 -- northrend
 bonfire(13485, 13440, 486,  55.2, 20.2) -- borean (A)
 bonfire(13441, 13493, 486,  51  , 11.8) -- borean (H)
 bonfire(13491, 13447, 510,  77.6, 75.2) -- crystal (A)
 bonfire(13457, 13499, 510,  80.3, 52.7) -- crystal (H)
 bonfire(13487, 13443, 488,  75  , 43.8) -- dragonb (A)
 bonfire(13451, 13495, 488,  38.5, 48.2) -- dragonb (H)
 bonfire(13488, 13444, 491,  57.7, 15.8) -- howling (A)
 bonfire(13453, 13496, 491,  48.4, 13.4) -- howling (H)
 bonfire(13489, 13445, 490,  34.1, 60.6) -- grizzly (A)
 bonfire(13454, 13497, 490,  19.1, 61.5) -- grizzly (H)
 bonfire(13486, 13442, 493,  47.8, 66.3) -- shola (A)
 bonfire(13450, 13494, 493,  47.3, 61.5) -- shola (H)
 bonfire(13490, 13446, 495,  41.4, 87  ) -- storm peaks (A)
 bonfire(13455, 13498, 495,  40.3, 85.6) -- storm peaks (H)
 bonfire(13492, 13449, 496,  40.5, 61  ) -- zul'drak (A)
 bonfire(13458, 13500, 496,  43.3, 71.4) -- zul'drak (H) 

 g = 2
 
 -- outlands
 bonfire(11807, 11736, 475,  41.7, 66  ) -- blade's (A)
 bonfire(11767, 11843, 475,  50.0, 59.0) -- blade's (H)
 bonfire(11818, 11747, 465,  62  , 58.3) -- hellfire (A)
 bonfire(11775, 11851, 465,  57.2, 41.8) -- hellfire (H)
 bonfire(11778, 11854, 477,  51.1, 34  ) -- nagrand (H) -- outlands
 bonfire(11821, 11750, 477,  49.7, 69.6) -- nagrand (A) -- outlands
 bonfire(11830, 11759, 479,  31.1, 62.3) -- netherstorm (A)
 bonfire(11799, 11835, 479,  32.3, 68.3) -- netherstorm (H)
 bonfire(11823, 11752, 473,  39.5, 54.4) -- shadowmoon (A) -- outlands
 bonfire(11779, 11855, 473,  33.4, 30.3) -- shadowmoon (H) -- outlands
 bonfire(11825, 11754, 478,  54.2, 55.6) -- terokkar (A)
 bonfire(11782, 11858, 478,  51.9, 43.2) -- terokkar (H)
 bonfire(11829, 11758, 467,  68.6, 52.1) -- zangar (A)
 bonfire(11787, 11863, 467,  35.5, 51.7) -- zangar (H)
 --
end

list.GenerateData = GenerateQuestsData
DailyGlobalCheck:LoadPlugin(list, questsdata)
