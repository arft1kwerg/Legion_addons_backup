# BigWigs [Burning Crusade]

## [v7.3.1-3-g068a765](https://github.com/BigWigsMods/BigWigs_BurningCrusade/tree/068a76559b79340734064825a746f5d2cdfce98e) (2018-07-17)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_BurningCrusade/compare/v7.3.1...068a76559b79340734064825a746f5d2cdfce98e)

- Update colors and sounds  
- Shahraz: Fix key  
- Update for UnitBuff/UnitDebuff  
