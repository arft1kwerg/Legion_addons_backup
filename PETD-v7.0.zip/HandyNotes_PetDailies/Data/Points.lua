local _, PetDailies = ...
PetDailies.Data = PetDailies.Data or {}

PetDailies.Data.ICON_QUESTIONMARK = 134400 -- inv_misc_questionmark
PetDailies.Data.ICON_COIN_COPPER = 133784 -- inv_misc_coin_02
PetDailies.Data.ICON_BAG = 133663 -- inv_misc_bag_cenarionherbbag

local coin = PetDailies.Data.ICON_COIN_COPPER
local bag = PetDailies.Data.ICON_BAG

-- questlog testing
-- clickhandler


---@class Objective
---@field criteriaID integer
---@field name string
---@field achID integer|nil
---@field questID integer|nil
---@field faction "horde"|"alliance"|"both"
---@field icon integer|nil

---@alias Coordinate Objective[] -- a list of objectives at a given coordinate

---@alias Point table<integer, Coordinate> -- A Point is a map of coordPacked → Coordinate

---@alias PointsTable table<integer, Point> -- The whole DB: mapID → Point

---@type PointsTable
PetDailies.Data.Points = {
[1] = {
  [43802880] = {
   { criteriaID = 21402, achID = 6602, faction = "horde" , name = "Zunta" },
   { criteriaID = 21402, achID = 7499, faction = "horde" , name = "Zunta" },
   { criteriaID = 23454, questID = 31818, icon = coin, faction = "horde" , name = "Zunta" }
 }},
[10] = {
  [38806820] = {
   { criteriaID = 36467, achID = 11765, questID = 45539, faction = "both" , name = "Muyani" },
   { criteriaID = 36467, achID = 14021, questID = 45539, faction = "both" , name = "Muyani" }
 },
  [58605300] = {
   { criteriaID = 21403, achID = 6602, faction = "horde" , name = "Dagra the Fierce" },
   { criteriaID = 21403, achID = 7499, faction = "horde" , name = "Dagra the Fierce" },
   { criteriaID = 23455, questID = 31819, icon = bag, faction = "horde" , name = "Dagra the Fierce" }
 }},
[23] = {
  [43201980] = {
   { criteriaID = 45479, achID = 13627, questID = 56492, faction = "both" , name = "Sean Wilkers" },
   { criteriaID = 45479, achID = 14021, questID = 56492, faction = "both" , name = "Sean Wilkers" }
 },
  [67005240] = {
   { criteriaID = 21599, achID = 6603, faction = "alliance" , name = "Deiza Plaguehorn" },
   { criteriaID = 21599, achID = 7499, faction = "alliance" , name = "Deiza Plaguehorn" },
   { criteriaID = 23448, questID = 31911, icon = coin, faction = "alliance" , name = "Deiza Plaguehorn" }
 }},
[26] = {
  [62805460] = {
   { criteriaID = 21598, achID = 6603, faction = "alliance" , name = "David Kosse" },
   { criteriaID = 21598, achID = 7499, faction = "alliance" , name = "David Kosse" },
   { criteriaID = 23447, questID = 31910, icon = coin, faction = "alliance" , name = "David Kosse" }
 }},
[27] = {
  [31407100] = {
   { criteriaID = 43580, achID = 13269, questID = 54186, faction = "both" , name = "Micro Zoox" },
   { criteriaID = 43580, achID = 14021, questID = 54186, faction = "both" , name = "Micro Zoox" }
 }},
[32] = {
  [33202340] = {
   { criteriaID = 46836, achID = 14020, questID = 58458, faction = "both" , name = "Burt Macklyn" },
   { criteriaID = 46836, achID = 14021, questID = 58458, faction = "both" , name = "Burt Macklyn" }
 },
  [35402780] = {
   { criteriaID = 21600, achID = 6603, faction = "alliance" , name = "Kortas Darkhammer" },
   { criteriaID = 21600, achID = 7499, faction = "alliance" , name = "Kortas Darkhammer" },
   { criteriaID = 23449, questID = 31912, icon = coin, faction = "alliance" , name = "Kortas Darkhammer" }
 }},
[36] = {
  [25604760] = {
   { criteriaID = 21603, achID = 6603, faction = "alliance" , name = "Durin Darkhammer" },
   { criteriaID = 21603, achID = 7499, faction = "alliance" , name = "Durin Darkhammer" },
   { criteriaID = 23451, questID = 31914, icon = coin, faction = "alliance" , name = "Durin Darkhammer" }
 }},
[37] = {
  [41608360] = {
   { criteriaID = 21396, achID = 6603, faction = "alliance" , name = "Julia Stevens" },
   { criteriaID = 21396, achID = 7499, faction = "alliance" , name = "Julia Stevens" },
   { criteriaID = 23418, questID = 31693, icon = coin, faction = "alliance" , name = "Julia Stevens" }
 }},
[42] = {
  [40207640] = {
   { criteriaID = 21602, achID = 6603, faction = "both" , name = "Lydia Accoste" },
   { criteriaID = 21602, achID = 7499, faction = "both" , name = "Lydia Accoste" },
   { criteriaID = 23452, questID = 31916, icon = bag, faction = "both" , name = "Lydia Accoste" },
   { criteriaID = 23452, achID = 8348, questID = 31916, faction = "both" , name = "Lydia Accoste" },
   { criteriaID = 26988, achID = 9069, faction = "both" , name = "Lydia Accoste" }
 }},
[47] = {
  [19804480] = {
   { criteriaID = 21399, achID = 6603, faction = "alliance" , name = "Eric Davidson" },
   { criteriaID = 21399, achID = 7499, faction = "alliance" , name = "Eric Davidson" },
   { criteriaID = 23444, questID = 31850, icon = coin, faction = "alliance" , name = "Eric Davidson" }
 }},
[49] = {
  [33205260] = {
   { criteriaID = 21398, achID = 6603, faction = "alliance" , name = "Lindsay" },
   { criteriaID = 21398, achID = 7499, faction = "alliance" , name = "Lindsay" },
   { criteriaID = 23420, questID = 31781, icon = bag, faction = "alliance" , name = "Lindsay" }
 }},
[50] = {
  [46004040] = {
   { criteriaID = 21400, achID = 6603, faction = "alliance" , name = "Steven Lisbane" },
   { criteriaID = 21400, achID = 7499, faction = "alliance" , name = "Steven Lisbane" },
   { criteriaID = 23446, questID = 31852, icon = coin, faction = "alliance" , name = "Steven Lisbane" }
 }},
[51] = {
  [76604140] = {
   { criteriaID = 21601, achID = 6603, faction = "alliance" , name = "Everessa" },
   { criteriaID = 21601, achID = 7499, faction = "alliance" , name = "Everessa" },
   { criteriaID = 23450, questID = 31913, icon = coin, faction = "alliance" , name = "Everessa" }
 }},
[52] = {
  [41607120] = {
   { criteriaID = 36841, achID = 11856, questID = 46292, faction = "both" , name = "Marcus \"Bagman\" Brown" },
   { criteriaID = 36841, achID = 14021, questID = 46292, faction = "both" , name = "Marcus \"Bagman\" Brown" }
 },
  [60801860] = {
   { criteriaID = 21397, achID = 6603, faction = "alliance" , name = "Old MacDonald" },
   { criteriaID = 21397, achID = 7499, faction = "alliance" , name = "Old MacDonald" },
   { criteriaID = 23419, questID = 31780, icon = bag, faction = "alliance" , name = "Old MacDonald" }
 }},
[63] = {
  [20202960] = {
   { criteriaID = 21404, achID = 6602, faction = "horde" , name = "Analynn" },
   { criteriaID = 21404, achID = 7499, faction = "horde" , name = "Analynn" },
   { criteriaID = 23456, questID = 31854, icon = bag, faction = "horde" , name = "Analynn" }
 }},
[64] = {
  [31803280] = {
   { criteriaID = 21416, achID = 6602, faction = "horde" , name = "Kela Grimtotem" },
   { criteriaID = 21416, achID = 7499, faction = "horde" , name = "Kela Grimtotem" },
   { criteriaID = 23462, questID = 31906, icon = coin, faction = "horde" , name = "Kela Grimtotem" }
 }},
[65] = {
  [59607160] = {
   { criteriaID = 21405, achID = 6602, faction = "horde" , name = "Zonya the Sadist" },
   { criteriaID = 21405, achID = 7499, faction = "horde" , name = "Zonya the Sadist" },
   { criteriaID = 23457, questID = 31862, icon = coin, faction = "horde" , name = "Zonya the Sadist" }
 }},
[66] = {
  [57204580] = {
   { criteriaID = 21406, achID = 6602, faction = "horde" , name = "Merda Stronghoof" },
   { criteriaID = 21406, achID = 7499, faction = "horde" , name = "Merda Stronghoof" },
   { criteriaID = 23459, questID = 31872, icon = coin, faction = "horde" , name = "Merda Stronghoof" }
 }},
[69] = {
  [59604960] = {
   { criteriaID = 21407, achID = 6602, faction = "horde" , name = "Traitor Gluk" },
   { criteriaID = 21407, achID = 7499, faction = "horde" , name = "Traitor Gluk" },
   { criteriaID = 23458, questID = 31871, icon = coin, faction = "horde" , name = "Traitor Gluk" }
 }},
[70] = {
  [53807480] = {
   { criteriaID = 21410, achID = 6602, faction = "horde" , name = "Grazzle the Great" },
   { criteriaID = 21410, achID = 7499, faction = "horde" , name = "Grazzle the Great" },
   { criteriaID = 23461, questID = 31905, icon = coin, faction = "horde" , name = "Grazzle the Great" }
 }},
[77] = {
  [40005660] = {
   { criteriaID = 21411, achID = 6602, faction = "horde" , name = "Zoltan" },
   { criteriaID = 21411, achID = 7499, faction = "horde" , name = "Zoltan" },
   { criteriaID = 23463, questID = 31907, icon = coin, faction = "horde" , name = "Zoltan" }
 }},
[80] = {
  [46006040] = {
   { criteriaID = 21408, achID = 6602, faction = "horde" , name = "Elena Flutterfly" },
   { criteriaID = 21408, achID = 7499, faction = "horde" , name = "Elena Flutterfly" },
   { criteriaID = 23466, questID = 31908, icon = coin, faction = "horde" , name = "Elena Flutterfly" }
 }},
[83] = {
  [65606440] = {
   { criteriaID = 21415, achID = 6602, faction = "both" , name = "Stone Cold Trixxy" },
   { criteriaID = 21415, achID = 7499, faction = "both" , name = "Stone Cold Trixxy" },
   { criteriaID = 23453, questID = 31909, icon = bag, faction = "both" , name = "Stone Cold Trixxy" },
   { criteriaID = 23453, achID = 8348, questID = 31909, faction = "both" , name = "Stone Cold Trixxy" },
   { criteriaID = 27000, achID = 9069, faction = "both" , name = "Stone Cold Trixxy" }
 }},
[100] = {
  [64404920] = {
   { criteriaID = 21604, achID = 6604, faction = "both" , name = "Nicki Tinytech" },
   { criteriaID = 21604, achID = 6607, faction = "both" , name = "Nicki Tinytech" },
   { criteriaID = 21604, achID = 7499, faction = "both" , name = "Nicki Tinytech" },
   { criteriaID = 23473, questID = 31922, icon = coin, faction = "both" , name = "Nicki Tinytech" },
   { criteriaID = 23473, achID = 8348, questID = 31922, faction = "both" , name = "Nicki Tinytech" },
   { criteriaID = 26994, achID = 9069, faction = "both" , name = "Nicki Tinytech" }
 }},
[102] = {
  [17205040] = {
   { criteriaID = 21605, achID = 6604, faction = "both" , name = "Ras'an" },
   { criteriaID = 21605, achID = 6607, faction = "both" , name = "Ras'an" },
   { criteriaID = 21605, achID = 7499, faction = "both" , name = "Ras'an" },
   { criteriaID = 23469, questID = 31923, icon = coin, faction = "both" , name = "Ras'an" },
   { criteriaID = 23469, achID = 8348, questID = 31923, faction = "both" , name = "Ras'an" },
   { criteriaID = 26997, achID = 9069, faction = "both" , name = "Ras'an" }
 }},
[107] = {
  [30004140] = {
   { criteriaID = 21608, achID = 7499, faction = "both" , name = "Bloodknight Antari" },
   { criteriaID = 21847, achID = 6604, faction = "both" , name = "Bloodknight Antari" },
   { criteriaID = 21847, achID = 6607, faction = "both" , name = "Bloodknight Antari" },
   { criteriaID = 23475, questID = 31926, icon = bag, faction = "both" , name = "Bloodknight Antari" },
   { criteriaID = 23475, achID = 8348, questID = 31926, faction = "both" , name = "Bloodknight Antari" },
   { criteriaID = 27471, achID = 9069, faction = "both" , name = "Bloodknight Antari" }
 },
  [61004940] = {
   { criteriaID = 21606, achID = 6604, faction = "both" , name = "Narrok" },
   { criteriaID = 21606, achID = 6607, faction = "both" , name = "Narrok" },
   { criteriaID = 21606, achID = 7499, faction = "both" , name = "Narrok" },
   { criteriaID = 23472, questID = 31924, icon = coin, faction = "both" , name = "Narrok" },
   { criteriaID = 23472, achID = 8348, questID = 31924, faction = "both" , name = "Narrok" },
   { criteriaID = 26992, achID = 9069, faction = "both" , name = "Narrok" }
 }},
[111] = {
  [59007000] = {
   { criteriaID = 21607, achID = 6604, faction = "both" , name = "Morulu The Elder" },
   { criteriaID = 21607, achID = 6607, faction = "both" , name = "Morulu The Elder" },
   { criteriaID = 21607, achID = 7499, faction = "both" , name = "Morulu The Elder" },
   { criteriaID = 23470, questID = 31925, icon = coin, faction = "both" , name = "Morulu The Elder" },
   { criteriaID = 23470, achID = 8348, questID = 31925, faction = "both" , name = "Morulu The Elder" },
   { criteriaID = 26991, achID = 9069, faction = "both" , name = "Morulu The Elder" }
 }},
[115] = {
  [59007700] = {
   { criteriaID = 21850, achID = 6605, faction = "both" , name = "Okrut Dragonwaste" },
   { criteriaID = 21850, achID = 6607, faction = "both" , name = "Okrut Dragonwaste" },
   { criteriaID = 21850, achID = 7499, faction = "both" , name = "Okrut Dragonwaste" },
   { criteriaID = 23479, questID = 31933, icon = coin, faction = "both" , name = "Okrut Dragonwaste" },
   { criteriaID = 23479, achID = 8348, questID = 31933, faction = "both" , name = "Okrut Dragonwaste" },
   { criteriaID = 26996, achID = 9069, faction = "both" , name = "Okrut Dragonwaste" }
 }},
[117] = {
  [28603380] = {
   { criteriaID = 21848, achID = 6605, faction = "both" , name = "Beegle Blastfuse" },
   { criteriaID = 21848, achID = 6607, faction = "both" , name = "Beegle Blastfuse" },
   { criteriaID = 21848, achID = 7499, faction = "both" , name = "Beegle Blastfuse" },
   { criteriaID = 23481, questID = 31931, icon = coin, faction = "both" , name = "Beegle Blastfuse" },
   { criteriaID = 23481, achID = 8348, questID = 31931, faction = "both" , name = "Beegle Blastfuse" },
   { criteriaID = 26970, achID = 9069, faction = "both" , name = "Beegle Blastfuse" }
 }},
[118] = {
  [77401960] = {
   { criteriaID = 21852, achID = 6605, faction = "both" , name = "Major Payne" },
   { criteriaID = 21852, achID = 6607, faction = "both" , name = "Major Payne" },
   { criteriaID = 21852, achID = 7499, faction = "both" , name = "Major Payne" },
   { criteriaID = 23482, questID = 31935, icon = bag, faction = "both" , name = "Major Payne" },
   { criteriaID = 23482, achID = 8348, questID = 31935, faction = "both" , name = "Major Payne" },
   { criteriaID = 26989, achID = 9069, faction = "both" , name = "Major Payne" }
 }},
[121] = {
  [13206680] = {
   { criteriaID = 21851, achID = 6605, faction = "both" , name = "Gutretch" },
   { criteriaID = 21851, achID = 6607, faction = "both" , name = "Gutretch" },
   { criteriaID = 21851, achID = 7499, faction = "both" , name = "Gutretch" },
   { criteriaID = 23478, questID = 31934, icon = coin, faction = "both" , name = "Gutretch" },
   { criteriaID = 23478, achID = 8348, questID = 31934, faction = "both" , name = "Gutretch" },
   { criteriaID = 26984, achID = 9069, faction = "both" , name = "Gutretch" }
 }},
[127] = {
  [50205900] = {
   { criteriaID = 21849, achID = 6605, faction = "both" , name = "Nearly Headless Jacob" },
   { criteriaID = 21849, achID = 6607, faction = "both" , name = "Nearly Headless Jacob" },
   { criteriaID = 21849, achID = 7499, faction = "both" , name = "Nearly Headless Jacob" },
   { criteriaID = 23480, questID = 31932, icon = coin, faction = "both" , name = "Nearly Headless Jacob" },
   { criteriaID = 23480, achID = 8348, questID = 31932, faction = "both" , name = "Nearly Headless Jacob" },
   { criteriaID = 26993, achID = 9069, faction = "both" , name = "Nearly Headless Jacob" }
 }},
[198] = {
  [61403280] = {
   { criteriaID = 21858, achID = 6607, faction = "both" , name = "Brok" },
   { criteriaID = 21858, achID = 7499, faction = "both" , name = "Brok" },
   { criteriaID = 21858, achID = 7525, faction = "both" , name = "Brok" },
   { criteriaID = 23483, questID = 31972, icon = coin, faction = "both" , name = "Brok" },
   { criteriaID = 23483, achID = 8348, questID = 31972, faction = "both" , name = "Brok" },
   { criteriaID = 26973, achID = 9069, faction = "both" , name = "Brok" }
 }},
[199] = {
  [39607920] = {
   { criteriaID = 21409, achID = 6602, faction = "horde" , name = "Cassandra Kaboom" },
   { criteriaID = 21409, achID = 7499, faction = "horde" , name = "Cassandra Kaboom" },
   { criteriaID = 23460, questID = 31904, icon = coin, faction = "horde" , name = "Cassandra Kaboom" }
 }},
[207] = {
  [49805700] = {
   { criteriaID = 21859, achID = 6607, faction = "both" , name = "Bordin Steadyfist" },
   { criteriaID = 21859, achID = 7499, faction = "both" , name = "Bordin Steadyfist" },
   { criteriaID = 21859, achID = 7525, faction = "both" , name = "Bordin Steadyfist" },
   { criteriaID = 23484, questID = 31973, icon = coin, faction = "both" , name = "Bordin Steadyfist" },
   { criteriaID = 23484, achID = 8348, questID = 31973, faction = "both" , name = "Bordin Steadyfist" },
   { criteriaID = 26972, achID = 9069, faction = "both" , name = "Bordin Steadyfist" }
 }},
[210] = {
  [51407320] = {
   { criteriaID = 21401, achID = 6603, faction = "alliance" , name = "Bill Buckler" },
   { criteriaID = 21401, achID = 7499, faction = "alliance" , name = "Bill Buckler" },
   { criteriaID = 23445, questID = 31851, icon = coin, faction = "alliance" , name = "Bill Buckler" }
 }},
[221] = {
  [61905970] = {
   { criteriaID = 45929, achID = 13766, faction = "both" , name = "Postmaster Malown" }
 }},
[241] = {
  [56605680] = {
   { criteriaID = 21860, achID = 6607, faction = "both" , name = "Goz Banefury" },
   { criteriaID = 21860, achID = 7499, faction = "both" , name = "Goz Banefury" },
   { criteriaID = 21860, achID = 7525, faction = "both" , name = "Goz Banefury" },
   { criteriaID = 23485, questID = 31974, icon = coin, faction = "both" , name = "Goz Banefury" },
   { criteriaID = 23485, achID = 8348, questID = 31974, faction = "both" , name = "Goz Banefury" },
   { criteriaID = 26983, achID = 9069, faction = "both" , name = "Goz Banefury" }
 }},
[249] = {
  [56604180] = {
   { criteriaID = 21861, achID = 6607, faction = "both" , name = "Obalis" },
   { criteriaID = 21861, achID = 7499, faction = "both" , name = "Obalis" },
   { criteriaID = 21861, achID = 7525, faction = "both" , name = "Obalis" },
   { criteriaID = 23486, questID = 31971, icon = bag, faction = "both" , name = "Obalis" },
   { criteriaID = 23486, achID = 8348, questID = 31971, faction = "both" , name = "Obalis" },
   { criteriaID = 26995, achID = 9069, faction = "both" , name = "Obalis" }
 }},
[371] = {
  [28803600] = {
   { criteriaID = 22482, achID = 7936, questID = 32428, faction = "both" , name = "Whispering Pandaren Spirit" },
   { criteriaID = 23497, questID = 32440, icon = bag, faction = "both" , name = "Whispering Pandaren Spirit" },
   { criteriaID = 23497, achID = 8348, questID = 32440, faction = "both" , name = "Whispering Pandaren Spirit" },
   { criteriaID = 27008, achID = 9069, faction = "both" , name = "Whispering Pandaren Spirit" }
 },
  [48005401] = {
   { criteriaID = 21853, achID = 6606, faction = "both" , name = "Hyuna of the Shrines" },
   { criteriaID = 21853, achID = 6607, faction = "both" , name = "Hyuna of the Shrines" },
   { criteriaID = 21853, achID = 7499, faction = "both" , name = "Hyuna of the Shrines" },
   { criteriaID = 23488, questID = 31953, icon = bag, faction = "both" , name = "Hyuna of the Shrines" },
   { criteriaID = 23488, achID = 8348, questID = 31953, faction = "both" , name = "Hyuna of the Shrines" },
   { criteriaID = 26985, achID = 9069, faction = "both" , name = "Hyuna of the Shrines" }
 },
  [48427096] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Ka'wi the Gorger" },
   { criteriaID = 23498, questID = 32604, icon = bag, faction = "both" , name = "Ka'wi the Gorger" },
   { criteriaID = 23498, achID = 8348, questID = 32604, faction = "both" , name = "Ka'wi the Gorger" }
 },
  [57042912] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Nitun" },
   { criteriaID = 23498, questID = 32604, icon = bag, faction = "both" , name = "Nitun" },
   { criteriaID = 23498, achID = 8348, questID = 32604, faction = "both" , name = "Nitun" }
 }},
[376] = {
  [25297854] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Greyhoof" },
   { criteriaID = 23499, questID = 32868, icon = bag, faction = "both" , name = "Greyhoof" },
   { criteriaID = 23499, achID = 8348, questID = 32868, faction = "both" , name = "Greyhoof" }
 },
  [40544367] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Lucky Yi" },
   { criteriaID = 23499, questID = 32868, icon = bag, faction = "both" , name = "Lucky Yi" },
   { criteriaID = 23499, achID = 8348, questID = 32868, faction = "both" , name = "Lucky Yi" }
 },
  [46004361] = {
   { criteriaID = 21854, achID = 6606, faction = "both" , name = "Farmer Nishi" },
   { criteriaID = 21854, achID = 6607, faction = "both" , name = "Farmer Nishi" },
   { criteriaID = 21854, achID = 7499, faction = "both" , name = "Farmer Nishi" },
   { criteriaID = 23490, questID = 31955, icon = bag, faction = "both" , name = "Farmer Nishi" },
   { criteriaID = 23490, achID = 8348, questID = 31955, faction = "both" , name = "Farmer Nishi" },
   { criteriaID = 26980, achID = 9069, faction = "both" , name = "Farmer Nishi" }
 }},
[379] = {
  [34605760] = {
   { criteriaID = 23615, achID = 8518, faction = "both" , name = "Chi-Chi, Hatchling of Chi-Ji" }
 },
  [35185617] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Kafi" },
   { criteriaID = 23498, questID = 32604, icon = bag, faction = "both" , name = "Kafi" },
   { criteriaID = 23498, achID = 8348, questID = 32604, faction = "both" , name = "Kafi" }
 },
  [35807360] = {
   { criteriaID = 21855, achID = 6606, faction = "both" , name = "Courageous Yon" },
   { criteriaID = 21855, achID = 6607, faction = "both" , name = "Courageous Yon" },
   { criteriaID = 21855, achID = 7499, faction = "both" , name = "Courageous Yon" },
   { criteriaID = 23491, questID = 31956, icon = bag, faction = "both" , name = "Courageous Yon" },
   { criteriaID = 23491, achID = 8348, questID = 31956, faction = "both" , name = "Courageous Yon" },
   { criteriaID = 26977, achID = 9069, faction = "both" , name = "Courageous Yon" }
 },
  [64809360] = {
   { criteriaID = 22482, achID = 7936, questID = 32428, faction = "both" , name = "Thundering Pandaren Spirit" },
   { criteriaID = 23496, questID = 32441, icon = bag, faction = "both" , name = "Thundering Pandaren Spirit" },
   { criteriaID = 23496, achID = 8348, questID = 32441, faction = "both" , name = "Thundering Pandaren Spirit" },
   { criteriaID = 27005, achID = 9069, faction = "both" , name = "Thundering Pandaren Spirit" }
 },
  [67878469] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Dos-Ryga" },
   { criteriaID = 23498, questID = 32604, icon = bag, faction = "both" , name = "Dos-Ryga" },
   { criteriaID = 23498, achID = 8348, questID = 32604, faction = "both" , name = "Dos-Ryga" }
 }},
[388] = {
  [11007101] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "No-No" },
   { criteriaID = 23500, questID = 32869, icon = bag, faction = "both" , name = "No-No" },
   { criteriaID = 23500, achID = 8348, questID = 32869, faction = "both" , name = "No-No" }
 },
  [36205221] = {
   { criteriaID = 21870, achID = 6606, faction = "both" , name = "Seeker Zusshi" },
   { criteriaID = 21870, achID = 6607, faction = "both" , name = "Seeker Zusshi" },
   { criteriaID = 22417, achID = 7499, faction = "both" , name = "Seeker Zusshi" },
   { criteriaID = 23487, questID = 31991, icon = bag, faction = "both" , name = "Seeker Zusshi" },
   { criteriaID = 23487, achID = 8348, questID = 31991, faction = "both" , name = "Seeker Zusshi" },
   { criteriaID = 26998, achID = 9069, faction = "both" , name = "Seeker Zusshi" }
 },
  [57004221] = {
   { criteriaID = 22482, achID = 7936, questID = 32428, faction = "both" , name = "Burning Pandaren Spirit" },
   { criteriaID = 23495, questID = 32434, icon = bag, faction = "both" , name = "Burning Pandaren Spirit" },
   { criteriaID = 23495, achID = 8348, questID = 32434, faction = "both" , name = "Burning Pandaren Spirit" },
   { criteriaID = 26974, achID = 9069, faction = "both" , name = "Burning Pandaren Spirit" }
 },
  [72267978] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Ti'un the Wanderer" },
   { criteriaID = 23500, questID = 32869, icon = bag, faction = "both" , name = "Ti'un the Wanderer" },
   { criteriaID = 23500, achID = 8348, questID = 32869, faction = "both" , name = "Ti'un the Wanderer" }
 }},
[390] = {
  [31207421] = {
   { criteriaID = 21857, achID = 6606, faction = "both" , name = "Aki the Chosen" },
   { criteriaID = 21857, achID = 6607, faction = "both" , name = "Aki the Chosen" },
   { criteriaID = 21857, achID = 7499, faction = "both" , name = "Aki the Chosen" },
   { criteriaID = 23493, questID = 31958, icon = bag, faction = "both" , name = "Aki the Chosen" },
   { criteriaID = 23493, achID = 8348, questID = 31958, faction = "both" , name = "Aki the Chosen" },
   { criteriaID = 25118, achID = 9069, faction = "both" , name = "Aki the Chosen" }
 }},
[407] = {
  [47206260] = {
   { criteriaID = 26986, achID = 9069, faction = "both" , name = "Jeremy Feasel" }
 },
  [47406221] = {
   { criteriaID = 26976, achID = 9069, faction = "both" , name = "Christoph VonFeasel" }
 }},
[418] = {
  [37133352] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Skitterer Xi'a" },
   { criteriaID = 23499, questID = 32868, icon = bag, faction = "both" , name = "Skitterer Xi'a" },
   { criteriaID = 23499, achID = 8348, questID = 32868, faction = "both" , name = "Skitterer Xi'a" }
 },
  [65094275] = {
   { criteriaID = 21871, achID = 6606, faction = "both" , name = "Mo'ruk" },
   { criteriaID = 21871, achID = 6607, faction = "both" , name = "Mo'ruk" },
   { criteriaID = 22418, achID = 7499, faction = "both" , name = "Mo'ruk" },
   { criteriaID = 23489, questID = 31954, icon = bag, faction = "both" , name = "Mo'ruk" },
   { criteriaID = 23489, achID = 8348, questID = 31954, faction = "both" , name = "Mo'ruk" },
   { criteriaID = 26990, achID = 9069, faction = "both" , name = "Mo'ruk" }
 }},
[422] = {
  [26185027] = {
   { criteriaID = 22737, achID = 8080, questID = 32603, faction = "both" , name = "Gorespine" },
   { criteriaID = 23500, questID = 32869, icon = bag, faction = "both" , name = "Gorespine" },
   { criteriaID = 23500, achID = 8348, questID = 32869, faction = "both" , name = "Gorespine" }
 },
  [55003741] = {
   { criteriaID = 21856, achID = 6606, faction = "both" , name = "Wastewalker Shu" },
   { criteriaID = 21856, achID = 6607, faction = "both" , name = "Wastewalker Shu" },
   { criteriaID = 21856, achID = 7499, faction = "both" , name = "Wastewalker Shu" },
   { criteriaID = 23492, questID = 31957, icon = bag, faction = "both" , name = "Wastewalker Shu" },
   { criteriaID = 23492, achID = 8348, questID = 31957, faction = "both" , name = "Wastewalker Shu" },
   { criteriaID = 27007, achID = 9069, faction = "both" , name = "Wastewalker Shu" }
 },
  [61208760] = {
   { criteriaID = 22482, achID = 7936, questID = 32428, faction = "both" , name = "Flowing Pandaren Spirit" },
   { criteriaID = 23494, questID = 32439, icon = bag, faction = "both" , name = "Flowing Pandaren Spirit" },
   { criteriaID = 23494, achID = 8348, questID = 32439, faction = "both" , name = "Flowing Pandaren Spirit" },
   { criteriaID = 26981, achID = 9069, faction = "both" , name = "Flowing Pandaren Spirit" }
 }},
[525] = {
  [68606460] = {
   { criteriaID = 26982, achID = 9069, faction = "both" , name = "Gargra" },
   { criteriaID = 27013, achID = 9724, faction = "both" , name = "Gargra" }
 }},
[534] = {
  [15744444] = {
   { criteriaID = 28805, achID = 10052, questID = 39168, faction = "both" , name = "Bleakclaw" }
 },
  [25047621] = {
   { criteriaID = 28798, achID = 10052, questID = 39161, faction = "both" , name = "Chaos Pup" }
 },
  [26143160] = {
   { criteriaID = 28796, achID = 10052, questID = 39157, faction = "both" , name = "Felsworn Sentry" }
 },
  [31373806] = {
   { criteriaID = 28799, achID = 10052, questID = 39162, faction = "both" , name = "Cursed Spirit" }
 },
  [42237179] = {
   { criteriaID = 28803, achID = 10052, questID = 39166, faction = "both" , name = "Mirecroak" }
 },
  [43378444] = {
   { criteriaID = 28801, achID = 10052, questID = 39164, faction = "both" , name = "Tainted Mudclaw" }
 },
  [44034572] = {
   { criteriaID = 28806, achID = 10052, questID = 39169, faction = "both" , name = "Vile Blood of Draenor" }
 },
  [47335278] = {
   { criteriaID = 28807, achID = 10052, questID = 39170, faction = "both" , name = "Dreadwalker" }
 },
  [48073302] = {
   { criteriaID = 28808, achID = 10052, questID = 39172, faction = "both" , name = "Skrillix (Cave)" }
 },
  [48373547] = {
   { criteriaID = 28810, achID = 10052, questID = 39171, faction = "both" , name = "Netherfist" }
 },
  [53016521] = {
   { criteriaID = 28797, achID = 10052, questID = 39160, faction = "both" , name = "Corrupted Thundertail" }
 },
  [54072983] = {
   { criteriaID = 28804, achID = 10052, questID = 39167, faction = "both" , name = "Dark Gazer" }
 },
  [55908076] = {
   { criteriaID = 28800, achID = 10052, questID = 39163, faction = "both" , name = "Felfly" }
 },
  [57733734] = {
   { criteriaID = 28802, achID = 10052, questID = 39165, faction = "both" , name = "Direflame" }
 },
  [75453736] = {
   { criteriaID = 28809, achID = 10052, questID = 39173, faction = "both" , name = "Defiled Earth" }
 }},
[535] = {
  [49008040] = {
   { criteriaID = 27002, achID = 9069, faction = "both" , name = "Taralune" },
   { criteriaID = 27016, achID = 9724, faction = "both" , name = "Taralune" }
 }},
[539] = {
  [50003120] = {
   { criteriaID = 26969, achID = 9069, faction = "both" , name = "Ashlei" },
   { criteriaID = 27012, achID = 9724, faction = "both" , name = "Ashlei" }
 }},
[542] = {
  [46204540] = {
   { criteriaID = 27006, achID = 9069, faction = "both" , name = "Vesharr" },
   { criteriaID = 27014, achID = 9724, faction = "both" , name = "Vesharr" }
 }},
[543] = {
  [51007060] = {
   { criteriaID = 26978, achID = 9069, faction = "both" , name = "Cymre Brightblade" },
   { criteriaID = 27011, achID = 9724, faction = "both" , name = "Cymre Brightblade" }
 }},
[550] = {
  [56200980] = {
   { criteriaID = 27004, achID = 9069, faction = "both" , name = "Tarr the Terrible" },
   { criteriaID = 27015, achID = 9724, faction = "both" , name = "Tarr the Terrible" }
 }},
[554] = {
  [34805961] = {
   { criteriaID = 23611, achID = 8518, faction = "both" , name = "Lorewalker Cho" },
   { criteriaID = 26987, achID = 9069, faction = "both" , name = "Lorewalker Cho" }
 },
  [34805962] = {
   { criteriaID = 23607, achID = 8518, faction = "both" , name = "Shademaster Kiryn" },
   { criteriaID = 26999, achID = 9069, faction = "both" , name = "Shademaster Kiryn" }
 },
  [34805963] = {
   { criteriaID = 23621, achID = 8518, faction = "both" , name = "Dr. Ion Goldbloom" },
   { criteriaID = 26979, achID = 9069, faction = "both" , name = "Dr. Ion Goldbloom" }
 },
  [34805964] = {
   { criteriaID = 23620, achID = 8518, faction = "both" , name = "Blingtron 4000" },
   { criteriaID = 26971, achID = 9069, faction = "both" , name = "Blingtron 4000" }
 },
  [34805965] = {
   { criteriaID = 23617, achID = 8518, faction = "both" , name = "Sully \"The Pickle\" McLeary" },
   { criteriaID = 27001, achID = 9069, faction = "both" , name = "Sully \"The Pickle\" McLeary" }
 },
  [34805966] = {
   { criteriaID = 23619, achID = 8518, faction = "both" , name = "Wise Mari" },
   { criteriaID = 27009, achID = 9069, faction = "both" , name = "Wise Mari" }
 },
  [34805967] = {
   { criteriaID = 23618, achID = 8518, faction = "both" , name = "Taran Zhu" },
   { criteriaID = 27003, achID = 9069, faction = "both" , name = "Taran Zhu" }
 },
  [34805968] = {
   { criteriaID = 23610, achID = 8518, faction = "both" , name = "Wrathion" },
   { criteriaID = 27010, achID = 9069, faction = "both" , name = "Wrathion" }
 },
  [34805969] = {
   { criteriaID = 23616, achID = 8518, faction = "both" , name = "Chen Stormstout" },
   { criteriaID = 26975, achID = 9069, faction = "both" , name = "Chen Stormstout" }
 },
  [35975623] = {
   { criteriaID = 23614, achID = 8518, faction = "both" , name = "Zao, Calfling of Niuzao" }
 },
  [48695413] = {
   { criteriaID = 23613, achID = 8518, faction = "both" , name = "Yu'la, Broodling of Yu'lon" }
 },
  [67684271] = {
   { criteriaID = 23612, achID = 8518, faction = "both" , name = "Xu-Fu, Cub of Xuen" }
 }},
[626] = {
  [28392388] = {
   { criteriaID = 31527, achID = 10876, questID = 40298, faction = "both" , name = "Sir Galveston" },
   { criteriaID = 32485, achID = 9696, faction = "both" , name = "Sir Galveston" }
 }},
[627] = {
  [28402440] = {
   { criteriaID = 31526, achID = 10876, questID = 41881, faction = "both" , name = "Heliosus" },
   { criteriaID = 31528, achID = 10876, questID = 41886, faction = "both" , name = "Splint Jr." },
   { criteriaID = 31529, achID = 10876, questID = 42062, faction = "both" , name = "Stitches Jr. Jr.	" }
 },
  [28602460] = {
   { criteriaID = 31524, achID = 10876, questID = 42442, faction = "both" , name = "Amalia" },
   { criteriaID = 32465, achID = 9696, faction = "both" , name = "Amalia" }
 },
  [46603920] = {
   { criteriaID = 31530, achID = 10876, questID = 40277, faction = "both" , name = "Tiffany Nelson" },
   { criteriaID = 32489, achID = 9696, faction = "both" , name = "Tiffany Nelson" }
 },
  [50880948] = {
   { criteriaID = 31554, achID = 10876, questID = 41860, faction = "both" , name = "Xorvasc" },
   { criteriaID = 32474, achID = 9696, faction = "both" , name = "Xorvasc" }
 }},
[630] = {
  [30805000] = {
   { criteriaID = 31519, achID = 10876, questID = 42165, faction = "both" , name = "Felspider" }
 },
  [43400840] = {
   { criteriaID = 31522, achID = 10876, questID = 42148, faction = "both" , name = "Vinu" }
 },
  [50034143] = {
   { criteriaID = 31520, achID = 10876, questID = 42146, faction = "both" , name = "Beguiling Orb" }
 },
  [53141620] = {
   { criteriaID = 31523, achID = 10876, questID = 42154, faction = "both" , name = "Wounded Azurewing Whelpling" }
 },
  [65604100] = {
   { criteriaID = 31518, achID = 10876, questID = 42063, faction = "both" , name = "Blottis" }
 }},
[634] = {
  [38402740] = {
   { criteriaID = 31537, achID = 10876, questID = 42067, faction = "both" , name = "Chromadon" }
 },
  [48354480] = {
   { criteriaID = 31539, achID = 10876, questID = 41958, faction = "both" , name = "Ominitron Defense System	" }
 },
  [62005200] = {
   { criteriaID = 31542, achID = 10876, questID = 41935, faction = "both" , name = "Rydyr" }
 },
  [62205200] = {
   { criteriaID = 31542, achID = 10876, questID = 41935, faction = "both" , name = "Andurs" }
 },
  [62606740] = {
   { criteriaID = 31541, achID = 10876, questID = 41948, faction = "both" , name = "Envoy of the Hunt" }
 }},
[641] = {
  [54608340] = {
   { criteriaID = 31553, achID = 10876, questID = 42190, faction = "both" , name = "Shimmering Aquafly" }
 },
  [55808860] = {
   { criteriaID = 31552, achID = 10876, questID = 41855, faction = "both" , name = "Thistleleaf Bully" }
 },
  [56206520] = {
   { criteriaID = 31550, achID = 10876, questID = 41862, faction = "both" , name = "Fragment of Fire" }
 },
  [66003900] = {
   { criteriaID = 31551, achID = 10876, questID = 41861, faction = "both" , name = "The Maw" }
 }},
[650] = {
  [28606461] = {
   { criteriaID = 31525, achID = 10876, questID = 40299, faction = "both" , name = "Bodhi Sunwayver" },
   { criteriaID = 32476, achID = 9696, faction = "both" , name = "Bodhi Sunwayver" }
 },
  [28806461] = {
   { criteriaID = 31543, achID = 10876, questID = 41895, faction = "both" , name = "Aulier" },
   { criteriaID = 32466, achID = 9696, faction = "both" , name = "Aulier" }
 },
  [36604660] = {
   { criteriaID = 31531, achID = 10876, questID = 40280, faction = "both" , name = "Bredda Tenderhide" },
   { criteriaID = 32477, achID = 9696, faction = "both" , name = "Bredda Tenderhide" }
 },
  [37205760] = {
   { criteriaID = 31536, achID = 10876, questID = 41624, faction = "both" , name = "Rocko" }
 },
  [37606380] = {
   { criteriaID = 31532, achID = 10876, questID = 40282, faction = "both" , name = "Grixis Tinypop" },
   { criteriaID = 32480, achID = 9696, faction = "both" , name = "Grixis Tinypop" }
 },
  [43200740] = {
   { criteriaID = 31534, achID = 10876, questID = 42064, faction = "both" , name = "Lil'idan" }
 },
  [47404020] = {
   { criteriaID = 31535, achID = 10876, questID = 41687, faction = "both" , name = "Odrogg" },
   { criteriaID = 32470, achID = 9696, faction = "both" , name = "Odrogg" }
 },
  [47604020] = {
   { criteriaID = 31540, achID = 10876, questID = 40278, faction = "both" , name = "Robert Craig" },
   { criteriaID = 32484, achID = 9696, faction = "both" , name = "Robert Craig" }
 },
  [47804000] = {
   { criteriaID = 31549, achID = 10876, questID = 40279, faction = "both" , name = "Durian Strongfruit" },
   { criteriaID = 32478, achID = 9696, faction = "both" , name = "Durian Strongfruit" }
 },
  [50806360] = {
   { criteriaID = 31546, achID = 10876, questID = 40337, faction = "both" , name = "Master Tamer Flummox" },
   { criteriaID = 32492, achID = 9696, faction = "both" , name = "Master Tamer Flummox" }
 },
  [56205300] = {
   { criteriaID = 31533, achID = 10876, questID = 41766, faction = "both" , name = "Hungry Icefang" }
 },
  [56600980] = {
   { criteriaID = 31538, achID = 10876, questID = 41944, faction = "both" , name = "Trapper Jarrun" },
   { criteriaID = 32490, achID = 9696, faction = "both" , name = "Trapper Jarrun" }
 }},
[680] = {
  [19953526] = {
   { criteriaID = 31548, achID = 10876, questID = 41931, faction = "both" , name = "Surging Mana Crystal" }
 },
  [33252292] = {
   { criteriaID = 31545, achID = 10876, questID = 41990, faction = "both" , name = "Varenne" },
   { criteriaID = 32472, achID = 9696, faction = "both" , name = "Varenne" }
 },
  [33292308] = {
   { criteriaID = 31521, achID = 10876, questID = 42159, faction = "both" , name = "Nightwatcher Merayl" },
   { criteriaID = 32483, achID = 9696, faction = "both" , name = "Nightwatcher Merayl" }
 },
  [33608320] = {
   { criteriaID = 31547, achID = 10876, questID = 42015, faction = "both" , name = "Felsoul Seer" }
 },
  [59264278] = {
   { criteriaID = 31544, achID = 10876, questID = 41914, faction = "both" , name = "Ancient Catacomb Eggs" }
 }},
[830] = {
  [30005851] = {
   { criteriaID = 37723, achID = 12088, faction = "both" , name = "Deathscreech" },
   { criteriaID = 37779, achID = 12100, faction = "both" , name = "Deathscreech" }
 },
  [40006600] = {
   { criteriaID = 37724, achID = 12088, faction = "both" , name = "Gnasher" },
   { criteriaID = 37789, achID = 12100, faction = "both" , name = "Gnasher" }
 },
  [43005200] = {
   { criteriaID = 37721, achID = 12088, faction = "both" , name = "Baneglow" },
   { criteriaID = 37759, achID = 12100, faction = "both" , name = "Baneglow" }
 },
  [51506381] = {
   { criteriaID = 37720, achID = 12088, faction = "both" , name = "Foulclaw" },
   { criteriaID = 37750, achID = 12100, faction = "both" , name = "Foulclaw" }
 },
  [58003000] = {
   { criteriaID = 37722, achID = 12088, faction = "both" , name = "Retch" },
   { criteriaID = 37769, achID = 12100, faction = "both" , name = "Retch" }
 },
  [66807270] = {
   { criteriaID = 37719, achID = 12088, faction = "both" , name = "Ruinhoof" },
   { criteriaID = 37740, achID = 12100, faction = "both" , name = "Ruinhoof" }
 }},
[862] = {
  [48403500] = {
   { criteriaID = 43608, achID = 13279, faction = "both" , name = "Talia Sparkbrow" },
   { criteriaID = 44230, achID = 12936, faction = "both" , name = "Talia Sparkbrow" }
 },
  [56204934] = {
   { criteriaID = 43609, achID = 13279, faction = "both" , name = "Zujai" },
   { criteriaID = 44232, achID = 12936, faction = "both" , name = "Zujai" }
 },
  [60303120] = {
   { criteriaID = 44218, achID = 12936, faction = "both" , name = "Chitara" }
 },
  [70602960] = {
   { criteriaID = 43607, achID = 13279, faction = "both" , name = "Karaga" },
   { criteriaID = 44229, achID = 12936, faction = "both" , name = "Karaga" }
 }},
[863] = {
  [36005460] = {
   { criteriaID = 43602, achID = 13279, faction = "both" , name = "Grady Prett" },
   { criteriaID = 44223, achID = 12936, faction = "both" , name = "Grady Prett" }
 },
  [42603820] = {
   { criteriaID = 44222, achID = 12936, faction = "both" , name = "Bloodtusk" }
 },
  [43003880] = {
   { criteriaID = 43603, achID = 13279, faction = "both" , name = "Korval Darkbeard" },
   { criteriaID = 44224, achID = 12936, faction = "both" , name = "Korval Darkbeard" }
 },
  [72804860] = {
   { criteriaID = 43601, achID = 13279, faction = "both" , name = "Lozu" },
   { criteriaID = 44221, achID = 12936, faction = "both" , name = "Lozu" }
 }},
[864] = {
  [26605480] = {
   { criteriaID = 43605, achID = 13279, faction = "both" , name = "Sizzik" },
   { criteriaID = 44228, achID = 12936, faction = "both" , name = "Sizzik" }
 },
  [43855091] = {
   { criteriaID = 44226, achID = 12936, faction = "both" , name = "Spineleaf" }
 },
  [45004640] = {
   { criteriaID = 43606, achID = 13279, faction = "both" , name = "Kusa" },
   { criteriaID = 44227, achID = 12936, faction = "both" , name = "Kusa" }
 },
  [56405340] = {
   { criteriaID = 44231, achID = 12936, faction = "both" , name = "Jammer" }
 },
  [57004900] = {
   { criteriaID = 43604, achID = 13279, faction = "both" , name = "Keeyo" },
   { criteriaID = 44225, achID = 12936, faction = "both" , name = "Keeyo" }
 }},
[882] = {
  [31903120] = {
   { criteriaID = 37729, achID = 12088, faction = "both" , name = "Corrupted Blood of Argus" },
   { criteriaID = 37839, achID = 12100, faction = "both" , name = "Corrupted Blood of Argus" }
 },
  [36005411] = {
   { criteriaID = 37728, achID = 12088, faction = "both" , name = "Shadeflicker" },
   { criteriaID = 37829, achID = 12100, faction = "both" , name = "Shadeflicker" }
 },
  [60007110] = {
   { criteriaID = 37727, achID = 12088, faction = "both" , name = "Gloamwing" },
   { criteriaID = 37819, achID = 12100, faction = "both" , name = "Gloamwing" }
 },
  [67604391] = {
   { criteriaID = 37725, achID = 12088, faction = "both" , name = "Bucky" },
   { criteriaID = 37799, achID = 12100, faction = "both" , name = "Bucky" }
 },
  [69705190] = {
   { criteriaID = 37726, achID = 12088, faction = "both" , name = "Snozz" },
   { criteriaID = 37809, achID = 12100, faction = "both" , name = "Snozz" }
 },
  [74703620] = {
   { criteriaID = 37730, achID = 12088, faction = "both" , name = "Mar'cuus" },
   { criteriaID = 37849, achID = 12100, faction = "both" , name = "Mar'cuus" }
 }},
[885] = {
  [51604141] = {
   { criteriaID = 37731, achID = 12088, faction = "both" , name = "Watcher" },
   { criteriaID = 37859, achID = 12100, faction = "both" , name = "Watcher" }
 },
  [56102871] = {
   { criteriaID = 37733, achID = 12088, faction = "both" , name = "Earseeker" },
   { criteriaID = 37879, achID = 12100, faction = "both" , name = "Earseeker" }
 },
  [56605430] = {
   { criteriaID = 37732, achID = 12088, faction = "both" , name = "Bloat" },
   { criteriaID = 37869, achID = 12100, faction = "both" , name = "Bloat" }
 },
  [59904030] = {
   { criteriaID = 37736, achID = 12088, faction = "both" , name = "One-of-Many" },
   { criteriaID = 37909, achID = 12100, faction = "both" , name = "One-of-Many" }
 },
  [64006591] = {
   { criteriaID = 37734, achID = 12088, faction = "both" , name = "Pilfer" },
   { criteriaID = 37889, achID = 12100, faction = "both" , name = "Pilfer" }
 },
  [76607410] = {
   { criteriaID = 37735, achID = 12088, faction = "both" , name = "Minixis" },
   { criteriaID = 37899, achID = 12100, faction = "both" , name = "Minixis" }
 }},
[895] = {
  [59603320] = {
   { criteriaID = 43599, achID = 13279, faction = "both" , name = "Delia Hanako" },
   { criteriaID = 44219, achID = 12936, faction = "both" , name = "Delia Hanako" }
 },
  [67601280] = {
   { criteriaID = 43600, achID = 13279, faction = "both" , name = "Burly" },
   { criteriaID = 44220, achID = 12936, faction = "both" , name = "Burly" }
 },
  [86203860] = {
   { criteriaID = 43598, achID = 13279, faction = "both" , name = "Kwint" },
   { criteriaID = 44217, achID = 12936, faction = "both" , name = "Kwint" }
 }},
[896] = {
  [21406640] = {
   { criteriaID = 43591, achID = 13279, faction = "both" , name = "Captain Hermes" },
   { criteriaID = 44208, achID = 12936, faction = "both" , name = "Captain Hermes" }
 },
  [38203860] = {
   { criteriaID = 43594, achID = 13279, faction = "both" , name = "Fizzie Sparkwhistle" },
   { criteriaID = 44213, achID = 12936, faction = "both" , name = "Fizzie Sparkwhistle" }
 },
  [61001760] = {
   { criteriaID = 43595, achID = 13279, faction = "both" , name = "Michael Skarn" },
   { criteriaID = 44214, achID = 12936, faction = "both" , name = "Michael Skarn" }
 },
  [63605960] = {
   { criteriaID = 43593, achID = 13279, faction = "both" , name = "Dilbert McClint" },
   { criteriaID = 44212, achID = 12936, faction = "both" , name = "Dilbert McClint" }
 }},
[942] = {
  [36603360] = {
   { criteriaID = 43592, achID = 13279, faction = "both" , name = "Eddie Fixit" },
   { criteriaID = 44211, achID = 12936, faction = "both" , name = "Eddie Fixit" }
 },
  [50505120] = {
   { criteriaID = 44209, achID = 12936, faction = "both" , name = "Bristlespine" }
 },
  [65005080] = {
   { criteriaID = 43596, achID = 13279, faction = "both" , name = "Ellie Vern" },
   { criteriaID = 44215, achID = 12936, faction = "both" , name = "Ellie Vern" }
 },
  [77202900] = {
   { criteriaID = 43597, achID = 13279, faction = "both" , name = "Leana Darkwind" },
   { criteriaID = 44216, achID = 12936, faction = "both" , name = "Leana Darkwind" }
 }},
[1355] = {
  [28102670] = {
   { criteriaID = 45478, achID = 13626, faction = "both" , name = "Giant Opaline Conch" },
   { criteriaID = 45478, achID = 13695, faction = "both" , name = "Giant Opaline Conch" }
 },
  [29604970] = {
   { criteriaID = 45473, achID = 13626, faction = "both" , name = "Ravenous Scalespawn" },
   { criteriaID = 45473, achID = 13695, faction = "both" , name = "Ravenous Scalespawn" }
 },
  [34702740] = {
   { criteriaID = 45467, achID = 13626, faction = "both" , name = "Prince Wiggletail" },
   { criteriaID = 45467, achID = 13695, faction = "both" , name = "Prince Wiggletail" }
 },
  [37501670] = {
   { criteriaID = 45476, achID = 13626, faction = "both" , name = "Voltgorger" },
   { criteriaID = 45476, achID = 13695, faction = "both" , name = "Voltgorger" }
 },
  [42201400] = {
   { criteriaID = 45470, achID = 13626, faction = "both" , name = "Shadowspike Lurker" },
   { criteriaID = 45470, achID = 13695, faction = "both" , name = "Shadowspike Lurker" }
 },
  [46602800] = {
   { criteriaID = 45475, achID = 13626, faction = "both" , name = "Kelpstone" },
   { criteriaID = 45475, achID = 13695, faction = "both" , name = "Kelpstone" }
 },
  [50605030] = {
   { criteriaID = 45471, achID = 13626, faction = "both" , name = "Pearlhusk Crawler" },
   { criteriaID = 45471, achID = 13695, faction = "both" , name = "Pearlhusk Crawler" }
 },
  [51307500] = {
   { criteriaID = 45472, achID = 13626, faction = "both" , name = "Elderspawn of Nalaada" },
   { criteriaID = 45472, achID = 13695, faction = "both" , name = "Elderspawn of Nalaada" }
 },
  [56400810] = {
   { criteriaID = 45474, achID = 13626, faction = "both" , name = "Mindshackle" },
   { criteriaID = 45474, achID = 13695, faction = "both" , name = "Mindshackle" }
 },
  [58304810] = {
   { criteriaID = 45469, achID = 13626, faction = "both" , name = "Silence" },
   { criteriaID = 45469, achID = 13695, faction = "both" , name = "Silence" }
 },
  [59102660] = {
   { criteriaID = 45477, achID = 13626, faction = "both" , name = "Frenzied Knifefang" },
   { criteriaID = 45477, achID = 13695, faction = "both" , name = "Frenzied Knifefang" }
 },
  [71905110] = {
   { criteriaID = 45468, achID = 13626, faction = "both" , name = "Chomp" },
   { criteriaID = 45468, achID = 13695, faction = "both" , name = "Chomp" }
 }},
[1462] = {
  [39504010] = {
   { criteriaID = 45465, achID = 13625, faction = "both" , name = "Unit 6" },
   { criteriaID = 45465, achID = 13695, faction = "both" , name = "Unit 6" }
 },
  [51104540] = {
   { criteriaID = 45464, achID = 13625, faction = "both" , name = "Unit 35" },
   { criteriaID = 45464, achID = 13695, faction = "both" , name = "Unit 35" }
 },
  [59205090] = {
   { criteriaID = 45462, achID = 13625, faction = "both" , name = "Creakclank" },
   { criteriaID = 45462, achID = 13695, faction = "both" , name = "Creakclank" }
 },
  [60605690] = {
   { criteriaID = 45461, achID = 13625, faction = "both" , name = "Goldenbot XD" },
   { criteriaID = 45461, achID = 13695, faction = "both" , name = "Goldenbot XD" }
 },
  [60704650] = {
   { criteriaID = 45460, achID = 13625, faction = "both" , name = "Sputtertube" },
   { criteriaID = 45460, achID = 13695, faction = "both" , name = "Sputtertube" }
 },
  [60804140] = {
   { criteriaID = 45463, achID = 13625, faction = "both" , name = "CK-9 Micro-Oppression Unit" },
   { criteriaID = 45463, achID = 13695, faction = "both" , name = "CK-9 Micro-Oppression Unit" }
 },
  [64706460] = {
   { criteriaID = 45459, achID = 13625, faction = "both" , name = "Gnomefeaster" },
   { criteriaID = 45459, achID = 13695, faction = "both" , name = "Gnomefeaster" }
 },
  [72107290] = {
   { criteriaID = 45466, achID = 13625, faction = "both" , name = "Unit 17" },
   { criteriaID = 45466, achID = 13695, faction = "both" , name = "Unit 17" }
 }},
[1525] = {
  [25602360] = {
   { criteriaID = 51051, achID = 14881, faction = "both" , name = "Sewer Creeper" }
 },
  [40005261] = {
   { criteriaID = 49408, achID = 14625, faction = "both" , name = "Sylla" },
   { criteriaID = 50936, achID = 14879, faction = "both" , name = "Sylla" }
 },
  [53004160] = {
   { criteriaID = 51052, achID = 14881, faction = "both" , name = "The Countess" }
 },
  [61204101] = {
   { criteriaID = 49406, achID = 14625, faction = "both" , name = "Addius the Tormentor" },
   { criteriaID = 50934, achID = 14879, faction = "both" , name = "Addius the Tormentor" }
 },
  [67606601] = {
   { criteriaID = 49407, achID = 14625, faction = "both" , name = "Eyegor" },
   { criteriaID = 50935, achID = 14879, faction = "both" , name = "Eyegor" }
 }},
[1533] = {
  [25803080] = {
   { criteriaID = 51053, achID = 14881, faction = "both" , name = "Digallo" }
 },
  [34806280] = {
   { criteriaID = 49416, achID = 14625, faction = "both" , name = "Stratios" },
   { criteriaID = 50928, achID = 14879, faction = "both" , name = "Stratios" }
 },
  [36603180] = {
   { criteriaID = 49417, achID = 14625, faction = "both" , name = "Jawbone" }
 },
  [46604940] = {
   { criteriaID = 51055, achID = 14881, faction = "both" , name = "Kostos" }
 },
  [51403820] = {
   { criteriaID = 49415, achID = 14625, faction = "both" , name = "Zolla" },
   { criteriaID = 50930, achID = 14879, faction = "both" , name = "Zolla" }
 },
  [52607420] = {
   { criteriaID = 51047, achID = 14881, faction = "both" , name = "Crystalsnap" }
 },
  [54605600] = {
   { criteriaID = 49414, achID = 14625, faction = "both" , name = "Thenia" },
   { criteriaID = 50929, achID = 14879, faction = "both" , name = "Thenia" }
 }},
[1536] = {
  [25203800] = {
   { criteriaID = 49409, achID = 14625, faction = "both" , name = "Scorch" }
 },
  [26602680] = {
   { criteriaID = 51056, achID = 14881, faction = "both" , name = "Glurp" }
 },
  [34005520] = {
   { criteriaID = 49412, achID = 14625, faction = "both" , name = "Rotgut" },
   { criteriaID = 50933, achID = 14879, faction = "both" , name = "Rotgut" }
 },
  [46805000] = {
   { criteriaID = 49413, achID = 14625, faction = "both" , name = "Caregiver Maximillian" },
   { criteriaID = 50931, achID = 14879, faction = "both" , name = "Caregiver Maximillian" }
 },
  [54002800] = {
   { criteriaID = 49410, achID = 14625, faction = "both" , name = "Gorgemouth" }
 },
  [61807880] = {
   { criteriaID = 51054, achID = 14881, faction = "both" , name = "Gelatinous" }
 },
  [63204681] = {
   { criteriaID = 49411, achID = 14625, faction = "both" , name = "Dundley Stickyfingers" },
   { criteriaID = 50932, achID = 14879, faction = "both" , name = "Dundley Stickyfingers" }
 }},
[1565] = {
  [26606200] = {
   { criteriaID = 51049, achID = 14881, faction = "both" , name = "Chittermaw" }
 },
  [34204460] = {
   { criteriaID = 51048, achID = 14881, faction = "both" , name = "Briarpaw" }
 },
  [40006440] = {
   { criteriaID = 49404, achID = 14625, faction = "both" , name = "Nightfang" }
 },
  [40202880] = {
   { criteriaID = 49402, achID = 14625, faction = "both" , name = "Rascal" }
 },
  [49804160] = {
   { criteriaID = 51050, achID = 14881, faction = "both" , name = "Mistwing" }
 },
  [51204401] = {
   { criteriaID = 49403, achID = 14625, faction = "both" , name = "Faryl" },
   { criteriaID = 50937, achID = 14879, faction = "both" , name = "Faryl" }
 },
  [58205680] = {
   { criteriaID = 49405, achID = 14625, faction = "both" , name = "Glitterdust" },
   { criteriaID = 50927, achID = 14879, faction = "both" , name = "Glitterdust" }
 }},
[2022] = {
  [26009240] = {
   { criteriaID = 55488, achID = 16464, faction = "both" , name = "Swog" },
   { criteriaID = 55538, achID = 16512, faction = "both" , name = "Swog" }
 },
  [38808321] = {
   { criteriaID = 55485, achID = 16464, faction = "both" , name = "Haniko" },
   { criteriaID = 55536, achID = 16512, faction = "both" , name = "Haniko" }
 }},
[2023] = {
  [24404220] = {
   { criteriaID = 55486, achID = 16464, faction = "both" , name = "Stormamu" },
   { criteriaID = 55535, achID = 16512, faction = "both" , name = "Stormamu" }
 },
  [62004161] = {
   { criteriaID = 55492, achID = 16464, faction = "both" , name = "Bakhushek" },
   { criteriaID = 55540, achID = 16512, faction = "both" , name = "Bakhushek" }
 }},
[2024] = {
  [13804981] = {
   { criteriaID = 55489, achID = 16464, faction = "both" , name = "Patchu" },
   { criteriaID = 55539, achID = 16512, faction = "both" , name = "Patchu" }
 },
  [41005941] = {
   { criteriaID = 55487, achID = 16464, faction = "both" , name = "Arcantus" },
   { criteriaID = 55537, achID = 16512, faction = "both" , name = "Arcantus" }
 }},
[2025] = {
  [39407340] = {
   { criteriaID = 55490, achID = 16464, faction = "both" , name = "Enyobon" },
   { criteriaID = 55541, achID = 16512, faction = "both" , name = "Enyobon" }
 },
  [56204921] = {
   { criteriaID = 55493, achID = 16464, faction = "both" , name = "Setimothes" },
   { criteriaID = 55542, achID = 16512, faction = "both" , name = "Setimothes" }
 }},
[2133] = {
  [47465339] = {
   { criteriaID = 102979, achID = 41551, faction = "both" , name = "Baxx the Purveyor" }
 },
  [47705326] = {
   { criteriaID = 67135, achID = 40153, faction = "both" , name = "Collector Dyna" },
   { criteriaID = 67139, achID = 40980, faction = "both" , name = "Collector Dyna" }
 },
  [48265344] = {
   { criteriaID = 102978, achID = 41551, faction = "both" , name = "Precision Powerdrill" }
 },
  [48365321] = {
   { criteriaID = 102980, achID = 41551, faction = "both" , name = "Prezly Wavecutter" }
 },
  [48705340] = {
   { criteriaID = 67136, achID = 40153, faction = "both" , name = "Friendhaver Grem" },
   { criteriaID = 67140, achID = 40980, faction = "both" , name = "Friendhaver Grem" }
 },
  [48965321] = {
   { criteriaID = 102981, achID = 41551, faction = "both" , name = "Creech" }
 },
  [49095337] = {
   { criteriaID = 67137, achID = 40153, faction = "both" , name = "Kyrie" },
   { criteriaID = 67141, achID = 40980, faction = "both" , name = "Kyrie" }
 },
  [56247389] = {
   { criteriaID = 58212, achID = 17406, faction = "both" , name = "Adinakon" },
   { criteriaID = 58218, achID = 17406, faction = "both" , name = "A New Vocation" }
 },
  [57017320] = {
   { criteriaID = 59352, achID = 17880, faction = "both" , name = "Explorer Bezzert" },
   { criteriaID = 59355, achID = 17934, faction = "both" , name = "Explorer Bezzert" }
 },
  [57637329] = {
   { criteriaID = 58216, achID = 17406, faction = "both" , name = "Sharp as Flint" }
 },
  [57797356] = {
   { criteriaID = 58213, achID = 17406, faction = "both" , name = "Lyver" }
 },
  [58607233] = {
   { criteriaID = 58217, achID = 17406, faction = "both" , name = "Paws of Thunder" }
 },
  [59745346] = {
   { criteriaID = 67131, achID = 40153, faction = "both" , name = "Awakened Custodian" }
 },
  [59925360] = {
   { criteriaID = 67132, achID = 40153, faction = "both" , name = "Haywire Servobot" }
 },
  [60205544] = {
   { criteriaID = 58214, achID = 17406, faction = "both" , name = "Enok the Stinky" }
 },
  [60345489] = {
   { criteriaID = 67133, achID = 40153, faction = "both" , name = "Guttergunk" }
 },
  [60985410] = {
   { criteriaID = 58215, achID = 17406, faction = "both" , name = "Malfunctioning Matrix" }
 }},
[2151] = {
  [13205360] = {
   { criteriaID = 58574, achID = 17541, questID = 73148, faction = "both" , name = "Wildfire" }
 },
  [18201340] = {
   { criteriaID = 58572, achID = 17541, questID = 73146, faction = "both" , name = "Vortex" }
 },
  [67201220] = {
   { criteriaID = 58573, achID = 17541, questID = 73147, faction = "both" , name = "Tremblor" }
 },
  [89206040] = {
   { criteriaID = 58575, achID = 17541, questID = 73149, faction = "both" , name = "Flow" }
 }},
[2200] = {
  [40255644] = {
   { criteriaID = 59351, achID = 17880, faction = "both" , name = "Shinmura" },
   { criteriaID = 59356, achID = 17934, faction = "both" , name = "Shinmura" }
 },
  [42395704] = {
   { criteriaID = 59354, achID = 17880, faction = "both" , name = "Delver Mardei" },
   { criteriaID = 59357, achID = 17934, faction = "both" , name = "Delver Mardei" }
 },
  [43125711] = {
   { criteriaID = 59353, achID = 17880, faction = "both" , name = "Trainer Orlogg" },
   { criteriaID = 59358, achID = 17934, faction = "both" , name = "Trainer Orlogg" }
 },
  [47934084] = {
   { criteriaID = 67134, achID = 40153, faction = "both" , name = "Zaedu" }
 },
  [48553691] = {
   { criteriaID = 67138, achID = 40153, faction = "both" , name = "Ziriak" },
   { criteriaID = 67142, achID = 40980, faction = "both" , name = "Ziriak" }
 }},
 }