local _, PetDailies = ...

PetDailies.Data = PetDailies.Data or {}

PetDailies.Data.Options = {
    display = {
        type  = "group",
        name  = "Display Settings",
        order = 1,
        args  = {
            left = {
                type   = "group",
                name   = "",
                inline = true,
                order  = 1,
                width  = "half",
                args   = {
                    completed = {
                        type  = "toggle",
                        name  = "Show Completed",
                        desc  = "Show objectives even if completed",
                        get   = function() return PetDailies.db.completed end,
                        set   = function(_, v)
                            PetDailies.db.completed = v
                            PetDailies:Refresh()
                        end,
                        order = 1,
                        width = "full",
                    },
                    coins = {
                        type  = "toggle",
                        name  = "Show Coin Rewards",
                        desc  = "Show objectives that only reward coins",
                        get   = function() return PetDailies.db.coins end,
                        set   = function(_, v)
                            PetDailies.db.coins = v
                            PetDailies:Refresh()
                        end,
                        order = 2,
                        width = "full",
                    },
                },
            },
            right = {
                type   = "group",
                name   = "",
                inline = true,
                order  = 2,
                width  = "half",
                args   = {
                    icon_scale = {
                        type  = "range",
                        name  = "Icon Scale",
                        desc  = "Adjust the size of map icons",
                        min   = 0.25, max = 4.0, step = 0.05,
                        get   = function() return PetDailies.db.icon_scale or 1 end,
                        set   = function(_, v)
                            PetDailies.db.icon_scale = v
                            PetDailies:Refresh()
                        end,
                        order = 1,
                        width = "full",
                    },
                    icon_alpha = {
                        type  = "range",
                        name  = "Icon Transparency",
                        desc  = "Adjust the transparency of map icons",
                        min   = 0, max = 1, step = 0.01,
                        get   = function() return PetDailies.db.icon_alpha or 1 end,
                        set   = function(_, v)
                            PetDailies.db.icon_alpha = v
                            PetDailies:Refresh()
                        end,
                        order = 2,
                        width = "full",
                    },
                },
            },
        },
    },
}
