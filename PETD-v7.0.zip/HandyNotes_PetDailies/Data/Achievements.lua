local _, PetDailies = ...
PetDailies.Data = PetDailies.Data or {}

---@class Achievement
---@field name string
---@field expansion string|nil
---@field reward string
---@field icon number|nil
---@field isMeta number|nil 0 = no, 1 = yes

---@type table<number, Achievement>
PetDailies.Data.Achievements = {
[6602] = {  name = "Taming Kalimdor",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Kalimdor Pet Battle Daily Quests",  icon = 236807},
[6603] = {  name = "Taming Eastern Kingdoms",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Eastern Kingdoms Pet Battle Daily Quests",  icon = 236759},
[6604] = {  name = "Taming Outland",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Outland Pet Battle Daily Quests",  icon = 236813},
[6605] = {  name = "Taming Northrend",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Northrend Pet Battle Daily Quests",  icon = 236812},
[6606] = {  name = "Taming Pandaria",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Pandaria Pet Battle Daily Quests",  icon = 652174},
[6607] = {  name = "Taming Azeroth",  expansion = "MoP",  isMeta = 1,  reward = "Title: Tamer",  icon = 652220},
[7499] = {  name = "Taming the World",  expansion = "MoP",  isMeta = 0,  reward = "Reward: Safari Hat",  icon = 652173},
[7525] = {  name = "Taming Cataclysm",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Cataclysm Pet Battle Daily Quests",  icon = 409545},
[7908] = {  name = "I Choose You",  expansion = "MoP",  isMeta = 0,  reward = "Reward: Heavy Sack of Gold",  icon = 631719},
[7936] = {  name = "Pandaren Spirit Tamer",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Pandaren Spirit Tamer Pet Battle Daily Quests",  icon = 656560},
[8080] = {  name = "Fabled Pandaren Tamer",  expansion = "MoP",  isMeta = 0,  reward = "Unlock: Beasts of Fable Pet Battle Daily Quest",  icon = 354435},
[8348] = {  name = "The Longest Day",  expansion = "MoP",  isMeta = 0,  reward = "Reward: Marked Flawless Battle Stone",  icon = 134376},
[8518] = {  name = "Master of the Masters",  expansion = "MoP",  isMeta = 0,  reward = "",  icon = 803763},
[9069] = {  name = "An Awfully Big Adventure",  expansion = "MoP",  isMeta = 0,  reward = "Pet: Trunks",  icon = 656597},
[9696] = {  name = "Family Familiar",  expansion = "Legion",  isMeta = 1,  reward = "Pet: Nightmare Treant",  icon = 1045095},
[9724] = {  name = "Taming Draenor",  expansion = "WoD",  isMeta = 0,  reward = "",  icon = 1032149},
[10052] = {  name = "Tiny Terrors in Tanaan",  expansion = "Legion",  isMeta = 0,  reward = "",  icon = 841219},
[10876] = {  name = "Battle on the Broken Isles",  expansion = "Legion",  isMeta = 0,  reward = "",  icon = 652174},
[11765] = {  name = "Pet Battle Challenge: Wailing Caverns",  expansion = "Legion",  isMeta = 0,  reward = "Pet: Son of Skum",  icon = 134310},
[11856] = {  name = "Pet Battle Challenge: Deadmines",  expansion = "Legion",  isMeta = 0,  reward = "Reward: Mining Monkey",  icon = 1373903},
[12088] = {  name = "Anomalous Animals of Argus",  expansion = "Legion",  isMeta = 0,  reward = "",  icon = 1602317},
[12100] = {  name = "Family Fighter",  expansion = "BfA",  isMeta = 1,  reward = "Pet: Felclaw Marsuul",  icon = 1045097},
[12936] = {  name = "Battle on Zandalar and Kul Tiras",  expansion = "BfA",  isMeta = 0,  reward = "Toy: Laser Pointer",  icon = 652174},
[13269] = {  name = "Pet Battle Challenge: Gnomeregan",  expansion = "BfA",  isMeta = 0,  reward = "Pet: Mini Spider Tank",  icon = 255139},
[13279] = {  name = "Family Battler",  expansion = "BfA",  isMeta = 1,  reward = "Pet: Wicker Wraith",  icon = 461112},
[13625] = {  name = "Mighty Minions of Mechagon",  expansion = "BfA",  isMeta = 0,  reward = "",  icon = 2126356},
[13626] = {  name = "Nautical Nuisances of Nazjatar",  expansion = "BfA",  isMeta = 0,  reward = "",  icon = 2530489},
[13627] = {  name = "Pet Battle Challenge: Stratholme",  expansion = "BfA",  isMeta = 0,  reward = "Pet: Evil Wizard Hat",  icon = 1390947},
[13695] = {  name = "Team Aquashock",  expansion = "BfA",  isMeta = 1,  reward = "Pet: Kelpfin",  icon = 237587},
[13766] = {  name = "Malowned",  expansion = "BfA",  isMeta = 0,  reward = "Pet: Burnout",  icon = 133460},
[14020] = {  name = "Pet Battle Challenge: Blackrock Depths",  expansion = "BfA",  isMeta = 0,  reward = "Toy: Shadowy Disguise",  icon = 236718},
[14021] = {  name = "The Shadows Revealed",  expansion = "BfA",  isMeta = 1,  reward = "Toy: Mayhem Mind Melder",  icon = 3163618},
[14625] = {  name = "Battle in the Shadowlands",  expansion = "SL",  isMeta = 0,  reward = "Toy: Mawsworn Pet Leash",  icon = 652174},
[14879] = {  name = "Family Exorcist",  expansion = "SL",  isMeta = 1,  reward = "Pet: Spriggan Trickster",  icon = 135983},
[14881] = {  name = "Abhorrent Adversaries of the Afterlife",  expansion = "SL",  isMeta = 0,  reward = "Pet: Winterleaf Spriggan",  icon = 3860424},
[16464] = {  name = "Battle on the Dragon Isles",  expansion = "DF",  isMeta = 0,  reward = "",  icon = 652174},
[16512] = {  name = "Family Battler of the Dragon Isles",  expansion = "DF",  isMeta = 1,  reward = "Pet: Lady Feathersworth",  icon = 2103802},
[17406] = {  name = "Battle on the Dragon Isles II",  expansion = "DF",  isMeta = 0,  reward = "",  icon = 652174},
[17541] = {  name = "Global Swarming",  expansion = "DF",  isMeta = 0,  reward = "",  icon = 136099},
[17880] = {  name = "Battle in Zaralek Cavern",  expansion = "DF",  isMeta = 0,  reward = "",  icon = 652174},
[17934] = {  name = "Family Battler of Zaralek Cavern",  expansion = "DF",  isMeta = 1,  reward = "Pet: Gerald",  icon = 4007141},
[40153] = {  name = "Battle on Khaz Algar",  expansion = "TWW",  isMeta = 0,  reward = "",  icon = 652174},
[40980] = {  name = "Family Battler of Khaz Algar",  expansion = "TWW",  isMeta = 1,  reward = "Pet: Fuzzy",  icon = 5755548},
[41551] = {  name = "Family Battler of Undermine",  expansion = "TWW",  isMeta = 1,  reward = "Pet: Foreman",  icon = 5928915},
}