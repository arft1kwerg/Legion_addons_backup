local _, PetDailies = ...
PetDailies.Dispatcher = PetDailies.Dispatcher or {}
local D = PetDailies.Dispatcher

-- Returns an iterator for nodes on the specified map
function D:GetNodes2(MapID, minimap)
    return PetDailies.Services.Points:Iterator(MapID, minimap)
end

-- Handles the OnEnter event for map nodes
function D:OnEnter(...)
    return PetDailies.TooltipHandlers:OnEnter(...)
end

-- Handles the OnClick event for map nodes
function D:OnClick(...)
    return PetDailies.ClickHandlers:OnClick(...)
end

-- Handles the OnLeave event for map nodes
function D:OnLeave(...)
    return PetDailies.TooltipHandlers:OnLeave(...)
end