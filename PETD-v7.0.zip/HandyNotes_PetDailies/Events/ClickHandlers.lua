local _, PetDailies = ...

PetDailies.ClickHandlers = PetDailies.ClickHandlers or {}
local P = PetDailies.Data.Points
local V = PetDailies.Services.Visibility

local HandyNotes = _G.HandyNotes
local TomTom = _G.TomTom

local IsControlKeyDown = _G.IsControlKeyDown


local Lira = LibStub("Lirameirav-1.0")
-- ClickHandlers.lua
local function createWaypoint(mapID, coord, objectives)
    local x, y = HandyNotes:getXY(coord)
    local text = PetDailies.Services.Points:GetPointTitle(objectives)
    TomTom:AddWaypoint(mapID, x, y, { title = text })
end

local function createAllWaypoints()
    for mapID, coords in pairs(P) do
        for coord, objectives in pairs(coords) do
            if V:IsPointVisible(objectives) then
                createWaypoint(mapID, coord, objectives)
            end
        end
    end
end

function PetDailies.ClickHandlers:OnClick(button, down, mapID, coord)
	if TomTom and button == "RightButton" and not down then
		local objectives = P[mapID] and P[mapID][coord]

		if IsControlKeyDown() then
			createAllWaypoints()
		else
			createWaypoint(mapID, coord, objectives)
		end
	end
end
