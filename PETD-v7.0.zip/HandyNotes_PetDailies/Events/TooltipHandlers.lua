local _, PetDailies = ...
PetDailies.TooltipHandlers = PetDailies.TooltipHandlers or {}

---@diagnostic disable-next-line: undefined-field
local WorldMapButton = _G.WorldMapButton
---@diagnostic disable-next-line: undefined-field
local WorldMapTooltip = _G.WorldMapTooltip
---@diagnostic disable-next-line: undefined-field
local TomTom = _G.TomTom
local Lira = LibStub("Lirameirav-1.0")
local T = PetDailies.TooltipHandlers

local question = PetDailies.Data.ICON_QUESTIONMARK

local function GetIconMarkup(icon)
    if not icon then return "" end

    if type(icon) == "number" then
        return CreateTextureMarkup(icon, 64, 64, 16, 16, 0, 1, 0, 1) .. " "
    elseif type(icon) == "string" then
        return "|T" .. icon .. ":16:16:0:0:64:64:0:64:0:64|t "
    end

    return ""
end

function T:BuildFullTooltip(objectives, tooltip)
    local V = PetDailies.Services.Visibility
    local A = PetDailies.Services.Achievement
    local P = PetDailies.Services.Points

    local COLOR_HEADER     = {1.0, 0.82, 0.0}
    local COLOR_TEXT       = {1.0, 1.0, 1.0}
    local COLOR_DIMMED     = {0.6, 0.6, 0.6}
    local COLOR_REWARD     = {0.0, 1.0, 0.0}
    local COLOR_INCOMPLETE = {1.0, 0.2, 0.2}

    tooltip:AddLine("Pet Dailies", unpack(COLOR_HEADER))

    local quests, directs, metas = {}, {}, {}
    for _, obj in ipairs(objectives) do
        local achieve = obj.achID and PetDailies.Data.Achievements[obj.achID]
        if achieve and achieve.isMeta == 1 then
            table.insert(metas, obj)
        elseif achieve then
            table.insert(directs, obj)
        elseif obj.questID then
            table.insert(quests, obj)
        end
    end
   
    local function AddSafeDoubleLine(tooltip, left, right, lColor, rColor)
        tooltip:AddDoubleLine(
            left,
            right,
            lColor[1], lColor[2], lColor[3],
            rColor[1], rColor[2], rColor[3]
        )
        local lineIndex = tooltip:NumLines()
        local rightFS = _G[tooltip:GetName().."TextRight"..lineIndex]
        if rightFS then
            rightFS:SetTextColor(rColor[1], rColor[2], rColor[3])
        end
        local leftFS = _G[tooltip:GetName().."TextLeft"..lineIndex]
        if leftFS then
            leftFS:SetTextColor(lColor[1], lColor[2], lColor[3])
        end
    end


    local function addQuestLine(obj)
        local completed = A:IsObjectiveCompleted(obj)
        local r,g,b = unpack(completed and COLOR_DIMMED or COLOR_TEXT)
        local icon = P:GetObjectiveIcon(obj)
        local iconStr = icon and GetIconMarkup(icon) or ""
        local questName = C_QuestLog.GetTitleForQuestID(obj.questID)
        tooltip:AddLine(iconStr .. (questName or obj.name), r, g, b)
    end

    local function addAchievementLine(obj)
        local achID = obj.achID
        local achieve = PetDailies.Data.Achievements[achID]
        if not achieve then return end

        -- Check overall completion
        local achCompleted = A:IsAchievementCompleted(achID)
        -- Ask AchievementService for criteria info
        local idx, critName = A:FindCriteriaInfo(achID, obj.criteriaID)
        local r,g,b = unpack(achCompleted and COLOR_DIMMED or COLOR_TEXT)
        local icon = P:GetObjectiveIcon(obj)
        local iconStr = icon and GetIconMarkup(icon) or ""

        -- Case 1: Achievement fully completed
        if achCompleted then
            AddSafeDoubleLine(
                tooltip,
                iconStr .. achieve.name,
                "Completed",
                {r,g,b}, {r,g,b}
            )
            return
        end

        -- Case 2: Single-criteria achievement (idx=1, critName=nil)
        if idx and not critName then
            AddSafeDoubleLine(
                tooltip,
                iconStr .. achieve.name,
                "", -- no separate criteria text
                {r,g,b}, {r,g,b}
            )
            return
        end

        -- Case 3: Multi-criteria, show this objective’s criteria name
        --need to show completion of this criteria not the whole achievement
        if idx and critName then

            AddSafeDoubleLine(
                tooltip,
                iconStr .. achieve.name,
                critName,
                {r,g,b}, {r,g,b}
            )
            return
        end

        -- Fallback (shouldn’t hit often)
        tooltip:AddLine(iconStr .. achieve.name, r,g,b)
    end

    local function addMetaBlock(obj)
        local achieve = PetDailies.Data.Achievements[obj.achID]
        if not achieve then return end

        local achCompleted = A:IsAchievementCompleted(obj.achID)
        local rightText =  achCompleted and "Completed" or (achieve.reward or "")
        local headerColor = achCompleted and COLOR_DIMMED or COLOR_HEADER
        local rewardColor = achCompleted and COLOR_DIMMED or COLOR_REWARD
        
        AddSafeDoubleLine(
            tooltip,
            achieve.name,
            rightText,
            headerColor,
            rewardColor
        )

        local incompletes = A:GetIncompleteCriteria(obj.achID, obj.criteriaID)
        for i = 1, #incompletes, 2 do
            local left  = incompletes[i]
            local right = incompletes[i+1]

            local leftText  = left  and (GetIconMarkup(left.icon or question)  .. " " .. left.family)   or ""
            local rightText = right and (right.family .. " " .. GetIconMarkup(right.icon or question)) or ""

            AddSafeDoubleLine(tooltip, leftText, rightText, COLOR_INCOMPLETE, COLOR_INCOMPLETE)
        end
        
    end

    for _, q in ipairs(quests) do addQuestLine(q) end
    for _, d in ipairs(directs) do addAchievementLine(d) end

    if (#quests > 0 or #directs > 0) and #metas > 0 then
        tooltip:AddLine(" ")
    end

    for _, m in ipairs(metas) do addMetaBlock(m) end

    if TomTom then
        tooltip:AddLine("Right-click to set a waypoint.", 1, 1, 1)
        tooltip:AddLine("Control-Right-click to set waypoints to every battle.", 1, 1, 1)
    end
    
end

-- Lira.DebugUI:RegisterHandler("PetDailies", PetDailies.TooltipHandlers)

function T:BuildFullTooltipDebug(mapID, coord, tooltip)
    tooltip = tooltip or GameTooltip

    local objectives = PetDailies.Data.Points[mapID] and PetDailies.Data.Points[mapID][coord]
    if not objectives then
        tooltip:AddLine("No objectives found")
        return
    end

    PetDailies.TooltipHandlers:BuildFullTooltip(objectives, tooltip)
end

function T:OnEnter(mapID, coord)

    local tooltip

    tooltip = GameTooltip
    tooltip:SetOwner(UIParent, "ANCHOR_CURSOR")

    --- @type Coordinate
	local objectives = PetDailies.Data.Points[mapID] and PetDailies.Data.Points[mapID][coord]
    if objectives  then

        -- if O:ShowCollapsedTooltip() then
        --     self:BuildCollapsedTooltip(objectives, tooltip)
        -- else
        self:BuildFullTooltip(objectives, tooltip)
        -- end
    else
        tooltip:SetText("No info")
    end
	tooltip:Show()
end

function T:OnLeave()
    GameTooltip:Hide()
end