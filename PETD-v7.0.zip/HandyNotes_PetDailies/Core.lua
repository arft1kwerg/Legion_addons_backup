
local _, PetDailies = ...

PetDailies = LibStub("AceAddon-3.0"):NewAddon(PetDailies, "HandyNotes_PetDailies", "AceConsole-3.0", "AceEvent-3.0")
PetDailies.Data = PetDailies.Data or {}
PetDailies.Services = PetDailies.Services or {}
PetDailies.Dispatcher = PetDailies.Dispatcher or {}

local Lira = LibStub("Lirameirav-1.0")
local currentExp = Lira.Expansion:Get(Lira.Expansion:GetVersion())
if currentExp then
    PetDailies.currentExpansion = currentExp
end
-- Lira.DebugUI:RegisterSlash("HandyNotes_PetDailies", "pd")
-- [[--------------------------------------------------------
-- End of initializing globals
-- -------------------------------------------------------]]


function PetDailies:OnInitialize()
    self.defaults = self.Services.Options:SetDefaults()

    local tempDB = LibStub("AceDB-3.0"):New("PetDailiesDB", self.defaults)
    self.db = tempDB.profile
   
    LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("HandyNotes_PetDailies", self.Services.Options:GetOptions())
    LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HandyNotes_PetDailies", "Pet Dailies")

    HandyNotes:RegisterPluginDB("HandyNotes_PetDailies", self.Dispatcher, PetDailies.Services.Options:GetOptions())

    hooksecurefunc(HandyNotesWorldMapPinMixin, "OnAcquired", function(pin, pluginName, iconpath, scale)
        if pluginName ~= "HandyNotes_PetDailies" then return end

        if not pin.countFS then
            local fs = pin:CreateFontString(nil, "OVERLAY", "NumberFontNormalHuge")
            fs:SetPoint("CENTER", pin, "CENTER", 0, 0)
            fs:SetDrawLayer("OVERLAY", 7)
            fs:SetTextColor(1, 1, 0, 1)
            pin.countFS = fs
        end

        -- Extract visibleCount from iconpath if it's a table, otherwise default to 0
        local visibleCount = 0
        if type(iconpath) == "table" and iconpath.count then
            visibleCount = iconpath.count
        end

        if visibleCount > 1 and scale > 0.9 then
            pin.countFS:SetText(visibleCount)
            pin.countFS:Show()
        else
            pin.countFS:Hide()
        end
    end)
end

function PetDailies:Refresh(_, _)
	self:SendMessage("HandyNotes_NotifyUpdate", "HandyNotes_PetDailies")
end

-- function PetDailies:handleSlashCommand(msg)
-- 	if (msg == "list") then
-- 		self:ToggleList()
-- 	end
-- end

--[[
    Toggles the visibility of the Pet Dailies UI.
    If the UI is initialized, it will be shown; otherwise, a message is printed.
]]
-- function PetDailies:ToggleList()
--     if self.UI then
--         self.UI:Show()
--     else
--         self:Print("UI is not initialized.")
--         -- Optionally, initialize self.UI here if you have a method for it, e.g.:
--         -- self.UI = self.Services.UI:Create()
--         -- self.UI:Show()
--     end
-- end


---@class PetDailiesAddon : AceAddon
---@field UI table
---@field db table
---@field Options table
---@field Handler table
---@field isEnabled boolean