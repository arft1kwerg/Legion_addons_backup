local _, PetDailies = ...

PetDailies.Services = PetDailies.Services or {}
PetDailies.Services.Points = PetDailies.Services.Points or {}
local S  = PetDailies.Services.Points
local P = PetDailies.Data.Points
local Lira = LibStub("Lirameirav-1.0")

function S:InitEvents()
    if self.eventFrame then return end

    local f = CreateFrame("Frame")
    self.eventFrame = f

    f:RegisterEvent("QUEST_TURNED_IN")
    f:RegisterEvent("ACHIEVEMENT_EARNED")
    f:RegisterEvent("CRITERIA_UPDATE")

    f:SetScript("OnEvent", function(_, event, arg1)
        if event == "QUEST_TURNED_IN" then
            self:RefreshByQuest(arg1)
        elseif event == "ACHIEVEMENT_EARNED" then
            self:RefreshByAchievement(arg1)
        else
            self:RefreshAll()
        end
        HandyNotes:SendMessage("HandyNotes_NotifyUpdate", "PetDailies")
    end)
end

---@param objectives Objective[] list of objectives at a coord
---@return string title
function S:GetPointTitle(objectives)
    
    local V = PetDailies.Services.Visibility
    if not objectives or #objectives == 0 then
        return "Unknown Objective"
    end

    local titles = {}

    for _, obj in ipairs(objectives) do
        if V:IsObjectiveVisible(obj) then
            table.insert(titles, obj.name or ("QuestID " .. obj.questID))
        end
    end

    if #titles == 0 then
        return "Hidden Objectives"
    elseif #titles == 1 then
        return titles[1]
    else
        return table.concat(titles, ", ")
    end
end

local ICON_QUESTIONMARK = PetDailies.Data.ICON_QUESTIONMARK
local ICON_COIN_COPPER = PetDailies.Data.ICON_COIN_COPPER

function S:GetObjectiveIcon(objective)
    if objective.icon then return objective.icon end

    if objective.achID then
        local _, _, _, _, _, _, _, _, _, iconFileID = GetAchievementInfo(objective.achID)
        return iconFileID or ICON_QUESTIONMARK
    elseif objective.questID then 
        return ICON_COIN_COPPER
    end
    return ICON_QUESTIONMARK
end

--- Required HandyNotes API: get node iterator for a map or continent
---@param mapID number
---@param minimap boolean true if icons are for the minimap
---@return function, table, number|nil
function S:Iterator(mapID, minimap)
    local V = PetDailies.Services.Visibility

    local nodes = P and P[mapID]

    return function(state, prestate)
        if not state then return nil end

        local coordKey, objectives = next(state, prestate)
        while coordKey do
            local ok, icon = V:ResolveIcon(objectives)
            if ok then
                return coordKey, mapID, icon, PetDailies.db.icon_scale, PetDailies.db.icon_alpha, objectives
            end

            coordKey, objectives = next(state, coordKey)
        end
    end, nodes, nil
end