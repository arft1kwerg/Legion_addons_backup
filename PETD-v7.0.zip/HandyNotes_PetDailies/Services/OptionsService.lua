local _, PetDailies = ...

PetDailies.Services = PetDailies.Services or {}
PetDailies.Services.Options = PetDailies.Services.Options or {}

local O = PetDailies.Services.Options
local AD = PetDailies.Data.Achievements
local OD = PetDailies.Data.Options
local A = PetDailies.Services.Achievement

local function BuildAchievementList()
    local Lira = LibStub("Lirameirav-1.0")
    local list = {}

    for achID, ach in pairs(AD) do
        local isSub = (ach.isMeta == 0) and A:IsSubAchievement(achID)
        if not isSub then
            table.insert(list, {
                achID     = tostring(achID),
                achName   = ach.name,
                expansion = ach.expansion,
                expName   = Lira.Expansion:GetFullName(ach.expansion),
            })
        end
    end

    Lira.Expansion:SortByExpansion(list, true)
    return list
end

-- Small helper to build the "Enable Expansion" toggle
local function BuildEnableToggle(expTag, expName)
    return {
        type  = "toggle",
        name  = "Enable " .. (expName or expTag),
        get   = function()
            local dbExp = PetDailies.db[expTag]
            return dbExp and dbExp.enabled
        end,
        set   = function(_, v)
            PetDailies.db[expTag] = PetDailies.db[expTag] or {}
            PetDailies.db[expTag].enabled = v
            PetDailies:Refresh()
        end,
        order = 1,
    }
end

-- Helper to build a single achievement toggle
local function BuildAchievementToggle(expTag, achID, achName)
    return {
        type  = "toggle",
        name  = achName,
        disabled = function()
            local dbExp = PetDailies.db[expTag]
            return not (dbExp and dbExp.enabled)
        end,
        get = function()
            return PetDailies.db[expTag] and PetDailies.db[expTag][achID]
        end,
        set = function(_, v)
            PetDailies.db[expTag] = PetDailies.db[expTag] or {}
            PetDailies.db[expTag][achID] = v
            PetDailies:Refresh()
        end,
        width = "full",
    }
end

-- Main grouping function now looks clean
local function GroupAchievements(list)
    local groups, order = {}, 10

    for _, entry in ipairs(list) do
        local expTag, expName, achID = entry.expansion, entry.expName, tostring(entry.achID)

        if not groups[expTag] then
            groups[expTag] = {
                type  = "group",
                name  = expName,
                order = order,
                args  = {
                    enabled  = BuildEnableToggle(expTag, expName),
                    achGroup = {
                        type   = "group",
                        name   = "Achievements",
                        inline = true,
                        order  = 2,
                        args   = {},
                    },
                },
            }
            OD[expTag] = groups[expTag]
            order = order + 1
        end

        groups[expTag].args.achGroup.args[achID] =
            BuildAchievementToggle(expTag, achID, entry.achName)
    end

    return groups
end


function O:GetOptions()

    local list   = BuildAchievementList()
    local groups = GroupAchievements(list)

    return {
        type = "group",
        name = "Pet Dailies",
        args = PetDailies.Data.Options
    }
end

function O:SetDefaults()
    local defs = {}

    local function collectDefaults(tbl, defsOut)
        for key, def in pairs(tbl) do
            if type(def) == "table" and (def.type == "toggle" or def.type == "range") then
            local dbKey = def.arg or key
            defsOut[dbKey] = def.default
            elseif type(def) == "table" and def.type == "group" and def.args then
                defsOut[key] = defsOut[key] or {}
                collectDefaults(def.args, defsOut[key])
            end
        end
    end
    
    collectDefaults(OD, defs)

    for id, ach in pairs(AD) do
        if ach.expansion then
            defs[ach.expansion] = defs[ach.expansion] or {}
            defs[ach.expansion][tostring(id)] = defs[ach.expansion][tostring(id)] or true
        end
    end

    return { profile = defs }
end

local Lira = LibStub("Lirameirav-1.0")

-- Internal helpers
local function isGlobalToggle(id)
    return id == "coins" or id == "completed" or id == "tooltipCollapsed"
end

local function isExpansionTag(id)
    return type(id) == "string" and PetDailies.db and PetDailies.db[id] and PetDailies.db[id].enabled ~= nil
end

local function isAchievementID(id)
    return type(id) == "number" and A[id] ~= nil
end

-- Unified check
---@param id number|string
---@return boolean
function O:IsEnabled(id)
    if not id or not PetDailies.db then return false end

    if isGlobalToggle(id) then
        return PetDailies.db[id] == true
    end

    if isExpansionTag(id) then
        return PetDailies.db[id].enabled == true
    end

    if isAchievementID(id) then
        local ach = A[id]
        local expTag = ach and ach.expansion
        if not expTag then return false end
        local dbExp = PetDailies.db[expTag]
        if not dbExp or not dbExp.enabled then return false end
        return dbExp[tostring(id)] == true
    end

    return true
end