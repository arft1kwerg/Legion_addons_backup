local _, PetDailies = ...

PetDailies.Services = PetDailies.Services or {}
PetDailies.Services.Visibility = PetDailies.Services.Visibility or {}
PetDailies.Services.Points = PetDailies.Services.Points or {}

local V = PetDailies.Services.Visibility
local P = PetDailies.Services.Points

local ICON_QUESTIONMARK = PetDailies.Data.ICON_QUESTIONMARK
local ICON_COIN_COPPER = PetDailies.Data.ICON_COIN_COPPER
local Lira = LibStub("Lirameirav-1.0")

---@param faction "horde"|"alliance"|"both"|nil
---@return boolean
local function MatchesFaction(faction)
    if not faction or faction == "both" then return true end
    local playerFaction = UnitFactionGroup("player")
    return string.lower(faction) == string.lower(playerFaction)
end

--- Determine visibility of the objective using all criteria
--- @param objective Objective
--- @return boolean
function V:IsObjectiveVisible(objective)
    local O = PetDailies.Services.Options
    local A = PetDailies.Services.Achievement
    if not MatchesFaction(objective.faction) then return false end
    if objective.icon == ICON_COIN_COPPER and not O:IsEnabled("coins") then return false end
    local completed = A:IsObjectiveCompleted(objective)
    if completed and not O:IsEnabled("completed") then return false end
    if objective.achID and not O:IsEnabled(objective.achID) then return false end

    return true
end

---@param objectives table[] list of objectives at a coord
---@return boolean
function V:IsPointVisible(objectives)
    if not objectives or #objectives == 0 then return false end
    for _, obj in ipairs(objectives) do
        if V:IsObjectiveVisible(obj) then
            return true
        end
    end
    return false
end

function V:ResolveIcon(objectives)
    if not objectives or #objectives == 0 then
        return false, nil
    end

    local iconFile
    local count = 0 
    for _, objective in ipairs(objectives) do
        local visible = self:IsObjectiveVisible(objective)
        if visible then
            count = count + 1
            iconFile = iconFile or P:GetObjectiveIcon(objective)
        end
    end

    if not iconFile then
        return false, nil
    end
    local db = PetDailies.db or {}
    local icon = {
        icon  = iconFile,
        scale = db.icon_scale or 1,
        alpha = db.icon_alpha or 1,
        count = count
    }

    return true, icon
end





---
---
---
---
---
-------- Haven't vetted, pasted for reference
---
---
---
---
---
---


--- Determines if the quest must be present in log or is implicitly visible
---@param questID number
---@param questIndex number
---@return boolean
local function isLogged(questID, questIndex)
	if questIndex > 0 and not PetDailies.MetasByID[questID] then
		local logIndex = C_QuestLog.GetLogIndexForQuestID(questID)
        return (logIndex or 0) > 0
    end
	return true
end