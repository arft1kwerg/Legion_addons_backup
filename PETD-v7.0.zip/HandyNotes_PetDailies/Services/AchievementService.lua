local _, PetDailies = ...

PetDailies.Services = PetDailies.Services or {}
PetDailies.Services.Achievement = PetDailies.Services.Achievement or {}

local S = PetDailies.Services.Achievement
local AD = PetDailies.Data.Achievements

local Lira = LibStub("Lirameirav-1.0")

---------------------------------------------------
-- Local helpers
---------------------------------------------------

--- Get incomplete criteria inside a normal (non-meta) achievement
--- @param achieveID number
--- @param criteriaIndex number
--- @return table[]
local function collectIncompleteBasic(achieveID, criteriaIndex)
    local results = {}
    local numCriteria = GetAchievementNumCriteria(achieveID)

    for idx = 1, numCriteria do
        local name, _, completed = GetAchievementCriteriaInfo(achieveID, idx)
        if not completed then
            table.insert(results, {
                family = name,
                icon   = AD[achieveID] and AD[achieveID].icon or nil,
            })
        end
    end

    return results
end

--- Get incomplete family sub-achievements for a given trainer
--- @param metaID number
--- @param criteriaID number
--- @param idxOfBattle number
--- @return table[]
local function collectIncompleteFamilies(metaID, criteriaID, idxOfBattle)
    local results = {}
    local numCriteria = GetAchievementNumCriteria(metaID)

    for idx = 1, numCriteria do
        local _, _, completed, _, _, _, _, subAchID = GetAchievementCriteriaInfo(metaID, idx)
        if not completed and subAchID then
            local _, familyName, _, _, _, _, _, _, _, familyIcon = GetAchievementInfo(subAchID)
            local _, _, subCompleted = GetAchievementCriteriaInfo(subAchID, idxOfBattle)

            if not subCompleted then
                table.insert(results, {
                    family = familyName,
                    icon   = familyIcon,
                })
            end
        end
    end

    return results
end

---------------------------------------------------
-- Services
---------------------------------------------------

--- Finds the index and name of a criteria inside an achievement by criteriaID.
--- @param achievementID integer|nil
--- @param criteriaID number
--- @param searchChildren boolean|nil whether to search sub-achievements (default false)
--- @return number|nil, string|nil, boolean|nil
function S:FindCriteriaInfo(achievementID, criteriaID, searchChildren)
    if not achievementID or not criteriaID then return nil end

    local numCriteria = GetAchievementNumCriteria(achievementID)
    if not numCriteria or numCriteria < 1 then return nil end
    if numCriteria == 1 then return 1, nil, false end

    for i = 1, numCriteria do
        local cName, _, _, _, _, _, _, assetID, _, cID = GetAchievementCriteriaInfo(achievementID, i)
        local isAchieve = select(1, GetAchievementInfo(assetID)) ~= nil

        if cID == criteriaID then
            return i, cName, isAchieve
        elseif searchChildren and isAchieve then
            local idx, name, childIsAchieve = self:FindCriteriaInfo(assetID, criteriaID, false)
            if idx then
                return idx, name, childIsAchieve
            end
        end
    end

    return nil, nil, nil
end

--- Return incomplete criteria/families for a given trainer inside a meta achievement
--- @param metaID number
--- @param criteriaID number
--- @return table[]
function S:GetIncompleteCriteria(metaID, criteriaID)
    if S:IsAchievementCompleted(metaID) then
        return {}
    end

    local idxOfBattle, _, isAchieve = self:FindCriteriaInfo(metaID, criteriaID, true)
    if not idxOfBattle then
        return {}
    end

    if isAchieve then
        return collectIncompleteFamilies(metaID, criteriaID, idxOfBattle)
    else
        return collectIncompleteBasic(metaID, idxOfBattle)
    end
end

--- Checks whether an objective is complete, without mutating state
--- @param objective Objective
--- @return boolean
function S:IsObjectiveCompleted(objective)
    if not objective then return false end

    if objective.achID then
        if self:IsAchievementCompleted(objective.achID) then
            return true 
        end  
        return S:IsCriteriaCompleted(objective.achID, objective.criteriaID) or false

    elseif objective.questID then
        return C_QuestLog.IsQuestFlaggedCompleted(objective.questID)
    end

    return false
end

--- Checks whether a specific criteria inside an achievement is complete
--- @param achievementID integer
--- @param criteriaID number
--- @return boolean|nil nil if not found
function S:IsCriteriaCompleted(achievementID, criteriaID)
    local numCriteria = GetAchievementNumCriteria(achievementID)
    if not numCriteria or numCriteria <= 0 then return nil end

    for i = 1, numCriteria do
        local _, _, completed, _, _, _, _, _, _, cID = GetAchievementCriteriaInfo(achievementID, i)
        if cID == criteriaID then
            return completed
        end
    end
    return nil
end

--- Check if an achievement is fully complete
--- @param achID number
--- @return boolean
function S:IsAchievementCompleted(achID)
    if not achID then return false end
    local _, _, _, completed = GetAchievementInfo(achID)
    return completed or false
end

function S:IsSubAchievement(childID)
    for parentID, parentAch in pairs(AD) do
        if parentAch.isMeta == 1 then
            local numCriteria = GetAchievementNumCriteria(parentID)
            for i = 1, numCriteria do
                local _, _, _, _, _, _, _, assetID = GetAchievementCriteriaInfo(parentID, i)
                if assetID == childID then
                    return true
                end
            end
        end
    end
    return false
end
