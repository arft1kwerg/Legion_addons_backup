local Lib = LibStub("Lirameirav-1.0")
Lib.Data = Lib.Data or {}
Lib.Data.Expansions = Lib.Data.Expansions or {}

---Register an expansion
---@param exp Expansion
local function addExpansion(exp)
    Lib.Data.Expansions.ByVersion[exp.majorVersion] = exp
    Lib.Data.Expansions.ByTag[exp.tag:lower()] = exp

end

addExpansion(Lib.Expansion:new{
    majorVersion = 1,
    fullName = "Classic Era",
    tag = "Classic",
    icon = 630785,
    maxSkill = 300,
    racialBonuses = {
        [202] = { spellID = 20593, bonus = 15 }, -- Engineering +15 (Gnome)
        [185] = { spellID = 107073, bonus = 15 }, -- Cooking +15
    },
    tiers = { 50, 75, 100, 150, 225, 300 },
})
--fullName = "Wrath of the Lich King"
--icon = 630787
--fullName = "Burning Crusade"
--icon = 630783

addExpansion(Lib.Expansion:new{
    majorVersion = 4,
    fullName = "Cataclysm Classic",
    tag = "Cata",
    icon = 630784,
    maxSkill = 525,
    racialBonuses = {
        [202] = { spellID = 20593, bonus = 15 }, -- Engineering +15 (Gnome)
        [171] = { spellID = 69045, bonus = 15 }, -- Alchemy +15 (Goblin, Cata only)
        [185] = { spellID = 107073, bonus = 15 }, -- Cooking +15
        [333] = { spellID = 28877, bonus = 10 }, -- Enchanting +10
        [755] = { spellID = 28875, bonus = 10 }, -- Jewelcrafting +10
    },
    tiers = { 50, 75, 100, 150, 225, 300, 375, 450, 525 },
})

addExpansion(Lib.Expansion:new{
    majorVersion = 5,
    fullName = "Mists of Pandaria",
    tag = "MoP",
    icon = 630786,
    maxSkill = 600,
    racialBonuses = {
        [202] = { spellID = 20593, bonus = 15 }, -- Engineering +15 (Gnome)
        [171] = { spellID = 69045, bonus = 15 }, -- Alchemy +15 (Goblin, Cata only)
        [185] = { spellID = 107073, bonus = 15 }, -- Cooking +15
        [333] = { spellID = 28877, bonus = 10 }, -- Enchanting +10
        [755] = { spellID = 28875, bonus = 10 }, -- Jewelcrafting +10
    },
    tiers = { 50, 75, 100, 150, 225, 300, 375, 450, 525, 600 },
})

addExpansion(Lib.Expansion:new{
    majorVersion = 6,
    fullName = "Warlords of Draenor",
    tag = "WoD",
    icon = 2838050
})
addExpansion(Lib.Expansion:new{
    majorVersion = 7,
    fullName = "Legion",
    tag = "Legion"
})
addExpansion(Lib.Expansion:new{
    majorVersion = 8,
    fullName = "Battle for Azeroth",
    tag = "BfA",
    maxSkill = 175,
    tiers = { 25, 50, 75, 100, 125, 150, 175 },
})

addExpansion(Lib.Expansion:new{
    majorVersion = 9,
    fullName = "Shadowlands",
    tag = "SL",
    maxSkill = 100,
    tiers = { 25, 50, 75, 100 },
})

addExpansion(Lib.Expansion:new{
    majorVersion = 10,
    fullName = "Dragonflight",
    tag = "DF",
    maxSkill = 100,
    tiers = { 25, 50, 75, 100 },
})

addExpansion(Lib.Expansion:new{
    majorVersion = 11,
    fullName = "The War Within",
    tag = "TWW",
    maxSkill = 100,
    tiers = { 25, 50, 75, 100 },
})