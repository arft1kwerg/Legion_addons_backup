local Lib = LibStub("Lirameirav-1.0")

Lib.Data = Lib.Data or {}
Lib.Data.Expansions = Lib.Data.Expansions or {
    ByVersion = {},
    ByTag = {},
}