---@class Expansion
---@field fullName string
---@field tag string
---@field majorVersion number
---@field maxSkill number
---@field racialBonuses table<number, table>
---@field tiers number[]

local Lib = LibStub("Lirameirav-1.0")
Lib.Expansion.__index = Lib.Expansion

---Constructor with defaults
---@param opts table
---@return Expansion
function Lib.Expansion:new(opts)
    local obj = {
        fullName = opts.fullName or "Unknown Expansion",
        tag = opts.tag or "Unknown",
        majorVersion = opts.majorVersion or 0,
        maxSkill = opts.maxSkill or 0,
        icon = opts.icon or 0,
        racialBonuses = opts.racialBonuses or {},
        tiers = opts.tiers or {},
    }
    return setmetatable(obj, self)
end

-- =========================
-- Convenience Methods
-- =========================

---Get expansion object by major version or tag
---@param exp number|string
---@return Expansion|nil
function Lib.Expansion:Get(exp)

    local tags = Lib.Data.Expansions.ByTag
    local vers = Lib.Data.Expansions.ByVersion

    if type(exp) == "number" then
        return vers[exp]
    elseif type(exp) == "string" then
        return tags[exp:lower()]
    else
        return nil
    end
end

---Get all expansions as a table indexed by major version
---@return table<number, Expansion>
function Lib.Expansion:GetAll()

    return Lib.Data.Expansions.ByVersion
end

---Get full name by major version or tag
---@param exp number|string
---@return string|nil
function Lib.Expansion:GetFullName(exp)
    if Lib.Data.Expansions == nil then
        print("|cffff0000[LibLirameiravCore]|r No expansions registered.")
        return nil
    end
    if Lib.Data.Expansions.ByTag == nil then
        print("|cffff0000[LibLirameiravCore]|r No expansions registered by tag.")
        return nil
    end
    if Lib.Data.Expansions.ByVersion == nil then
        print("|cffff0000[LibLirameiravCore]|r No expansions registered by version.")
        return nil
    end

    local tags = Lib.Data.Expansions.ByTag
    local vers = Lib.Data.Expansions.ByVersion

    if type(exp) == "number" then
        return vers[exp].fullName
    elseif type(exp) == "string" then
        return tags[exp:lower()].fullName
    else
        return nil
    end
end

---Sorts a list of objects that have a `.expansion` field using expansion.major
---@param tbl table<any, {expansion:string}>
---@param descending boolean|nil
function Lib.Expansion:SortByExpansion(tbl, descending)
    local tags = Lib.Data.Expansions.ByTag
    local vers = Lib.Data.Expansions.ByVersion


    table.sort(tbl, function(a, b)
        local ea, eb
        if type(a.expansion) == "number" then
            ea = vers[a.expansion]
            eb = vers[b.expansion]
        elseif type(a.expansion) == "string" then
            ea = tags[a.expansion:lower()]
            eb = tags[b.expansion:lower()]
        end
        
        local majorA = ea and ea.majorVersion or 0
        local majorB = eb and eb.majorVersion or 0

        if descending then
            return majorA > majorB
        else
            return majorA < majorB
        end
    end)
end

---Get racial bonus for a profession
---@param professionID number
---@return number|nil, number|nil
function Lib.Expansion:GetRacialBonus(professionID)
    local bonus = self.racialBonuses[professionID]
    if bonus then return bonus.spellID, bonus.bonus
    else return nil, nil end
end

---Get the tier breakpoints for this expansion
---@return number[]
function Lib.Expansion:GetTierLevels()
    return self.tiers
end


---Get the current WoW major version from GetBuildInfo
---@return number|nil
function Lib.Expansion:GetVersion()
    local buildVersion = GetBuildInfo()
    return buildVersion and tonumber(buildVersion:match("^%d+")) or nil
end

---Check if current WoW client version has a registered expansion
---@return boolean
function Lib.Expansion:IsSupported()
    local version = self:GetVersion()
    if not version then
        print("|cffff0000[LibLirameiravCore]|r Unable to detect WoW client version.")
        return false
    end
    if self.All[version] then
        return true
    end
    print("|cffff0000[LibLirameiravCore]|r Unsupported WoW version:", version)
    return false
end