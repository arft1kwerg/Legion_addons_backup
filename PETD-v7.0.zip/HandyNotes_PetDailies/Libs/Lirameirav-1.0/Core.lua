local MAJOR, MINOR = "Lirameirav-1.0", 1
local Lib = LibStub:NewLibrary(MAJOR, MINOR)
if not Lib then return end

Lib.Data = Lib.Data or {}
Lib.Utils = Lib.Utils or {}
Lib.Expansion = Lib.Expansion or {}