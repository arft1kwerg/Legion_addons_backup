-- $Id: ruRU.lua 27 2017-05-14 14:37:20Z arith $

local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_SuramarShalAranTelemancy", "ruRU", false)

if not L then return end

if L then
L["AddOn Settings"] = "Настройки модификации"
L["Entrance"] = "Вход"
L["Entrance of %s"] = "Вход в %s"
L["Fountain"] = "Фонтан"
L["Garden"] = "Сад"
L["Great Eagle"] = "Большой орел"
L["HandyNotes - Suramar & Shal'Aran Telemancy"] = "HandyNotes - Телемантические маяки Сурамара и Шал'Арана"
L["Icon Alpha"] = "Прозрачность значков"
L["Icon Scale"] = "Масштаб значков"
L["Icon settings"] = "Настройки значков"
L["Ignore in-/out-door"] = "Игнорировать внутри/снаружи"
L["Ignore whether it is currently indoor or outdoor, show all nodes."] = "Игнорировать то, находится ли он внутри или снаружи, показывать все значки."
L["Leyline Entrances"] = "Входы к силовым каналам"
L["Library"] = "Библиотека"
L["Outside of The Drift"] = "Снаружи Дрейфа"
L["Portal"] = "Портал"
L["Portal to %s"] = "Портал в %s"
L["Query from server"] = "Запрашивать с сервера"
L["Reset hidden nodes"] = "Сбросить скрытые значки"
L["Send query request to server to lookup NPC's localized name. May be a little bit slower for the first time lookup but would be very fast once the name is found and cached."] = "Отправлять запрос серверу для поиска локализованного имени. Может быть слегка медленным при первом поиске, но будет очень быстрым после того, как имя будет найдено и сохранено в кэше."
L["Shal'Aran Portals"] = "Порталы Шал'Арана"
L["Show all nodes that you manually hid by right-clicking on them and choosing \"hide\"."] = "Показать все значки, которые вы скрыли вручную, нажав на них правой кнопкой мыши и выбрав \"скрыть\"."
L["Show entrances which lead to the leyline."] = "Показать входы, которые ведут к силовым каналам."
L["Show note"] = "Показать заметку"
L["Show portals inside Shal'Aran."] = "Показать порталы внутри Шал'Арана."
L["Show Telemetry Lab related telemancies, mainly quest related from Oculeth's quest: \"The Delicate Art of Telemancy\"."] = "Показывает телемантические маяки Лаборатории телеметрии, связанные с заданием Окулета \"Тонкое искусство телемантии\"."
L["Show the entrances which are not specified more precisely."] = "Показать входы, которые не указаны более точно."
L["Show the entrances which lead to known caves or space."] = "Показать входы, которые ведут к известным пещерам или местам."
L["Show the node's additional notes when it's available."] = "Показывать дополнительные заметки к значку, когда они доступны."
L["Shows the telemancy between Shal'Aran and nodes in Suramar"] = "Показывает телемантические маяки между Шал'Араном и Сурамаром"
L["Specified Entrances"] = "Известные входы"
L["Storage"] = "Хранилище"
L["Suramar & Shal'Aran Telemancy"] = "Телемантические маяки Сурамара и Шал'Арана"
L[ [=[Telemancy to: 
  - Garden]=] ] = [=[Телемантический маяк: 
- Сад]=]
L[ [=[Telemancy to: 
  - Storage]=] ] = [=[Телемантический маяк: 
- Хранилище]=]
L[ [=[Telemancy to: 
  o Fountain]=] ] = [=[Телемантический маяк: 
- Фонтан]=]
L[ [=[Telemancy to: 
  o Fountain
  o Warp Lab
  - Library]=] ] = [=[Телемантический маяк: 
o Фонтан
o Лаборатория искажений
- Библиотека]=]
L[ [=[Telemancy to: 
  o Garden
  - Test Chamber]=] ] = [=[Телемантический маяк: 
o Сад
- Зал испытаний]=]
L[ [=[Telemancy to: 
  o Telemetry Lab
  o Garden
  x Breakfast Nook]=] ] = [=[Телемантический маяк: 
o Лаборатория телеметрии
o Сад
x Столовая]=]
L[ [=[Telemancy to: 
  o Workshop]=] ] = [=[Телемантический маяк: 
o Мастерская]=]
L["Telemetry Lab"] = "Лаборатория телеметрии"
L["Teleportation Nexus"] = "Нексус телепортации"
L["The alpha transparency of the icons"] = "Альфа-прозрачность значков"
L["The scale of the icons"] = "Масштаб значков"
L["These settings control the look and feel of the icon."] = "Эти настройки управляют внешним видом значков."
L["These settings control what type of icons to be displayed."] = "Эти настройки управляют типами значков, которые будут отображаться на карте мира и на миникарте."
L["Unspecified Entrances"] = "Неизвестные входы"
L["Warp Lab"] = "Лаборатория искажений"
L["What to display"] = "Что показывать"

end
