local addonName, data = ...
local frame = CreateFrame("Frame", addonName, UIParent, "BasicFrameTemplateWithInset")

local speciesBaseStats = data.speciesBaseStats
local speciesBreeds = data.speciesBreeds
local quality = data.quality
local battlePetBreedState = data.battlePetBreedState
local highestSpeciesId = data.highestSpeciesId
local allBreeds = data.allBreeds
local session = {}

frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event, ...)
  print("|cff00ff00[" .. addonName .. "]|r For the website import, type |cffffff00/xufu|r")
  --print("|cff00ff00[" .. addonName .. "]|r Open the addon with: |cffffff00/xufu|r \n For a more detailed pet collection export, type |cffffff00/exportpets|r.")
    
end)


frame:SetSize(580, 400)
frame:SetPoint("CENTER")
frame:Hide() 
tinsert(UISpecialFrames, addonName) 

frame.title = frame:CreateFontString(nil, "OVERLAY")
frame.title:SetFontObject("GameFontHighlight")
frame.title:SetPoint("TOP", frame, "TOP", 0, -5)
frame.title:SetText("Xu-Fu Pet Import")

frame.scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
frame.scrollFrame:SetSize(520, 300)
frame.scrollFrame:SetPoint("TOP", frame, "TOP", 0, -40)

frame.editBox = CreateFrame("EditBox", nil, frame.scrollFrame)
frame.editBox:SetMultiLine(true)
frame.editBox:SetFontObject("ChatFontNormal")
frame.editBox:SetSize(500, 400) 
frame.editBox:SetAutoFocus(true)
frame.editBox:SetTextInsets(0, 0, 0, 0)
frame.editBox:SetPoint("TOPLEFT", frame.scrollLabel, "BOTTOMLEFT", 0, -5)

frame.editBox:SetScript("OnEscapePressed", function(self)
  self:ClearFocus()
  frame.scrollFrame:Hide()
end)

frame.scrollFrame:SetScrollChild(frame.editBox)

frame.scrollLabel = frame.scrollFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.scrollLabel:SetFont("Fonts\\FRIZQT__.TTF", 16)
frame.scrollLabel:SetTextColor(1.0, 0.82, 0.0)
frame.scrollLabel:SetPoint("BOTTOM", frame, "BOTTOM", 20, 20)
frame.scrollLabel:SetText("Press Ctrl + C to copy")

local function formatListWithOr(l)
  local len = #l
  if len == 2 then
        return l[1] .. " or " .. l[2]
    else
        local result = ""
        for i = 1, len - 1 do
            result = result .. l[i]
            if i < len - 1 then
                result = result .. ", "
            else
                result = result .. " or "
            end
        end
        result = result .. l[len]
        return result
    end
end

local function round(num)
  return math.floor(num + 0.5)
end



local function GetBreed(maxHealth, power, speed, rarity, level, speciesID, name)
  -- basestats are mandatory!
  if not speciesBaseStats[speciesID] then
    print("|cff00ff00[" .. addonName .. "]|r Missing baseStats Data: " .. name .. "(" .. speciesID .. ")")
    return "N/A"
  end

  local breed = {}
  local possibleBreeds = speciesBreeds[speciesID] or allBreeds
  local baseStatsHealth = speciesBaseStats[speciesID][1]
  local baseStatsPower = speciesBaseStats[speciesID][2]
  local baseStatsSpeed = speciesBaseStats[speciesID][3]

  local function checkBreeds(breedsToCheck)
    for i = 1, #breedsToCheck do
      if breedsToCheck[i] then
        local h = round(((baseStatsHealth + battlePetBreedState[breedsToCheck[i]][1]) * (5 * level * quality[rarity]) / 100 + 100))
        local p = round(((baseStatsPower  + battlePetBreedState[breedsToCheck[i]][2]) * (level * quality[rarity]) / 100))
        local s = round(((baseStatsSpeed  + battlePetBreedState[breedsToCheck[i]][3]) * (level * quality[rarity]) / 100))
        if h == tonumber(maxHealth) and p == tonumber(power) and s == tonumber(speed) then      
          table.insert(breed, breedsToCheck[i])
        end
      end
    end
  end

  checkBreeds(possibleBreeds)

  -- retry if breed data is incomplete or Blizzard changed breeds in Classic
  if #breed == 0 then
    checkBreeds(allBreeds)
  end

  local UnknownBreedText = "|cff00ff00[" .. addonName .. "]|r Unknown Breed: " .. name .. "(" .. speciesID .. ") => " .. maxHealth .. "/" .. power .. "/" .. speed

  -- if basestats are wrong
  if #breed == 0 then
    print(UnknownBreedText .. " error" )
  end

  if #breed == 1 then
    return breed[1]
  end
  
  if #breed > 1 then
    local breeds = breed
    print(UnknownBreedText .. " " .. formatListWithOr(breeds))
    --return breeds[1] .. "||" .. breeds[2]
  end

  return "N/A"
end

local function CsvSafe(txt)
    if string.find(txt, ",") then
        return '"' .. txt .. '"'
    else
        return txt
    end
end

function session:GetPetList()
  local petList = ""
  if self.isXufu or self.isExportPets then
    petList = "speciesID,name,level,petType,rarity,breed"
    if self.isExportPets then
      petList = petList .. ",creatureID,source,collected,wild,battle,tradeable,unique"
    end
    petList = petList .. "\n"
  end
  if self.isAranesh then 
    petList = "speciesID,maxCopies,possibleBreeds\n"
  end

  if self.isAranesh or self.isExportPets then  
    for speciesID=1, highestSpeciesId do
      local isObtainable = select(11,C_PetJournal.GetPetInfoBySpeciesID(speciesID))
      if isObtainable ~= nil then
        self.countAllSpecies = self.countAllSpecies + 1
        if isObtainable then
          self.speciesIdCollected[speciesID] = false
          self.countObtainable = self.countObtainable + 1
          if self.isAranesh then
            local isUnique = select(10,C_PetJournal.GetPetInfoBySpeciesID(speciesID))
            local canBattle = select(8,C_PetJournal.GetPetInfoBySpeciesID(speciesID))
            --petList = (petList == "") and petList .. speciesID or petList .. "," .. speciesID
            local maxCopies = isUnique and 1 or 3
            local possibleBreeds = "N/A"
            if speciesBreeds[speciesID] then
              possibleBreeds = '"' .. table.concat(speciesBreeds[speciesID], ",") .. '"'
            end
            petList = petList  .. speciesID .. "," .. maxCopies .. "," .. possibleBreeds .. "\n"
          end
        end
      end
    end
  end

  if self.isXufu or self.isExportPets then

    local numPets = C_PetJournal.GetNumPets()
    for i=1,numPets do  
        local petID, speciesID, owned, _, level, _, _, name, _, petType, creatureID, sourceText, _, isWild, canBattle, isTradeable, isUnique, isObtainable = C_PetJournal.GetPetInfoByIndex(i)
        
        if isObtainable then
          local name = CsvSafe(name)
          local wild = isWild  and "Yes" or "No"
          local battle = canBattle and "Yes" or "No"
          local tradeable = isTradeable and "Yes" or "No"
          local unique = isUnique  and "Yes" or "No"
          local source = sourceText:match("|c%x%x%x%x%x%x%x%x(.-):") or sourceText:match("|c%x%x%x%x%x%x%x%x(.-)|r") or "N/A"
          local collected = "Yes"
                            
          if petID then
            self.speciesIdCollected[speciesID] = true
            local _, maxHealth, power, speed, rarity = C_PetJournal.GetPetStats(petID)    
            local racial = self.isXufu and petType or _G["BATTLE_PET_NAME_" .. petType]
            local quality = self.isXufu and rarity or _G["BATTLE_PET_BREED_QUALITY" .. rarity]
            local breed = GetBreed(maxHealth, power, speed, rarity, level, speciesID, name)

            petList = petList .. speciesID .. "," .. name .. "," .. level 
              .. "," .. racial .. "," .. quality ..  "," ..  breed

            if self.isExportPets then
              petList = petList .. "," .. creatureID .. "," .. source .. "," .. collected .. "," 
                .. wild .. "," .. battle .. "," .. tradeable .. "," .. unique
            end

            petList = petList .. "\n"

          end 
        end
    end

    if self.isExportPets then
      for speciesID, isCollected in pairs(self.speciesIdCollected) do
          if not isCollected then
            local name, _, petType, creatureID, sourceText, _, isWild, canBattle, isTradeable, isUnique = C_PetJournal.GetPetInfoBySpeciesID(speciesID)
            local racial = _G["BATTLE_PET_NAME_" .. petType]
            local level, quality, breed, collected = "N/A", "N/A", "N/A", "No"
            local name = CsvSafe(name)
            local wild = isWild  and "Yes" or "No"
            local battle = canBattle and "Yes" or "No"
            local tradeable = isTradeable and "Yes" or "No"
            local unique = isUnique  and "Yes" or "No"
            local source = sourceText:match("|c%x%x%x%x%x%x%x%x(.-):") or sourceText:match("|c%x%x%x%x%x%x%x%x(.-)|r") or "N/A"
            petList = petList .. speciesID .. "," .. name .. "," .. level .. "," .. racial .. "," 
              .. quality ..  "," ..  breed .. "," .. creatureID .. "," .. source .. "," .. collected 
              .. "," .. wild .. "," .. battle .. "," .. tradeable .. "," .. unique .. "\n"
          end
      end
    end

  end

  return petList
end


local function ResetPetJournalFilters()   
    local filters = {
        LE_PET_JOURNAL_FILTER_COLLECTED,
        LE_PET_JOURNAL_FILTER_NOT_COLLECTED,
    }
    for _, filter in ipairs(filters) do
        C_PetJournal.SetFilterChecked(filter, true)
    end

    C_PetJournal.SetSearchFilter("")

    C_PetJournal.SetAllPetSourcesChecked(true)

    C_PetJournal.SetAllPetTypesChecked(true)
end


SLASH_XUFU1 = "/xufu"
SLASH_EXPORTPETS1 = "/exportpets"
SLASH_ARANESH1 = "/aranesh"

SlashCmdList["XUFU"] = function()
  frame:HandleCommand("xufu")
end

SlashCmdList["EXPORTPETS"] = function()
  frame:HandleCommand("exportpets")
end

SlashCmdList["ARANESH"] = function()
  frame:HandleCommand("aranesh")
end



function frame:HandleCommand(cmd)
  session.isXufu = (cmd == "xufu")
  session.isAranesh = (cmd == "aranesh")
  session.isExportPets = (cmd == "exportpets")
  session.speciesIdCollected = {}
  session.countObtainable = 0
  session.countAllSpecies = 0
  session.countTest = 0

  if frame:IsShown() then
    frame:Hide()
  else
    frame.scrollFrame:Hide()
    frame:Show()
  end
  ResetPetJournalFilters()

  local formattedPetList = session:GetPetList()
  frame.editBox:SetText(formattedPetList)
  frame.editBox:HighlightText()
  frame.scrollFrame:Show()
  if session.isAranesh then
    print("|cff00ff00[" .. addonName .. "]|r Maximum number of unique pets you can own: " .. session.countObtainable)
  end

end

