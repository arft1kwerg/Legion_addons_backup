-- Daily Global Check - World Bosses plugin
-- Jadya EU-Well of Eternity

local addonName, addonTable = ...
 
local questsdata = {}

-- legion questIDs
local legion_wq    = "multipleor#43193_43985_43448_43192_42270_42779_42269_44287_42819_43513"
local legion_loot  = "multipleor#44506_44511_44502_44503_44504_44509_44505_44510_44507"
local legion_bloot = "multipleor#44906_44897_44898_44899_44904_44900_44905_44902_44901"

local list = {
 ["Title"] = "World Bosses",
 ["Icon"]  = "Interface\\Icons\\Ability_Monk_LeeroftheOx",
 ["Version"] = 1004,
 ["Order"] = {{{"7.0",legion_wq, legion_loot, legion_bloot},
               {"6.2",39380},
			   {"6.0",37464,37462,37460},
               {GARRISON_LANDING_INVASION,37638,37639,37640,38482,38276}},
              {{"5.0",32099,32098},
               {"5.2",32518,32519},
               {"5.4",33117,33118}},
			 }
}

local function GenerateData()
 local Z = DailyGlobalCheck.Z
 -- legion
 questsdata[legion_wq]    = {"","Legion World Boss ".."("..WORLD_QUEST_BANNER..")",nil,nil,nil,nil,3}
 questsdata[legion_loot]  = {"","Legion World Boss ".."("..LOOT..")",nil,nil,nil,nil,3, [12] = true}
 questsdata[legion_bloot] = {"","Legion World Boss ".."("..BONUS_LOOT_LABEL..")",nil,nil,nil,nil,3, [12] = true}

 questsdata[39380] = {Z[945],EJ_GetEncounterInfo(1452),"|TInterface\\EncounterJournal\\UI-EJ-BOSS-SupremeLordKazzak:12|t" ,nil,{945,47.1,21.5},nil,3}
 questsdata[37464] = {Z[948],EJ_GetEncounterInfo(1262),"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Rukhmar:12|t"           ,nil,{948,34.5,36.2},nil,3}
 questsdata[37462] = {Z[949],EJ_GetEncounterInfo(1211),"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Tarlna The Ancient:12|t",nil,{949,46,86}    ,nil,3}
 questsdata[37460] = {Z[949],EJ_GetEncounterInfo(1291),"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Drov the Ruiner:12|t"   ,nil,{949,44,40}    ,nil,3}
 questsdata[32098] = {Z[807],EJ_GetEncounterInfo(725) ,"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Chief Salyis:12|t"       ,nil,{807,70,63}    ,nil,3}
 questsdata[32099] = {Z[809],EJ_GetEncounterInfo(691) ,"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Sha of Anger:12|t"       ,nil,{809,51,87}    ,nil,3}
 questsdata[32519] = {Z[929],EJ_GetEncounterInfo(826) ,"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Oondasta:12|t"           ,nil,{929,50,54}    ,nil,3}
 questsdata[32518] = {Z[928],EJ_GetEncounterInfo(814) ,"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Nalak:12|t"              ,nil,{928,61,36}    ,nil,3}
 questsdata[33118] = {Z[951],EJ_GetEncounterInfo(861) ,"|TInterface\\EncounterJournal\\UI-EJ-BOSS-Ordos:12|t"              ,nil,{951,54,20}    ,nil,3}
 questsdata[33117] = {Z[951],select(2, GetAchievementInfo(8535)),"|TInterface\\Icons\\INV_CelestialSerpentMount:12|t"     ,nil,{951,38,55},nil,3}

 -- Invasions
 questsdata[37638] = {GARRISON_LOCATION_TOOLTIP,"Bronze"   ,nil,nil,nil,nil,3}
 questsdata[37639] = {GARRISON_LOCATION_TOOLTIP,"Silver"   ,nil,nil,nil,nil,3}
 questsdata[37640] = {GARRISON_LOCATION_TOOLTIP,"Gold"     ,nil,nil,nil,nil,3}
 questsdata[38482] = {GARRISON_LOCATION_TOOLTIP,"Platinum" ,nil,nil,nil,nil,3}
 questsdata[38276] = {GARRISON_LOCATION_TOOLTIP,"Raid boss",nil,nil,nil,nil,3}
end

list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)
