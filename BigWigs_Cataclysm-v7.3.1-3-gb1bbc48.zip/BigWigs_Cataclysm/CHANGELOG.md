# BigWigs [Cataclysm]

## [v7.3.1-3-gb1bbc48](https://github.com/BigWigsMods/BigWigs_Cataclysm/tree/b1bbc4852220a9907d4a0a1c75a2e7bc1a8c6b09) (2018-07-17)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_Cataclysm/compare/v7.3.1...b1bbc4852220a9907d4a0a1c75a2e7bc1a8c6b09)

- Update colors and sounds  
- Fixes  
- Update for UnitBuff/UnitDebuff  
