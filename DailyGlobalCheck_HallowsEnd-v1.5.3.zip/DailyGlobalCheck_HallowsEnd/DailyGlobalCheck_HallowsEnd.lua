-- Daily Global Check - Hallow's End
-- Vildiesel EU-Well of Eternity

local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z

local plugintitle = "Hallow's End"
local pluginicon = "Interface\\Icons\\INV_Misc_Bag_28_Halloween"

local questsdata = {}

local function isquestcompleted(questID)
 if questID == "12404a" or questID == "12404b" or questID == "12409a" or questID == "12409b" then
  local tmp = questID:gsub("(%a)", "")
  return IsQuestFlaggedCompleted(tonumber(tmp))
 elseif questID == "headless" then
  local _, _, completed = GetLFGDungeonRewardCapBarInfo(285)
  return completed == 1 and true or false
 end
end

local list = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = { 
               { -- page 1
			   {DAILY},
			   },
               { -- page 2
               {"Candy Buckets "..Z[13],12398,28993,28994,12400,29014,12399,29018,12401,12396,28999,29001,29000,29016,29017},
			   },
			   {-- page 3
			   {"Candy Buckets "..Z[14],12402,28965,28955,28967,12397,28981,28982},
			   },
			   {-- page 4
			   {"Candy Buckets "..Z[466],12408,12407,12403,"12404a","12404b","12409a","12409b",12406},
			   },
			   {-- page 5
			   {"Candy Buckets "..Z[485],12941,12940,12950,13461,13462,13452,13456,13459,13472,13463,13460},
			   },
			   {-- page 6
			   {"Candy Buckets "..Z[862],32024,32023,32027,32029,32032,32031,32021,32034,32036,32039,32041,32037,32051,32026,32043,32044,32048,32046},
			   },
             },
 }

local function setup_faction_orders()
 local faction = DailyGlobalCheck.player_faction and DailyGlobalCheck.player_faction or UnitFactionGroup("player")
 
 local o = list["Order"]

 if faction == "Alliance" then
  o[1][1] = {"","headless"}
  o[1][2] = {"Requires Creepy Crawlers Decoration" ,39617}
  o[1][3] = {DAILY,39716,39719,39720,39721,11131,12133,29054,29144,29075,29371,43162}
  -- kalimdor
  o[2][2] = {"",29006,29007,29008,12349,12350,28952,12348,12347,29010,29011,29013,29012,12345,28995,28951,12334,12331,12341,12333,12337}
  -- eastern kingdoms
  o[3][2] = {"",28988,12351,28970,28990,12343,28991,12339,28963,12332,12335,28956,12336,12286,12342,28968,28960,28961,12344,12340,28964,28954,28978,28977,28980,28979,28983,28985,}
  -- outland
  o[4][2] = {"",12359,12358,12355,12354,12353,12352,12360,12356,12357}
  -- northrend
  o[5][2] = {"",13437,13436,13473,13438,13439,12944,12945,13435,13433,13434,13448}
  -- pandaria
  o[6][2] = {"",32049,32033,32042,32052}
 elseif faction == "Horde" then
  o[1][1] = {"","headless"}
  o[1][2] = {"Requires Creepy Crawlers Decoration" ,39617}
  o[1][3] = {DAILY,39716,39719,39720,39721,11219,12155,29374,29375,29377,29376}
  -- kalimdor
  o[2][2] = {"",28989,28958,28953,12377,28992,12383,12381,12386,28998,28996,29005,29004,12362,12367,12378,29009,29003,29002,12374,12361,12366}
  -- eastern kingdoms
  o[3][2] = {"",12369,12370,12364,12365,12373,28987,28972,12363,12368,28966,12371,12376,28962,28971,12387,12380,28957,12384,28959,12382,28969,28974,28973,28976,28975,28984,28986,}
  -- outland
  o[4][2] = {"",12394,12393,12390,12388,12389,12392,12391,12395}
  -- northrend
  o[5][2] = {"",13548,13471,13466,13465,13464,12946,13947,13470,13469,13474,13468,13501,13467}
  -- pandaria
  o[6][2] = {"",32028,32050,32020,32047,32040,32022}
 end
end
 
local function show_aldor()
 local _, _, standingInfo = GetFactionInfoByID(932)
 return standingInfo == 0 or standingInfo >= 4
end
 
local function show_scryers()
 local _, _, standingInfo = GetFactionInfoByID(934)
 return standingInfo == 0 or standingInfo >= 4
end

local function GenerateQuestsData()
 local l = DailyGlobalCheck.LocalizeSection
 local achi = GetAchievementCriteriaInfo

 local faction = DailyGlobalCheck.player_faction and DailyGlobalCheck.player_faction or UnitFactionGroup("player")
 
 if faction == "Alliance" then 
  -- Dailies
  questsdata[39617] = {Z[971], "Arachnis",nil,nil,{971, 71.9, 37.1}}-- Requires Creepy Crawlers Decoration
  questsdata[39716] = {Z[971], l(questsdata, 39716, 2, "Smashing Squashlings", "quest", 39716)}
  questsdata[39719] = {Z[971], l(questsdata, 39719, 2, "Mutiny on the Boneship", "quest", 39719)}
  questsdata[39720] = {Z[971], l(questsdata, 39720, 2, "Foul Fertilizer", "quest", 39720)} 
  questsdata[39721] = {Z[971], l(questsdata, 39721, 2, "Culling the Crew", "quest", 39721)} 
  questsdata[11131] = {Z[30] , l(questsdata, 11131, 2, "Stop the Fires!", "quest", 11131)} -- 12135 let-the-fires-come
  questsdata[12133] = {Z[30] , l(questsdata, 12133, 2, "Smash the Pumpkin", "quest", 12133)}
  --questsdata[29054] = {Z[30] , achi(1040,2), nil} -- stink bombs away
  --questsdata[29144] = {Z[30] , achi(1040,1), nil} -- clean up in stormwind
  --questsdata[29075] = {Z[30] , achi(1040,3), nil} -- a time to gain
  --questsdata[29371] = {Z[30] , achi(1040,4), nil} -- a time to lose
  questsdata[29054] = {Z[30] , "Stink Bombs Away", nil} -- stink bombs away
  questsdata[29144] = {Z[30] , "Clean up in Stormwind", nil} -- clean up in stormwind
  questsdata[29075] = {Z[30] , "A Time to Gain", nil} -- a time to gain
  questsdata[29371] = {Z[30] , "A Time to Lose", nil} -- a time to lose
  
  --Kalimdor --Alliance
  --questsdata[29006] = {nil, achi(963,21),nil,nil,{607, 39.0, 11.0},nil,1}--Z.SOUTHERN_BARRENS Honor's Stand
  --questsdata[29007] = {nil, achi(963,22),nil,nil,{607, 65.6, 46.5},nil,1}--Z.SOUTHERN_BARRENS Northwatch Hold
  --questsdata[29008] = {nil, achi(963,20),nil,nil,{607, 49.0, 68.5},nil,1}--Z.SOUTHERN_BARRENS Fort Triumph
  --questsdata[12349] = {nil, achi(850,2) ,nil,nil,{141, 66.6, 45.3},nil,1}--Z.DUSTWALLOW_MARSH Theramore Isle (not part of meta achievement)
  --questsdata[12350] = {nil, achi(963,2) ,nil,nil,{121, 46.3, 45.2},nil,1}--Z.FERALAS Feathermoon Stronghold
  --questsdata[28952] = {nil, achi(963,19),nil,nil,{121, 51.1, 17.8},nil,1}--Z.FERALAS Dreamer's Rest
  --questsdata[12348] = {nil, achi(963,12),nil,nil,{101, 66.3, 6.6 },nil,1}--Z.DESOLACE Nijel's Point
  --questsdata[12347] = {nil, achi(847,10),nil,nil,{81 , 40.6, 17.7},nil,1}--Z.STONETALON_MOUNTAINS Stonetalon Peak (not part of meta achievement)
  --questsdata[29010] = {nil, achi(963,24),nil,nil,{81 , 71.0, 79.0},nil,1}--Z.STONETALON_MOUNTAINS Northwatch Expedition Base Camp
  --questsdata[29011] = {nil, achi(963,25),nil,nil,{81 , 59.0, 56.3},nil,1}--Z.STONETALON_MOUNTAINS Windshear Hold
  --questsdata[29013] = {nil, achi(963,23),nil,nil,{81 , 31.5, 60.7},nil,1}--Z.STONETALON_MOUNTAINS Farwatcher's Glen
  --questsdata[29012] = {nil, achi(963,13),nil,nil,{81 , 39.5, 32.8},nil,1}--Z.STONETALON_MOUNTAINS Thal'darah Overlook
  --questsdata[12345] = {nil, achi(963,15),nil,nil,{43 , 37.0, 49.3},nil,1}--Z.ASHENVALE Astranaar	
  --questsdata[28995] = {nil, achi(963,18),nil,nil,{182, 61.9, 26.7},nil,1}--Z.FELWOOD Talonbranch Glade
  --questsdata[28951] = {nil, achi(963,11),nil,nil,{42 , 50.8, 18.8},nil,1}--Z.DARKSHORE Lor'danel	
  --questsdata[12334] = {nil, achi(963,1) ,nil,nil,{381, 62.2, 33.1},nil,1}--Z.DARNASSUS Craftsmen's Terrace
  --questsdata[12331] = {nil, achi(963,3) ,nil,nil,{41 , 55.4, 52.3},nil,1}--Z.TELDRASSIL Dolanaar	
  --questsdata[12341] = {nil, achi(963,9) ,nil,nil,{476, 55.7, 60.0},nil,1}--Z.BLOODMYST_ISLE Blood Watch
  --questsdata[12333] = {nil, achi(963,14),nil,nil,{464, 48.5, 49.0},nil,1}--Z.AZUREMYST_ISLE Azure Watch
  --questsdata[12337] = {nil, achi(963,8) ,nil,nil,{471, 59.3, 19.2},nil,1}--Z.THE_EXODAR Seat of the Naaru
  
  questsdata[29006] = {nil, "Southern Barrens",nil,nil,{607, 39.0, 11.0},nil,1}--Z.SOUTHERN_BARRENS Honor's Stand
  questsdata[29007] = {nil, "Southern Barrens",nil,nil,{607, 65.6, 46.5},nil,1}--Z.SOUTHERN_BARRENS Northwatch Hold
  questsdata[29008] = {nil, "Southern Barrens",nil,nil,{607, 49.0, 68.5},nil,1}--Z.SOUTHERN_BARRENS Fort Triumph
  questsdata[12349] = {nil, "Dustwallow Marsh",nil,nil,{141, 66.6, 45.3},nil,1}--Z.DUSTWALLOW_MARSH Theramore Isle (not part of meta achievement)
  questsdata[12350] = {nil, "Feralas",nil,nil,{121, 46.3, 45.2},nil,1}--Z.FERALAS Feathermoon Stronghold
  questsdata[28952] = {nil, "Feralas",nil,nil,{121, 51.1, 17.8},nil,1}--Z.FERALAS Dreamer's Rest
  questsdata[12348] = {nil, "Desolace",nil,nil,{101, 66.3, 6.6 },nil,1}--Z.DESOLACE Nijel's Point
  questsdata[12347] = {nil, "Stonetalon Mountains",nil,nil,{81 , 40.6, 17.7},nil,1}--Z.STONETALON_MOUNTAINS Stonetalon Peak (not part of meta achievement)
  questsdata[29010] = {nil, "Stonetalon Mountains",nil,nil,{81 , 71.0, 79.0},nil,1}--Z.STONETALON_MOUNTAINS Northwatch Expedition Base Camp
  questsdata[29011] = {nil, "Stonetalon Mountains",nil,nil,{81 , 59.0, 56.3},nil,1}--Z.STONETALON_MOUNTAINS Windshear Hold
  questsdata[29013] = {nil, "Stonetalon Mountains",nil,nil,{81 , 31.5, 60.7},nil,1}--Z.STONETALON_MOUNTAINS Farwatcher's Glen
  questsdata[29012] = {nil, "Stonetalon Mountains",nil,nil,{81 , 39.5, 32.8},nil,1}--Z.STONETALON_MOUNTAINS Thal'darah Overlook
  questsdata[12345] = {nil, "Ashenvale",nil,nil,{43 , 37.0, 49.3},nil,1}--Z.ASHENVALE Astranaar	
  questsdata[28995] = {nil, "Felwood",nil,nil,{182, 61.9, 26.7},nil,1}--Z.FELWOOD Talonbranch Glade
  questsdata[28951] = {nil, "Darkshore",nil,nil,{42 , 50.8, 18.8},nil,1}--Z.DARKSHORE Lor'danel	
  questsdata[12334] = {nil, "Darnassus",nil,nil,{381, 62.2, 33.1},nil,1}--Z.DARNASSUS Craftsmen's Terrace
  questsdata[12331] = {nil, "Teldrassil",nil,nil,{41 , 55.4, 52.3},nil,1}--Z.TELDRASSIL Dolanaar	
  questsdata[12341] = {nil, "Bloodmyst Isle",nil,nil,{476, 55.7, 60.0},nil,1}--Z.BLOODMYST_ISLE Blood Watch
  questsdata[12333] = {nil, "Azuremyst Isle",nil,nil,{464, 48.5, 49.0},nil,1}--Z.AZUREMYST_ISLE Azure Watch
  questsdata[12337] = {nil, "The Exodar",nil,nil,{471, 59.3, 19.2},nil,1}--Z.THE_EXODAR Seat of the Naaru
  
  --Eastern Kingdoms --Alliance
  --questsdata[28988] = {nil, achi(966,21),nil,nil,{22 , 43.4, 84.4},nil,1}--Z.WESTERN_PLAGUELANDS Chillwind Camp
  --questsdata[12351] = {nil, achi(966,6) ,nil,nil,{26 , 14.2, 44.7},nil,1}--Z.THE_HINTERLANDS Aerie Peak
  --questsdata[28970] = {nil, achi(966,20),nil,nil,{26 , 66.2, 44.4},nil,1}--Z.THE_HINTERLANDS Stormfeather Outpost
  --questsdata[28990] = {nil, achi(966,23),nil,nil,{40 , 26.1, 26.0},nil,1}--Z.WETLANDS Swiftgear Station
  --questsdata[12343] = {nil, achi(966,4) ,nil,nil,{40 , 10.8, 61.0},nil,1}--Z.WETLANDS Menethil Harbor
  --questsdata[28991] = {nil, achi(966,22),nil,nil,{40 , 58.2, 39.2},nil,1}--Z.WETLANDS Greenwarden's Grove
  --questsdata[12339] = {nil, achi(966,3) ,nil,nil,{35 , 35.5, 48.5},nil,1}--Z.LOCH_MODAN Thelsamar
  --questsdata[28963] = {nil, achi(966,17),nil,nil,{35 , 83.0, 63.5},nil,1}--Z.LOCH_MODAN Farstrider Lodge
  --questsdata[12332] = {nil, achi(966,1) ,nil,nil,{27 , 54.5, 50.8},nil,1}--Z.DUN_MOROGH Kharanos
  --questsdata[12335] = {nil, achi(966,10),nil,nil,{341, 18.5, 50.9},nil,1}--Z.IRONFORGE The Commons
  --questsdata[28956] = {nil, achi(966,14),nil,nil,{17 , 20.9, 56.3},nil,1}--Z.BADLANDS Dragon's Mouth
  --questsdata[12336] = {nil, achi(966,8) ,nil,nil,{301, 60.5, 75.2},nil,1}--Z.STORMWIND_CITY Trade District
  --questsdata[12286] = {nil, achi(966,2) ,nil,nil,{30 , 43.8, 66.0},nil,1}--Z.ELWYNN_FOREST Goldshire
  --questsdata[12342] = {nil, achi(966,5) ,nil,nil,{36 , 26.5, 41.5},nil,1}--Z.REDRIDGE_MOUNTAINS Lakeshire
  --questsdata[28968] = {nil, achi(966,19),nil,nil,{38 , 28.9, 32.4},nil,1}--Z.SWAMP_OF_SORROWS The Harborage
  --questsdata[28960] = {nil, achi(966,15),nil,nil,{19 , 60.7, 14.1},nil,1}--Z.BLASTED_LANDS Nethergarde Keep
  --questsdata[28961] = {nil, achi(966,16),nil,nil,{19 , 44.4, 87.6},nil,1}--Z.BLASTED_LANDS Surwich
  --questsdata[12344] = {nil, achi(966,11),nil,nil,{34 , 73.8, 44.2},nil,1}--Z.DUSKWOOD Darkshire
  --questsdata[12340] = {nil, achi(966,12),nil,nil,{39 , 52.9, 53.7},nil,1}--Z.WESTFALL Sentinel Hill
  --questsdata[28964] = {nil, achi(966,18),nil,nil,{37 , 53.2, 67.0},nil,1}--Z.NORTHERN_STRANGLETHORN Fort Livingston
  --questsdata[28954] = {nil, achi(966,13),nil,nil,{16 , 40.1, 49.0},nil,1}--Z.ARATHI_HIGHLANDS Refuge Point
  
  questsdata[28988] = {nil, "Western Plaguelands",nil,nil,{22 , 43.4, 84.4},nil,1}--Z.WESTERN_PLAGUELANDS Chillwind Camp
  questsdata[12351] = {nil, "The Hinterlands",nil,nil,{26 , 14.2, 44.7},nil,1}--Z.THE_HINTERLANDS Aerie Peak
  questsdata[28970] = {nil, "The Hinterlands",nil,nil,{26 , 66.2, 44.4},nil,1}--Z.THE_HINTERLANDS Stormfeather Outpost
  questsdata[28990] = {nil, "Wetlands",nil,nil,{40 , 26.1, 26.0},nil,1}--Z.WETLANDS Swiftgear Station
  questsdata[12343] = {nil, "Wetlands",nil,nil,{40 , 10.8, 61.0},nil,1}--Z.WETLANDS Menethil Harbor
  questsdata[28991] = {nil, "Wetlands",nil,nil,{40 , 58.2, 39.2},nil,1}--Z.WETLANDS Greenwarden's Grove
  questsdata[12339] = {nil, "Loch Modan",nil,nil,{35 , 35.5, 48.5},nil,1}--Z.LOCH_MODAN Thelsamar
  questsdata[28963] = {nil, "Loch Modan",nil,nil,{35 , 83.0, 63.5},nil,1}--Z.LOCH_MODAN Farstrider Lodge
  questsdata[12332] = {nil, "Dun Morogh",nil,nil,{27 , 54.5, 50.8},nil,1}--Z.DUN_MOROGH Kharanos
  questsdata[12335] = {nil, "Ironforge",nil,nil,{341, 18.5, 50.9},nil,1}--Z.IRONFORGE The Commons
  questsdata[28956] = {nil, "Badlands",nil,nil,{17 , 20.9, 56.3},nil,1}--Z.BADLANDS Dragon's Mouth
  questsdata[12336] = {nil, "Stormwind City",nil,nil,{301, 60.5, 75.2},nil,1}--Z.STORMWIND_CITY Trade District
  questsdata[12286] = {nil, "Elwynn Forest",nil,nil,{30 , 43.8, 66.0},nil,1}--Z.ELWYNN_FOREST Goldshire
  questsdata[12342] = {nil, "Redridge Mountains",nil,nil,{36 , 26.5, 41.5},nil,1}--Z.REDRIDGE_MOUNTAINS Lakeshire
  questsdata[28968] = {nil, "Swamp of Sorrows",nil,nil,{38 , 28.9, 32.4},nil,1}--Z.SWAMP_OF_SORROWS The Harborage
  questsdata[28960] = {nil, "Blasted Lands",nil,nil,{19 , 60.7, 14.1},nil,1}--Z.BLASTED_LANDS Nethergarde Keep
  questsdata[28961] = {nil, "Blasted Lands",nil,nil,{19 , 44.4, 87.6},nil,1}--Z.BLASTED_LANDS Surwich
  questsdata[12344] = {nil, "Duskwood",nil,nil,{34 , 73.8, 44.2},nil,1}--Z.DUSKWOOD Darkshire
  questsdata[12340] = {nil, "Westfall",nil,nil,{39 , 52.9, 53.7},nil,1}--Z.WESTFALL Sentinel Hill
  questsdata[28964] = {nil, "Northern Stranglethorn",nil,nil,{37 , 53.2, 67.0},nil,1}--Z.NORTHERN_STRANGLETHORN Fort Livingston
  questsdata[28954] = {nil, "Arathi Highlands",nil,nil,{16 , 40.1, 49.0},nil,1}--Z.ARATHI_HIGHLANDS Refuge Point
  
  --Eastern Kingdoms --Alliance(Cataclysm)
  --questsdata[28978] = {nil, achi(5837,6) ,nil,nil,{700, 49.6, 30.4},nil,1}--Z.TWILIGHT_HIGHLANDS Thundermar
  --questsdata[28977] = {nil, achi(5837,3) ,nil,nil,{700, 60.3, 58.2},nil,1}--Z.TWILIGHT_HIGHLANDS Firebeard's Patrol
  --questsdata[28980] = {nil, achi(5837,9) ,nil,nil,{700, 79.5, 78.5},nil,1}--Z.TWILIGHT_HIGHLANDS Highbank
  --questsdata[28979] = {nil, achi(5837,14),nil,nil,{700, 43.5, 57.3},nil,1}--Z.TWILIGHT_HIGHLANDS Victor's Point
  --questsdata[28983] = {nil, achi(5837,8) ,nil,nil,{615, 49.7, 57.4},nil,1}--Z.SHIMMERING_EXPANSE Tranquil Wash
  --questsdata[28985] = {nil, achi(5837,11),nil,nil,{614, 54.7, 72.1},nil,1}--Z.ABYSSAL_DEPTHS Darkbreak Cove
  
  questsdata[28978] = {nil, "Twilight Highlands",nil,nil,{700, 49.6, 30.4},nil,1}--Z.TWILIGHT_HIGHLANDS Thundermar
  questsdata[28977] = {nil, "Twilight Highlands",nil,nil,{700, 60.3, 58.2},nil,1}--Z.TWILIGHT_HIGHLANDS Firebeard's Patrol
  questsdata[28980] = {nil, "Twilight Highlands",nil,nil,{700, 79.5, 78.5},nil,1}--Z.TWILIGHT_HIGHLANDS Highbank
  questsdata[28979] = {nil, "Twilight Highlands",nil,nil,{700, 43.5, 57.3},nil,1}--Z.TWILIGHT_HIGHLANDS Victor's Point
  questsdata[28983] = {nil, "Shimmering Expanse",nil,nil,{615, 49.7, 57.4},nil,1}--Z.SHIMMERING_EXPANSE Tranquil Wash
  questsdata[28985] = {nil, "Abyssal Depths",nil,nil,{614, 54.7, 72.1},nil,1}--Z.ABYSSAL_DEPTHS Darkbreak Cove
  --Outland --Alliance
  --questsdata[12359] = {nil, achi(969,2) ,nil,nil,{475, 61.1, 68.1},nil,1}--Z.BLADES_EDGE_MOUNTAINS Toshley's Station
  --questsdata[12358] = {nil, achi(969,10),nil,nil,{475, 35.8, 63.7},nil,1}--Z.BLADES_EDGE_MOUNTAINS Sylvanaar
  --questsdata[13255] = {nil, achi(969,15),nil,nil,{467, 41.9, 26.2},nil,1}--Z.ZANGARMARSH Orebor Harborage
  --questsdata[12354] = {nil, achi(969,9) ,nil,nil,{467, 67.2, 48.9},nil,1}--Z.ZANGARMARSH Telredor
  --questsdata[12353] = {nil, achi(969,7) ,nil,nil,{465, 23.4, 36.4},nil,1}--Z.HELLFIRE_PENINSULA Temple of Telhamat
  --questsdata[12352] = {nil, achi(969,3) ,nil,nil,{465, 54.2, 63.7},nil,1}--Z.HELLFIRE_PENINSULA Honor Hold
  --questsdata[12360] = {nil, achi(969,14),nil,nil,{473, 37.0, 58.3},nil,1}--Z.SHADOWMOON_VALLEY Wildhammer Stronghold
  --questsdata[12356] = {nil, achi(969,1) ,nil,nil,{478, 56.6, 53.2},nil,1}--Z.TEROKKAR_FOREST Allerian Stronghold
  --questsdata[12357] = {nil, achi(969,12),nil,nil,{477, 54.2, 75.9},nil,1}--Z.NAGRAND Telaar
  
  questsdata[12359] = {nil, "Blade's Edge Mountains",nil,nil,{475, 61.1, 68.1},nil,1}--Z.BLADES_EDGE_MOUNTAINS Toshley's Station
  questsdata[12358] = {nil, "Blade's Edge Mountains",nil,nil,{475, 35.8, 63.7},nil,1}--Z.BLADES_EDGE_MOUNTAINS Sylvanaar
  questsdata[12355] = {nil, "Zangarmarsh",nil,nil,{467, 41.9, 26.2},nil,1}--Z.ZANGARMARSH Orebor Harborage
  questsdata[12354] = {nil, "Zangarmarsh",nil,nil,{467, 67.2, 48.9},nil,1}--Z.ZANGARMARSH Telredor
  questsdata[12353] = {nil, "Hellfire Peninsula",nil,nil,{465, 23.4, 36.4},nil,1}--Z.HELLFIRE_PENINSULA Temple of Telhamat
  questsdata[12352] = {nil, "Hellfire Peninsula",nil,nil,{465, 54.2, 63.7},nil,1}--Z.HELLFIRE_PENINSULA Honor Hold
  questsdata[12360] = {nil, "Shadowmoon Valley",nil,nil,{473, 37.0, 58.3},nil,1}--Z.SHADOWMOON_VALLEY Wildhammer Stronghold
  questsdata[12356] = {nil, "Terokkar Forest",nil,nil,{478, 56.6, 53.2},nil,1}--Z.TEROKKAR_FOREST Allerian Stronghold
  questsdata[12357] = {nil, "Nagrand",nil,nil,{477, 54.2, 75.9},nil,1}--Z.NAGRAND Telaar
  --Northrend --Alliance
  --questsdata[13437] = {nil, achi(5836,2) ,nil,nil,{486, 57.1, 18.8},nil,1}--Z.BOREAN_TUNDRA Fizzcrank Airstrip
  --questsdata[13436] = {nil, achi(5836,3) ,nil,nil,{486, 58.5, 67.8},nil,1}--Z.BOREAN_TUNDRA Valiance Keep
  --questsdata[13473] = {nil, achi(5836,12),nil,nil,{504, 42.3, 63  },nil,1}--Z.DALARAN_THE_SITUATION Silver Enclave
  --questsdata[13438] = {nil, achi(5836,6) ,nil,nil,{488, 28.9, 56.2},nil,1}--Z.DRAGONBLIGHT Stars' Rest
  --questsdata[13439] = {nil, achi(5836,4) ,nil,nil,{488, 77.5, 51.2},nil,1}--Z.DRAGONBLIGHT Wintergarde Keep
  --questsdata[12944] = {nil, achi(5836,7) ,nil,nil,{490, 31.9, 60.2},nil,1}--Z.GRIZZLY_HILLS Amberpine Lodge
  --questsdata[12945] = {nil, achi(5836,15),nil,nil,{490, 59.6, 26.3},nil,1}--Z.GRIZZLY_HILLS Westfall Brigade
  --questsdata[13435] = {nil, achi(5836,5) ,nil,nil,{491, 60.4, 15.9},nil,1}--Z.HOWLING_FJORD Fort Wildervar
  --questsdata[13433] = {nil, achi(5836,16),nil,nil,{491, 58.3, 62.8},nil,1}--Z.HOWLING_FJORD Valgarde
  --questsdata[13434] = {nil, achi(5836,8) ,nil,nil,{491, 30.8, 41.4},nil,1}--Z.HOWLING_FJORD Westguard Keep
  --questsdata[13448] = {nil, achi(5836,18),nil,nil,{495, 28.7, 74.2},nil,1}--Z.THE_STORM_PEAKS Frosthold
  
  questsdata[13437] = {nil, "Borean Tundra",nil,nil,{486, 57.1, 18.8},nil,1}--Z.BOREAN_TUNDRA Fizzcrank Airstrip
  questsdata[13436] = {nil, "Borean Tundra",nil,nil,{486, 58.5, 67.8},nil,1}--Z.BOREAN_TUNDRA Valiance Keep
  questsdata[13473] = {nil, "Dalaran",nil,nil,{504, 42.3, 63  },nil,1}--Z.DALARAN_THE_SITUATION Silver Enclave
  questsdata[13438] = {nil, "Dragonblight",nil,nil,{488, 28.9, 56.2},nil,1}--Z.DRAGONBLIGHT Stars' Rest
  questsdata[13439] = {nil, "Dragonblight",nil,nil,{488, 77.5, 51.2},nil,1}--Z.DRAGONBLIGHT Wintergarde Keep
  questsdata[12944] = {nil, "Grizzly Hills",nil,nil,{490, 31.9, 60.2},nil,1}--Z.GRIZZLY_HILLS Amberpine Lodge
  questsdata[12945] = {nil, "Grizzly Hills",nil,nil,{490, 59.6, 26.3},nil,1}--Z.GRIZZLY_HILLS Westfall Brigade
  questsdata[13435] = {nil, "Howling Fjord",nil,nil,{491, 60.4, 15.9},nil,1}--Z.HOWLING_FJORD Fort Wildervar
  questsdata[13433] = {nil, "Howling Fjord",nil,nil,{491, 58.3, 62.8},nil,1}--Z.HOWLING_FJORD Valgarde
  questsdata[13434] = {nil, "Howling Fjord",nil,nil,{491, 30.8, 41.4},nil,1}--Z.HOWLING_FJORD Westguard Keep
  questsdata[13448] = {nil, "The Storm Peaks",nil,nil,{495, 28.7, 74.2},nil,1}--Z.THE_STORM_PEAKS Frosthold
  --Pandaria --Alliance
  --questsdata[32049] = {nil, achi(7601,1),nil,nil,{806, 44.8, 84.4},nil,1}--Z.THE_JADE_FOREST Paw'don Village
  --questsdata[32033] = {nil, achi(7601,2),nil,nil,{806, 59.6, 83.2},nil,1}--Z.THE_JADE_FOREST Pearlfin Village
  --questsdata[32042] = {nil, achi(7601,3),nil,nil,{809, 54.1, 82.8},nil,1}--Z.KUN_LAI_SUMMIT Westwind Rest
  --questsdata[32052] = {nil, achi(7601,4),nil,nil,{811, 87.0, 69.0},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Shrine of Seven Stars
  
  questsdata[32049] = {nil, "The Jade Forest",nil,nil,{806, 44.8, 84.4},nil,1}--Z.THE_JADE_FOREST Paw'don Village
  questsdata[32033] = {nil, "The Jade Forest",nil,nil,{806, 59.6, 83.2},nil,1}--Z.THE_JADE_FOREST Pearlfin Village
  questsdata[32042] = {nil, "Kun-Lai Summit",nil,nil,{809, 54.1, 82.8},nil,1}--Z.KUN_LAI_SUMMIT Westwind Rest
  questsdata[32052] = {nil, "Vale of Eternal Blossoms",nil,nil,{811, 87.0, 69.0},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Shrine of Seven Stars
 elseif faction == "Horde" then
  -- Dailies
  questsdata[39617] = {Z[976], "Arachnis",nil,nil,{976, 56.8, 88.9}}-- Requires Creepy Crawlers Decoration
  questsdata[39716] = {Z[976], l(questsdata, 39716, 2, "Smashing Squashlings", "quest", 39716)}
  questsdata[39719] = {Z[976], l(questsdata, 39719, 2, "Mutiny on the Boneship", "quest", 39719)}
  questsdata[39720] = {Z[976], l(questsdata, 39720, 2, "Foul Fertilizer", "quest", 39720)}
  questsdata[39721] = {Z[976], l(questsdata, 39721, 2, "Culling the Crew", "quest", 39721)}
  questsdata[11219] = {Z[382], l(questsdata, 11219, 2, "Stop the Fires!", "quest", 11219)} -- 12139 let-the-fires-come
  questsdata[12155] = {Z[382], l(questsdata, 12155, 2, "Smash the Pumpkin", "quest", 12155)}
  questsdata[29374] = {Z[382], "Stink Bombs Away", nil} -- stink bombs away
  questsdata[29375] = {Z[382], "Clean up in Undercity", nil} -- clean up in undercity
  questsdata[29377] = {Z[382], "A Time to Break", nil} -- a time to break
  questsdata[29376] = {Z[382], "A Time to Build", nil} -- a time to build
  
  --questsdata[29374] = {Z[382], achi(1041,1), nil} -- stink bombs away
  --questsdata[29375] = {Z[382], achi(1041,2), nil} -- clean up in undercity
  --questsdata[29377] = {Z[382], achi(1041,3), nil} -- a time to break
  --questsdata[29376] = {Z[382], achi(1041,4), nil} -- a time to build
  --Kalimdor --Horde
  --questsdata[28989] = {nil, achi(965,25),nil,nil,{43 , 12.9, 34.1},nil,1}--Z.ASHENVALE Zoram'gar Outpost
  --questsdata[28958] = {nil, achi(965,18),nil,nil,{43 , 38.6, 42.4},nil,1}--Z.ASHENVALE Hellscream's Watch
  --questsdata[28953] = {nil, achi(965,16),nil,nil,{43 , 50.2, 67.3},nil,1}--Z.ASHENVALE Silverwind Refuge
  --questsdata[12377] = {nil, achi(965,14),nil,nil,{43 , 73.9, 60.6},nil,1}--Z.ASHENVALE Splintertree Post
  --questsdata[28992] = {nil, achi(965,21),nil,nil,{181, 57.0, 50.3},nil,1}--Z.AZSHARA Bilgewater Harbor
  --questsdata[12383] = {nil, achi(965,2) ,nil,nil,{141, 36.8, 32.4},nil,1}--Z.DUSTWALLOW_MARSH Brackenwall Village
  --questsdata[12381] = {nil, achi(965,11),nil,nil,{101, 24.1, 68.3},nil,1}--Z.DESOLACE Shadowprey Village
  --questsdata[12386] = {nil, achi(965,13),nil,nil,{121, 74.8, 45.1},nil,1}--Z.FERALAS Camp Mojache
  --questsdata[28998] = {nil, achi(965,20),nil,nil,{121, 52.0, 47.6},nil,1}--Z.FERALAS Stonemaul Hold
  --questsdata[28996] = {nil, achi(965,19),nil,nil,{121, 41.4, 15.7},nil,1}--Z.FERALAS Camp Ataya
  --questsdata[29005] = {nil, achi(965,23),nil,nil,{607, 40.7, 69.3},nil,1}--Z.SOUTHERN_BARRENS Desolation Hold
  --questsdata[29004] = {nil, achi(965,28),nil,nil,{607, 39.3, 20.1},nil,1}--Z.SOUTHERN_BARRENS Hunter's Hill
  --questsdata[12362] = {nil, achi(965,10),nil,nil,{9  , 46.8, 60.4},nil,1}--Z.MULGORE Bloodhoof Village
  --questsdata[12367] = {nil, achi(965,4) ,nil,nil,{362, 45.6, 64.9},nil,1}--Z.THUNDER_BLUFF Lower Rise
  --questsdata[12378] = {nil, achi(965,3) ,nil,nil,{81 , 50.4, 63.8},nil,1}--Z.STONETALON_MOUNTAINS Sun Rock Retreat
  --questsdata[29009] = {nil, achi(965,24),nil,nil,{81 , 66.5, 64.2},nil,1}--Z.STONETALON_MOUNTAINS Krom'gar Fortress
  --questsdata[29003] = {nil, achi(965,22),nil,nil,{11 , 62.5, 16.6},nil,1}--Z.NORTHERN_BARRENS Nozzlepot's Outpost
  --questsdata[29002] = {nil, achi(965,17),nil,nil,{11 , 56.2, 40.0},nil,1}--Z.NORTHERN_BARRENS Grol'dom Farm
  --questsdata[12374] = {nil, achi(965,1) ,nil,nil,{11 , 49.5, 57.9},nil,1}--Z.NORTHERN_BARRENS Crossroads
  --questsdata[12361] = {nil, achi(965,15),nil,nil,{4  , 51.6, 41.6},nil,1}--Z.DUROTAR Razor Hill
  --questsdata[12366] = {nil, achi(965,9) ,nil,nil,{321, 53.6, 78.7},nil,1}--Z.ORGRIMMAR Valley of Strength
  
  questsdata[28989] = {nil, "Ashenvale",nil,nil,{43 , 12.9, 34.1},nil,1}--Z.ASHENVALE Zoram'gar Outpost
  questsdata[28958] = {nil, "Ashenvale",nil,nil,{43 , 38.6, 42.4},nil,1}--Z.ASHENVALE Hellscream's Watch
  questsdata[28953] = {nil, "Ashenvale",nil,nil,{43 , 50.2, 67.3},nil,1}--Z.ASHENVALE Silverwind Refuge
  questsdata[12377] = {nil, "Ashenvale",nil,nil,{43 , 73.9, 60.6},nil,1}--Z.ASHENVALE Splintertree Post
  questsdata[28992] = {nil, "Azshara",nil,nil,{181, 57.0, 50.3},nil,1}--Z.AZSHARA Bilgewater Harbor
  questsdata[12383] = {nil, "Dustwallow Marsh",nil,nil,{141, 36.8, 32.4},nil,1}--Z.DUSTWALLOW_MARSH Brackenwall Village
  questsdata[12381] = {nil, "Desolace",nil,nil,{101, 24.1, 68.3},nil,1}--Z.DESOLACE Shadowprey Village
  questsdata[12386] = {nil, "Feralas",nil,nil,{121, 74.8, 45.1},nil,1}--Z.FERALAS Camp Mojache
  questsdata[28998] = {nil, "Feralas",nil,nil,{121, 52.0, 47.6},nil,1}--Z.FERALAS Stonemaul Hold
  questsdata[28996] = {nil, "Feralas",nil,nil,{121, 41.4, 15.7},nil,1}--Z.FERALAS Camp Ataya
  questsdata[29005] = {nil, "Southern Barrens",nil,nil,{607, 40.7, 69.3},nil,1}--Z.SOUTHERN_BARRENS Desolation Hold
  questsdata[29004] = {nil, "Southern Barrens",nil,nil,{607, 39.3, 20.1},nil,1}--Z.SOUTHERN_BARRENS Hunter's Hill
  questsdata[12362] = {nil, "Mulgore",nil,nil,{9  , 46.8, 60.4},nil,1}--Z.MULGORE Bloodhoof Village
  questsdata[12367] = {nil, "Thunder Bluff",nil,nil,{362, 45.6, 64.9},nil,1}--Z.THUNDER_BLUFF Lower Rise
  questsdata[12378] = {nil, "Stonetalon Mountains",nil,nil,{81 , 50.4, 63.8},nil,1}--Z.STONETALON_MOUNTAINS Sun Rock Retreat
  questsdata[29009] = {nil, "Stonetalon Mountains",nil,nil,{81 , 66.5, 64.2},nil,1}--Z.STONETALON_MOUNTAINS Krom'gar Fortress
  questsdata[29003] = {nil, "Northern Barrens",nil,nil,{11 , 62.5, 16.6},nil,1}--Z.NORTHERN_BARRENS Nozzlepot's Outpost
  questsdata[29002] = {nil, "Northern Barrens",nil,nil,{11 , 56.2, 40.0},nil,1}--Z.NORTHERN_BARRENS Grol'dom Farm
  questsdata[12374] = {nil, "Northern Barrens",nil,nil,{11 , 49.5, 57.9},nil,1}--Z.NORTHERN_BARRENS Crossroads
  questsdata[12361] = {nil, "Durotar",nil,nil,{4  , 51.6, 41.6},nil,1}--Z.DUROTAR Razor Hill
  questsdata[12366] = {nil, "Orgrimmar",nil,nil,{321, 53.6, 78.7},nil,1}--Z.ORGRIMMAR Valley of Strength
 --Eastern Kingdoms --Horde
  --questsdata[12369] = {nil, achi(967,8) ,nil,nil,{480, 79.4, 57.7},nil,1}--Z.SILVERMOON_CITY Silvermoon City Inn
  --questsdata[12370] = {nil, achi(967,3) ,nil,nil,{480, 67.6, 72.9},nil,1}--Z.SILVERMOON_CITY Wayfarer's Rest
  --questsdata[12364] = {nil, achi(967,2) ,nil,nil,{462, 48.2, 47.9},nil,1}--Z.EVERSONG_WOODS Falconwing Square
  --questsdata[12365] = {nil, achi(967,12),nil,nil,{462, 43.7, 71.0},nil,1}--Z.EVERSONG_WOODS Fairbreeze Village
  --questsdata[12373] = {nil, achi(967,13),nil,nil,{463, 48.7, 31.9},nil,1}--Z.GHOSTLANDS	Tranquillien
  --questsdata[28987] = {nil, achi(967,22),nil,nil,{22 , 48.3, 63.7},nil,1}--Z.WESTERN_PLAGUELANDS Andorhal
  --questsdata[28972] = {nil, achi(967,21),nil,nil,{20 , 83.0, 72.1},nil,1}--Z.TIRISFAL_GLADES The Bulwark
  --questsdata[12363] = {nil, achi(967,4) ,nil,nil,{20 , 61.0, 51.4},nil,1}--Z.TIRISFAL_GLADES Brill
  --questsdata[12368] = {nil, achi(967,5) ,nil,nil,{382, 67.7, 37.5},nil,1}--Z.UNDERCITY Trade Quarter
  --questsdata[28966] = {nil, achi(967,19),nil,nil,{21 , 44.3, 20.3},nil,1}--Z.SILVERPINE_FOREST Forsaken Rear Guard
  --questsdata[12371] = {nil, achi(967,9) ,nil,nil,{21 , 46.4, 42.7},nil,1}--Z.SILVERPINE_FOREST The Sepulcher
  --questsdata[12376] = {nil, achi(967,7) ,nil,nil,{24 , 57.9, 47.3},nil,1}--Z.HILLSBRAD_FOOTHILLS Tarren Mill
  --questsdata[28962] = {nil, achi(967,16),nil,nil,{24 , 60.3, 63.7},nil,1}--Z.HILLSBRAD_FOOTHILLS Eastpoint Tower
  --questsdata[28971] = {nil, achi(967,23),nil,nil,{26 , 31.8, 57.9},nil,1}--Z.THE_HINTERLANDS Hiri'watha Research Station
  --questsdata[12387] = {nil, achi(967,14),nil,nil,{26 , 78.2, 81.5},nil,1}--Z.THE_HINTERLANDS Revantusk Village
  --questsdata[12380] = {nil, achi(967,15),nil,nil,{16 , 69.0, 33.3},nil,1}--Z.ARATHI_HIGHLANDS Hammerfall
  --questsdata[28957] = {nil, achi(967,18),nil,nil,{17 , 18.4, 42.7},nil,1}--Z.BADLANDS New Kargath
  --questsdata[12384] = {nil, achi(967,11),nil,nil,{38 , 46.9, 56.9},nil,1}--Z.SWAMP_OF_SORROWS Stonard
  --questsdata[28959] = {nil, achi(967,24),nil,nil,{19 , 40.5, 11.3},nil,1}--Z.BLASTED_LANDS Dreadmaul Hold
  --questsdata[12382] = {nil, achi(967,10),nil,nil,{37 , 37.4, 51.8},nil,1}--Z.NORTHERN_STRANGLETHORN Grom'gol Base Camp
  --questsdata[28969] = {nil, achi(967,20),nil,nil,{673, 35.0, 27.2},nil,1}--Z.THE_CAPE_OF_STRANGLETHORN Hardwrench Hideaway
  
  questsdata[12369] = {nil, "Silvermoon City",nil,nil,{480, 79.4, 57.7},nil,1}--Z.SILVERMOON_CITY Silvermoon City Inn
  questsdata[12370] = {nil, "Silvermoon City",nil,nil,{480, 67.6, 72.9},nil,1}--Z.SILVERMOON_CITY Wayfarer's Rest
  questsdata[12364] = {nil, "Eversong Woods",nil,nil,{462, 48.2, 47.9},nil,1}--Z.EVERSONG_WOODS Falconwing Square
  questsdata[12365] = {nil, "Eversong Woods",nil,nil,{462, 43.7, 71.0},nil,1}--Z.EVERSONG_WOODS Fairbreeze Village
  questsdata[12373] = {nil, "Ghostlands",nil,nil,{463, 48.7, 31.9},nil,1}--Z.GHOSTLANDS	Tranquillien
  questsdata[28987] = {nil, "Western Plaguelands",nil,nil,{22 , 48.3, 63.7},nil,1}--Z.WESTERN_PLAGUELANDS Andorhal
  questsdata[28972] = {nil, "Tirisfal Glades",nil,nil,{20 , 83.0, 72.1},nil,1}--Z.TIRISFAL_GLADES The Bulwark
  questsdata[12363] = {nil, "Tirisfal Glades",nil,nil,{20 , 61.0, 51.4},nil,1}--Z.TIRISFAL_GLADES Brill
  questsdata[12368] = {nil, "Undercity",nil,nil,{382, 67.7, 37.5},nil,1}--Z.UNDERCITY Trade Quarter
  questsdata[28966] = {nil, "Silverpine Forest",nil,nil,{21 , 44.3, 20.3},nil,1}--Z.SILVERPINE_FOREST Forsaken Rear Guard
  questsdata[12371] = {nil, "Silverpine Forest",nil,nil,{21 , 46.4, 42.7},nil,1}--Z.SILVERPINE_FOREST The Sepulcher
  questsdata[12376] = {nil, "Hillsbrad Foothills",nil,nil,{24 , 57.9, 47.3},nil,1}--Z.HILLSBRAD_FOOTHILLS Tarren Mill
  questsdata[28962] = {nil, "Hillsbrad Foothills",nil,nil,{24 , 60.3, 63.7},nil,1}--Z.HILLSBRAD_FOOTHILLS Eastpoint Tower
  questsdata[28971] = {nil, "The Hinterlands",nil,nil,{26 , 31.8, 57.9},nil,1}--Z.THE_HINTERLANDS Hiri'watha Research Station
  questsdata[12387] = {nil, "The Hinterlands",nil,nil,{26 , 78.2, 81.5},nil,1}--Z.THE_HINTERLANDS Revantusk Village
  questsdata[12380] = {nil, "Arathi Highlands",nil,nil,{16 , 69.0, 33.3},nil,1}--Z.ARATHI_HIGHLANDS Hammerfall
  questsdata[28957] = {nil, "Badlands",nil,nil,{17 , 18.4, 42.7},nil,1}--Z.BADLANDS New Kargath
  questsdata[12384] = {nil, "Swamp of Sorrows",nil,nil,{38 , 46.9, 56.9},nil,1}--Z.SWAMP_OF_SORROWS Stonard
  questsdata[28959] = {nil, "Blasted Lands",nil,nil,{19 , 40.5, 11.3},nil,1}--Z.BLASTED_LANDS Dreadmaul Hold
  questsdata[12382] = {nil, "Northern Stranglethorn",nil,nil,{37 , 37.4, 51.8},nil,1}--Z.NORTHERN_STRANGLETHORN Grom'gol Base Camp
  questsdata[28969] = {nil, "The Cape of Stranglethorn",nil,nil,{673, 35.0, 27.2},nil,1}--Z.THE_CAPE_OF_STRANGLETHORN Hardwrench Hideaway
  --Horde (Cataclysm)
  --questsdata[28974] = {nil, achi(5838,6) ,nil,nil,{700, 45.1, 76.8},nil,1}--Z.TWILIGHT_HIGHLANDS Crushblow
  --questsdata[28973] = {nil, achi(5838,3) ,nil,nil,{700, 53.4, 42.8},nil,1}--Z.TWILIGHT_HIGHLANDS Bloodgulch
  --questsdata[28976] = {nil, achi(5838,1) ,nil,nil,{700, 75.4, 16.5},nil,1}--Z.TWILIGHT_HIGHLANDS The Krazzworks
  --questsdata[28975] = {nil, achi(4866,8) ,nil,nil,{700, 75.3, 54.9},nil,1}--Z.TWILIGHT_HIGHLANDS Dragonmaw Port (not for meta)
  --questsdata[28984] = {nil, achi(5838,8) ,nil,nil,{615, 51.4, 62.3},nil,1}--Z.SHIMMERING_EXPANSE Legion's Rest
  --questsdata[28986] = {nil, achi(5838,11),nil,nil,{614, 51.3, 60.5},nil,1}--Z.ABYSSAL_DEPTHS Tenebrous Cavern	

  questsdata[28974] = {nil, "Twilight Highlands",nil,nil,{700, 45.1, 76.8},nil,1}--Z.TWILIGHT_HIGHLANDS Crushblow
  questsdata[28973] = {nil, "Twilight Highlands",nil,nil,{700, 53.4, 42.8},nil,1}--Z.TWILIGHT_HIGHLANDS Bloodgulch
  questsdata[28976] = {nil, "Twilight Highlands",nil,nil,{700, 75.4, 16.5},nil,1}--Z.TWILIGHT_HIGHLANDS The Krazzworks
  questsdata[28975] = {nil, "Twilight Highlands",nil,nil,{700, 75.3, 54.9},nil,1}--Z.TWILIGHT_HIGHLANDS Dragonmaw Port (not for meta)
  questsdata[28984] = {nil, "Shimmering Expanse",nil,nil,{615, 51.4, 62.3},nil,1}--Z.SHIMMERING_EXPANSE Legion's Rest
  questsdata[28986] = {nil, "Abyssal Depths",nil,nil,{614, 51.3, 60.5},nil,1}--Z.ABYSSAL_DEPTHS Tenebrous Cavern	  
  --Outland --Horde
  --questsdata[12394] = {nil, achi(968,8) ,nil,nil,{475, 76.2, 60.4},nil,1}--Z.BLADES_EDGE_MOUNTAINS Mok'Nathal Village
  --questsdata[12393] = {nil, achi(968,2) ,nil,nil,{475, 53.4, 55.5},nil,1}--Z.BLADES_EDGE_MOUNTAINS Thunderlord Stronghold
  --questsdata[12390] = {nil, achi(968,1) ,nil,nil,{467, 30.7, 50.9},nil,1}--Z.ZANGARMARSH Zabra'jin
  --questsdata[12388] = {nil, achi(968,3) ,nil,nil,{465, 56.8, 37.5},nil,1}--Z.HELLFIRE_PENINSULA Thrallmar
  --questsdata[12389] = {nil, achi(968,13),nil,nil,{465, 26.9, 59.6},nil,1}--Z.HELLFIRE_PENINSULA Falcon Watch
  --questsdata[12392] = {nil, achi(968,14),nil,nil,{477, 56.7, 34.6},nil,1}--Z.NAGRAND Garadar
  --questsdata[12391] = {nil, achi(968,7) ,nil,nil,{478, 48.8, 45.2},nil,1}--Z.TEROKKAR_FOREST Stonebreaker Hold
  --questsdata[12395] = {nil, achi(968,4) ,nil,nil,{473, 30.3, 27.8},nil,1}--Z.SHADOWMOON_VALLEY Shadowmoon Village
  
  questsdata[12394] = {nil, "Blade's Edge Mountains",nil,nil,{475, 76.2, 60.4},nil,1}--Z.BLADES_EDGE_MOUNTAINS Mok'Nathal Village
  questsdata[12393] = {nil, "Blade's Edge Mountains",nil,nil,{475, 53.4, 55.5},nil,1}--Z.BLADES_EDGE_MOUNTAINS Thunderlord Stronghold
  questsdata[12390] = {nil, "Zangarmarsh",nil,nil,{467, 30.7, 50.9},nil,1}--Z.ZANGARMARSH Zabra'jin
  questsdata[12388] = {nil, "Hellfire Peninsula",nil,nil,{465, 56.8, 37.5},nil,1}--Z.HELLFIRE_PENINSULA Thrallmar
  questsdata[12389] = {nil, "Hellfire Peninsula",nil,nil,{465, 26.9, 59.6},nil,1}--Z.HELLFIRE_PENINSULA Falcon Watch
  questsdata[12392] = {nil, "Nagrand",nil,nil,{477, 56.7, 34.6},nil,1}--Z.NAGRAND Garadar
  questsdata[12391] = {nil, "Terokkar Forest",nil,nil,{478, 48.8, 45.2},nil,1}--Z.TEROKKAR_FOREST Stonebreaker Hold
  questsdata[12395] = {nil, "Shadowmoon Valley",nil,nil,{473, 30.3, 27.8},nil,1}--Z.SHADOWMOON_VALLEY Shadowmoon Village
  --Northrend  --Horde
  --questsdata[13548] = {nil, achi(5835,9) ,nil,nil,{495, 37  , 49.5},nil,1}--Z.THE_STORM_PEAKS Grom'arsh Crash Site
  --questsdata[13471] = {nil, achi(5835,17),nil,nil,{495, 67.6, 50.6},nil,1}--Z.THE_STORM_PEAKS Camp Tunka'lo
  --questsdata[13466] = {nil, achi(5835,3) ,nil,nil,{491, 79.2, 30.6},nil,1}--Z.HOWLING_FJORD Vengeance Landing
  --questsdata[13465] = {nil, achi(5835,10),nil,nil,{491, 52.1, 66.1},nil,1}--Z.HOWLING_FJORD New Agamand
  --questsdata[13464] = {nil, achi(5835,6) ,nil,nil,{491, 49.4, 10.7},nil,1}--Z.HOWLING_FJORD Camp Winterhoof
  --questsdata[12946] = {nil, achi(5835,19),nil,nil,{490, 20.8, 64.7},nil,1}--Z.GRIZZLY_HILLS Conquest Hold
  --questsdata[12947] = {nil, achi(5835,18),nil,nil,{490, 65.3, 47  },nil,1}--Z.GRIZZLY_HILLS Camp Onegwah
  --questsdata[13470] = {nil, achi(5835,13),nil,nil,{488, 76.8, 63.2},nil,1}--Z.DRAGONBLIGHT Venomspite
  --questsdata[13469] = {nil, achi(5835,2) ,nil,nil,{488, 37.8, 46.4},nil,1}--Z.DRAGONBLIGHT Agmar's Hammer
  --questsdata[13474] = {nil, achi(5835,4) ,nil,nil,{504, 66.8, 29.6},nil,1}--Z.DALARAN_THE_SITUATION Sunreaver's Sanctuary
  --questsdata[13468] = {nil, achi(5835,20),nil,nil,{486, 41.7, 54.4},nil,1}--Z.BOREAN_TUNDRA Warsong Hold
  --questsdata[13501] = {nil, achi(5835,22),nil,nil,{486, 49.7, 9.9 },nil,1}--Z.BOREAN_TUNDRA Bor'gorok Outpost
  --questsdata[13467] = {nil, achi(5835,1) ,nil,nil,{486, 76.6, 37.4},nil,1}--Z.BOREAN_TUNDRA Taunka'le Village
  
  questsdata[13548] = {nil, "The Storm Peaks",nil,nil,{495, 37  , 49.5},nil,1}--Z.THE_STORM_PEAKS Grom'arsh Crash Site
  questsdata[13471] = {nil, "The Storm Peaks",nil,nil,{495, 67.6, 50.6},nil,1}--Z.THE_STORM_PEAKS Camp Tunka'lo
  questsdata[13466] = {nil, "Howling Fjord",nil,nil,{491, 79.2, 30.6},nil,1}--Z.HOWLING_FJORD Vengeance Landing
  questsdata[13465] = {nil, "Howling Fjord",nil,nil,{491, 52.1, 66.1},nil,1}--Z.HOWLING_FJORD New Agamand
  questsdata[13464] = {nil, "Howling Fjord",nil,nil,{491, 49.4, 10.7},nil,1}--Z.HOWLING_FJORD Camp Winterhoof
  questsdata[12946] = {nil, "Grizzly Hills",nil,nil,{490, 20.8, 64.7},nil,1}--Z.GRIZZLY_HILLS Conquest Hold
  questsdata[12947] = {nil, "Grizzly Hills",nil,nil,{490, 65.3, 47  },nil,1}--Z.GRIZZLY_HILLS Camp Onegwah
  questsdata[13470] = {nil, "Dragonblight",nil,nil,{488, 76.8, 63.2},nil,1}--Z.DRAGONBLIGHT Venomspite
  questsdata[13469] = {nil, "Dragonblight",nil,nil,{488, 37.8, 46.4},nil,1}--Z.DRAGONBLIGHT Agmar's Hammer
  questsdata[13474] = {nil, "Dalaran",nil,nil,{504, 66.8, 29.6},nil,1}--Z.DALARAN_THE_SITUATION Sunreaver's Sanctuary
  questsdata[13468] = {nil, "Borean Tundra",nil,nil,{486, 41.7, 54.4},nil,1}--Z.BOREAN_TUNDRA Warsong Hold
  questsdata[13501] = {nil, "Borean Tundra",nil,nil,{486, 49.7, 9.9 },nil,1}--Z.BOREAN_TUNDRA Bor'gorok Outpost
  questsdata[13467] = {nil, "Borean Tundra",nil,nil,{486, 76.6, 37.4},nil,1}--Z.BOREAN_TUNDRA Taunka'le Village
  --Pandaria --Horde
  --questsdata[32028] = {nil, achi(7602,19),nil,nil,{806, 28  , 47.4},nil,1}--Z.THE_JADE_FOREST Grookin Hill
  --questsdata[32050] = {nil, achi(7602,20),nil,nil,{806, 28.4, 13.2},nil,1}--Z.THE_JADE_FOREST Honeydew Village
  --questsdata[32020] = {nil, achi(7602,21),nil,nil,{857, 28.2, 50.7},nil,1}--Z.KRASARANG_WILDS Dawnchaser Retreat
  --questsdata[32047] = {nil, achi(7602,24),nil,nil,{857, 61.0, 25.1},nil,1}--Z.KRASARANG_WILDS Thunder Cleft
  --questsdata[32040] = {nil, achi(7602,22),nil,nil,{809, 62.7, 80.5},nil,1}--Z.KUN_LAI_SUMMIT Eastwind Rest
  --questsdata[32022] = {nil, achi(7602,23),nil,nil,{811, 61.9, 16.2},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Shrine of Two Moons
  
  questsdata[32028] = {nil, "The Jade Forest",nil,nil,{806, 28  , 47.4},nil,1}--Z.THE_JADE_FOREST Grookin Hill
  questsdata[32050] = {nil, "The Jade Forest",nil,nil,{806, 28.4, 13.2},nil,1}--Z.THE_JADE_FOREST Honeydew Village
  questsdata[32020] = {nil, "Krasarang Wilds",nil,nil,{857, 28.2, 50.7},nil,1}--Z.KRASARANG_WILDS Dawnchaser Retreat
  questsdata[32047] = {nil, "Krasarang Wilds",nil,nil,{857, 61.0, 25.1},nil,1}--Z.KRASARANG_WILDS Thunder Cleft
  questsdata[32040] = {nil, "Kun-Lai Summit",nil,nil,{809, 62.7, 80.5},nil,1}--Z.KUN_LAI_SUMMIT Eastwind Rest
  questsdata[32022] = {nil, "Vale of Eternal Blossoms",nil,nil,{811, 61.9, 16.2},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Shrine of Two Moons
 end
 
  questsdata["headless"] = {Z[874], select(8, GetAchievementInfo(255)), nil, nil, nil, nil, nil, nil, nil, isquestcompleted}
  questsdata[43162] = {Z[976], l(questsdata, 43162, 2, "Under the Crooked Tree", "quest", 43162)}
  
  --Kalimdor
  --Neutral (9)
  --questsdata[12398] = {nil, achi(963,10),nil,nil,{141, 41.9, 74.1},nil,1} --Z.DUSTWALLOW_MARSH Mudsprocket
  --questsdata[28993] = {nil, achi(963,16),nil,nil,{101, 56.7, 50.1},nil,1}--Z.DESOLACE Karnum's Glade
  --questsdata[28994] = {nil, achi(963,17),nil,nil,{182, 44.7, 29.0},nil,1}--Z.FELWOOD Whisperwind Grove
  --questsdata[12400] = {nil, achi(963,6) ,nil,nil,{281, 59.8, 51.1},nil,1}--Z.WINTERSPRING Everlook
  --questsdata[29014] = {nil, achi(963,26),nil,nil,{161, 55.7, 61.0},nil,1}--Z.TANARIS Bootlegger Outpost
  --questsdata[12399] = {nil, achi(963,7) ,nil,nil,{161, 52.6, 27.1},nil,1}--Z.TANARIS Gadgetzan
  --questsdata[29018] = {nil, achi(963,27),nil,nil,{201, 55.3, 62.1},nil,1}--Z.UNGORO_CRATER Marshal's Stand
  --questsdata[12401] = {nil, achi(963,5) ,nil,nil,{261, 55.5, 36.8},nil,1}--Z.SILITHUS Cenarion Hold
  --questsdata[12396] = {nil, achi(963,4) ,nil,nil,{11 , 67.3, 74.6},nil,1}--Z.NORTHERN_BARRENS Ratchet	
  
  questsdata[12398] = {nil, "Dustwallow Marsh",nil,nil,{141, 41.9, 74.1},nil,1} --Z.DUSTWALLOW_MARSH Mudsprocket
  questsdata[28993] = {nil, "DEsolace",nil,nil,{101, 56.7, 50.1},nil,1}--Z.DESOLACE Karnum's Glade
  questsdata[28994] = {nil, "Felwood",nil,nil,{182, 44.7, 29.0},nil,1}--Z.FELWOOD Whisperwind Grove
  questsdata[12400] = {nil, "Winterspring",nil,nil,{281, 59.8, 51.1},nil,1}--Z.WINTERSPRING Everlook
  questsdata[29014] = {nil, "Tanaris",nil,nil,{161, 55.7, 61.0},nil,1}--Z.TANARIS Bootlegger Outpost
  questsdata[12399] = {nil, "Tanaris",nil,nil,{161, 52.6, 27.1},nil,1}--Z.TANARIS Gadgetzan
  questsdata[29018] = {nil, "Un'goro Crater",nil,nil,{201, 55.3, 62.1},nil,1}--Z.UNGORO_CRATER Marshal's Stand
  questsdata[12401] = {nil, "Silithus",nil,nil,{261, 55.5, 36.8},nil,1}--Z.SILITHUS Cenarion Hold
  questsdata[12396] = {nil, "Northern Barrens",nil,nil,{11 , 67.3, 74.6},nil,1}--Z.NORTHERN_BARRENS Ratchet	
  --Neutral (Cataclysm) 
  --questsdata[28999] = {nil, achi(5837,5) ,nil,nil,{606, 63.1, 24.1},nil,1}--Z.MOUNT_HYJAL Nordrassil Inn
  --questsdata[29001] = {nil, achi(5837,2) ,nil,nil,{606, 42.7, 45.7},nil,1}--Z.MOUNT_HYJAL Shrine of Aviana
  --questsdata[29000] = {nil, achi(5837,13),nil,nil,{606, 18.6, 37.3},nil,1}--Z.MOUNT_HYJAL Grove of Aessina
  --questsdata[29016] = {nil, achi(5837,1) ,nil,nil,{720, 26.6, 7.2 },nil,1}--Z.ULDUM Oasis of Vir'sar
  --questsdata[29017] = {nil, achi(5837,7) ,nil,nil,{720, 54.7, 33.0},nil,1}--Z.ULDUM Ramkahen
  
  questsdata[28999] = {nil, "Mount Hyjal",nil,nil,{606, 63.1, 24.1},nil,1}--Z.MOUNT_HYJAL Nordrassil Inn
  questsdata[29001] = {nil, "Mount Hyjal",nil,nil,{606, 42.7, 45.7},nil,1}--Z.MOUNT_HYJAL Shrine of Aviana
  questsdata[29000] = {nil, "Mount Hyjal",nil,nil,{606, 18.6, 37.3},nil,1}--Z.MOUNT_HYJAL Grove of Aessina
  questsdata[29016] = {nil, "Uldum",nil,nil,{720, 26.6, 7.2 },nil,1}--Z.ULDUM Oasis of Vir'sar
  questsdata[29017] = {nil, "Uldum",nil,nil,{720, 54.7, 33.0},nil,1}--Z.ULDUM Ramkahen
  --Eastern Kingdoms
  --Neutral
  --questsdata[12402] = {nil, achi(966,7) ,nil,nil,{23 , 75.6, 52.3},nil,1}--Z.EASTERN_PLAGUELANDS Light's Hope Chapel
  --questsdata[28965] = {nil, achi(966,25),nil,nil,{28 , 39.5, 66.1},nil,1}--Z.SEARING_GORGE Iron Summit
  --questsdata[28955] = {nil, achi(966,24),nil,nil,{17 , 65.8, 35.6},nil,1}--Z.BADLANDS Fuselight
  --questsdata[28967] = {nil, achi(966,26),nil,nil,{38 , 71.6, 14.1},nil,1}--Z.SWAMP_OF_SORROWS Bogpaddle
  --questsdata[12397] = {nil, achi(966,9) ,nil,nil,{673, 40.9, 73.7},nil,1}--Z.THE_CAPE_OF_STRANGLETHORN Booty Bay
  
  questsdata[12402] = {nil, "Eatern Plaguelands",nil,nil,{23 , 75.6, 52.3},nil,1}--Z.EASTERN_PLAGUELANDS Light's Hope Chapel
  questsdata[28965] = {nil, "Searing Gorge",nil,nil,{28 , 39.5, 66.1},nil,1}--Z.SEARING_GORGE Iron Summit
  questsdata[28955] = {nil, "Badlands",nil,nil,{17 , 65.8, 35.6},nil,1}--Z.BADLANDS Fuselight
  questsdata[28967] = {nil, "Swamp of Sorrows",nil,nil,{38 , 71.6, 14.1},nil,1}--Z.SWAMP_OF_SORROWS Bogpaddle
  questsdata[12397] = {nil, "The Cape of Stranglethorn",nil,nil,{673, 40.9, 73.7},nil,1}--Z.THE_CAPE_OF_STRANGLETHORN Booty Bay
  --Neutral Cataclysm
  --questsdata[28981] = {nil, achi(5837,12),nil,nil,{610, 63.5, 60.2},nil,1}--Z.KELPTHAR_FOREST Deepmist Grotto
  --questsdata[28982] = {nil, achi(5837,10),nil,nil,{615, 49.2, 41.8},nil,1}--Z.SHIMMERING_EXPANSE Silver Tide Hollow
  
  questsdata[28981] = {nil, "Kelp'thar Forest",nil,nil,{610, 63.5, 60.2},nil,1}--Z.KELPTHAR_FOREST Deepmist Grotto
  questsdata[28982] = {nil, "Shimmering Expanse",nil,nil,{615, 49.2, 41.8},nil,1}--Z.SHIMMERING_EXPANSE Silver Tide Hollow
  --Outland
  --Neutral
  --questsdata[12408]    = {nil, achi(969,6) ,nil,nil,{479, 43.4, 36.1},nil,1}--Z.NETHERSTORM Stormspire
  --questsdata[12407]    = {nil, achi(969,5) ,nil,nil,{479, 32.1, 64.5},nil,1}--Z.NETHERSTORM Area 52
  --questsdata[12403]    = {nil, achi(969,13),nil,nil,{467, 78.5, 62.9},nil,1}--Z.ZANGARMARSH Cenarion Refuge
  --questsdata["12404a"] = {nil, achi(867,5) ,nil,nil,{481, 28.1, 49.0},nil,1, nil, show_aldor  , isquestcompleted}--Z.SHATTRATH_CITY Aldor Rise
  --questsdata["12404b"] = {nil, achi(867,5) ,nil,nil,{481, 56.2, 81.8},nil,1, nil, show_scryers, isquestcompleted}--Z.SHATTRATH_CITY Scryers Tier
  --questsdata["12409a"] = {nil, achi(864,9) ,nil,nil,{473, 61.0, 28.2},nil,1, nil, show_aldor  , isquestcompleted}--Z.SHADOWMOON_VALLEY Altar of Sha’tar
  --questsdata["12409b"] = {nil, achi(864,12),nil,nil,{473, 56.3, 59.8},nil,1, nil, show_scryers, isquestcompleted}--Z.SHADOWMOON_VALLEY Sanctum of the Stars
  --questsdata[12406]    = {nil, achi(969,4) ,nil,nil,{475, 62.9, 38.3},nil,1}--Z.BLADES_EDGE_MOUNTAINS Evergrove
  
  questsdata[12408]    = {nil, "Netherstorm",nil,nil,{479, 43.4, 36.1},nil,1}--Z.NETHERSTORM Stormspire
  questsdata[12407]    = {nil, "Netherstorm",nil,nil,{479, 32.1, 64.5},nil,1}--Z.NETHERSTORM Area 52
  questsdata[12403]    = {nil, "Zangarmarsh",nil,nil,{467, 78.5, 62.9},nil,1}--Z.ZANGARMARSH Cenarion Refuge
  questsdata["12404a"] = {nil, "Shattrath City",nil,nil,{481, 28.1, 49.0},nil,1, nil, show_aldor  , isquestcompleted}--Z.SHATTRATH_CITY Aldor Rise
  questsdata["12404b"] = {nil, "Shattrath City",nil,nil,{481, 56.2, 81.8},nil,1, nil, show_scryers, isquestcompleted}--Z.SHATTRATH_CITY Scryers Tier
  questsdata["12409a"] = {nil, "Shadowmoon Valley",nil,nil,{473, 61.0, 28.2},nil,1, nil, show_aldor  , isquestcompleted}--Z.SHADOWMOON_VALLEY Altar of Sha’tar
  questsdata["12409b"] = {nil, "Shadowmoon Valley",nil,nil,{473, 56.3, 59.8},nil,1, nil, show_scryers, isquestcompleted}--Z.SHADOWMOON_VALLEY Sanctum of the Stars
  questsdata[12406]    = {nil, "Blade's Edge Mountains",nil,nil,{475, 62.9, 38.3},nil,1}--Z.BLADES_EDGE_MOUNTAINS Evergrove
  --Northrend
  --Neutral
  --questsdata[12941] = {nil, achi(5836,22),nil,nil,{496, 40.8, 66.0},nil,1}--Z.ZULDRAK The Argent Stand
  --questsdata[12940] = {nil, achi(5836,19),nil,nil,{496, 59.3, 57.1},nil,1}--Z.ZULDRAK Zim'Torga
  --questsdata[12950] = {nil, achi(5836,1) ,nil,nil,{493, 26.6, 59.2},nil,1}--Z.SHOLAZAR_BASIN Nesingwary Base Camp
  --questsdata[13461] = {nil, achi(5836,17),nil,nil,{495, 41  , 85.8},nil,1}--Z.THE_STORM_PEAKS K3
  --questsdata[13462] = {nil, achi(5836,9) ,nil,nil,{495, 30.9, 37.1},nil,1}--Z.THE_STORM_PEAKS Bouldercrag's Refuge
  --questsdata[13452] = {nil, achi(5836,21),nil,nil,{491, 25.4, 59.8},nil,1}--Z.HOWLING_FJORD Kamagua
  --questsdata[13456] = {nil, achi(5836,20),nil,nil,{488, 60.1, 53.4},nil,1}--Z.DRAGONBLIGHT Wyrmrest Temple
  --questsdata[13459] = {nil, achi(5836,14),nil,nil,{488, 48.1, 74.6},nil,1}--Z.DRAGONBLIGHT Moa'ki Harbor
  --questsdata[13472] = {nil, achi(5836,13),nil,nil,{504, 37.8, 46.4},nil,1}--Z.DALARAN_THE_SITUATION The Underbelly
  --questsdata[13463] = {nil, achi(5836,11),nil,nil,{504, 48.3, 40.8},nil,1}--Z.DALARAN_THE_SITUATION The Legerdemain Lounge
  --questsdata[13460] = {nil, achi(5836,10),nil,nil,{486, 78.4, 49.1},nil,1}--Z.BOREAN_TUNDRA Unu'pe
  
  questsdata[12941] = {nil, "Zul'drak",nil,nil,{496, 40.8, 66.0},nil,1}--Z.ZULDRAK The Argent Stand
  questsdata[12940] = {nil, "Zul'drak",nil,nil,{496, 59.3, 57.1},nil,1}--Z.ZULDRAK Zim'Torga
  questsdata[12950] = {nil, "Sholazar Basin",nil,nil,{493, 26.6, 59.2},nil,1}--Z.SHOLAZAR_BASIN Nesingwary Base Camp
  questsdata[13461] = {nil, "The Storm Peaks",nil,nil,{495, 41  , 85.8},nil,1}--Z.THE_STORM_PEAKS K3
  questsdata[13462] = {nil, "The Storm Peaks",nil,nil,{495, 30.9, 37.1},nil,1}--Z.THE_STORM_PEAKS Bouldercrag's Refuge
  questsdata[13452] = {nil, "Howling Fjord",nil,nil,{491, 25.4, 59.8},nil,1}--Z.HOWLING_FJORD Kamagua
  questsdata[13456] = {nil, "Dragonblight",nil,nil,{488, 60.1, 53.4},nil,1}--Z.DRAGONBLIGHT Wyrmrest Temple
  questsdata[13459] = {nil, "Dragonblight",nil,nil,{488, 48.1, 74.6},nil,1}--Z.DRAGONBLIGHT Moa'ki Harbor
  questsdata[13472] = {nil, "Dalaran",nil,nil,{504, 37.8, 46.4},nil,1}--Z.DALARAN_THE_SITUATION The Underbelly
  questsdata[13463] = {nil, "Dalaran",nil,nil,{504, 48.3, 40.8},nil,1}--Z.DALARAN_THE_SITUATION The Legerdemain Lounge
  questsdata[13460] = {nil, "Borean",nil,nil,{486, 78.4, 49.1},nil,1}--Z.BOREAN_TUNDRA Unu'pe
  --Pandaria
  --Neutral
  --questsdata[32024] = {nil, achi(7601,5) ,nil,nil,{858, 55.9, 32.2},nil,1}--Z.DREAD_WASTES Klaxxi'vess
  --questsdata[32023] = {nil, achi(7601,6) ,nil,nil,{858, 55.2, 71.2},nil,1}--Z.DREAD_WASTES Soggy's Gamble
  --questsdata[32027] = {nil, achi(7601,7) ,nil,nil,{806, 45.7, 43.6},nil,1}--Z.THE_JADE_FOREST Dawn's Blossom
  --questsdata[32029] = {nil, achi(7601,8) ,nil,nil,{806, 48.0, 34.6},nil,1}--Z.THE_JADE_FOREST Greenstone Village
  --questsdata[32032] = {nil, achi(7601,9) ,nil,nil,{806, 54.6, 63.3},nil,1}--Z.THE_JADE_FOREST Jade Temple Grounds
  --questsdata[32031] = {nil, achi(7601,10),nil,nil,{806, 55.7, 24.4},nil,1}--Z.THE_JADE_FOREST Sri-La Village
  --questsdata[32021] = {nil, achi(7601,11),nil,nil,{806, 41.6, 23.1},nil,1}--Z.THE_JADE_FOREST Tian Monastery
  --questsdata[32034] = {nil, achi(7601,12),nil,nil,{857, 51.4, 77.2},nil,1}--Z.KRASARANG_WILDS Marista
  --questsdata[32036] = {nil, achi(7601,13),nil,nil,{857, 75.9, 6.87},nil,1}--Z.KRASARANG_WILDS Zhu's Watch
  --questsdata[32039] = {nil, achi(7601,14),nil,nil,{809, 72.7, 92.2},nil,1}--Z.KUN_LAI_SUMMIT Binan Village
  --questsdata[32041] = {nil, achi(7601,16),nil,nil,{809, 64.2, 61.2},nil,1}--Z.KUN_LAI_SUMMIT The Grummle Bazaar
  --questsdata[32037] = {nil, achi(7601,15),nil,nil,{809, 57.4, 59.9},nil,1}--Z.KUN_LAI_SUMMIT One Keg
  --questsdata[32051] = {nil, achi(7601,17),nil,nil,{809, 62.3, 29  },nil,1}--Z.KUN_LAI_SUMMIT Zouchin Village
  --questsdata[32026] = {nil, achi(7601,18),nil,nil,{873, 55.0, 72.2},nil,1}--Z.THE_VEILED_STAIR Tavern in the Mists
  --questsdata[32043] = {nil, achi(7601,19),nil,nil,{810, 71.1, 57.8},nil,1}--Z.TOWNLONG_STEPPES Longying Outpost
  --questsdata[32044] = {nil, achi(7601,20),nil,nil,{811, 35.1, 77.7},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Mistfall Village
  --questsdata[32048] = {nil, achi(7601,21),nil,nil,{807, 83.6, 20.1},nil,1}--Z.VALLEY_OF_THE_FOUR_WINDS Pang's Stead
  --questsdata[32046] = {nil, achi(7601,22),nil,nil,{807, 19.8, 55.7},nil,1}--Z.VALLEY_OF_THE_FOUR_WINDSStoneplow
  
  questsdata[32024] = {nil, "Dread Wastes",nil,nil,{858, 55.9, 32.2},nil,1}--Z.DREAD_WASTES Klaxxi'vess
  questsdata[32023] = {nil, "Dread Wastes",nil,nil,{858, 55.2, 71.2},nil,1}--Z.DREAD_WASTES Soggy's Gamble
  questsdata[32027] = {nil, "The Jade Forest",nil,nil,{806, 45.7, 43.6},nil,1}--Z.THE_JADE_FOREST Dawn's Blossom
  questsdata[32029] = {nil, "The Jade Forest",nil,nil,{806, 48.0, 34.6},nil,1}--Z.THE_JADE_FOREST Greenstone Village
  questsdata[32032] = {nil, "The Jade Forest",nil,nil,{806, 54.6, 63.3},nil,1}--Z.THE_JADE_FOREST Jade Temple Grounds
  questsdata[32031] = {nil, "The Jade Forest",nil,nil,{806, 55.7, 24.4},nil,1}--Z.THE_JADE_FOREST Sri-La Village
  questsdata[32021] = {nil, "The Jade Forest",nil,nil,{806, 41.6, 23.1},nil,1}--Z.THE_JADE_FOREST Tian Monastery
  questsdata[32034] = {nil, "Krasarang Wilds",nil,nil,{857, 51.4, 77.2},nil,1}--Z.KRASARANG_WILDS Marista
  questsdata[32036] = {nil, "Krasarang Wilds",nil,nil,{857, 75.9, 6.87},nil,1}--Z.KRASARANG_WILDS Zhu's Watch
  questsdata[32039] = {nil, "Kun-Lai Summit",nil,nil,{809, 72.7, 92.2},nil,1}--Z.KUN_LAI_SUMMIT Binan Village
  questsdata[32041] = {nil, "Kun-Lai Summit",nil,nil,{809, 64.2, 61.2},nil,1}--Z.KUN_LAI_SUMMIT The Grummle Bazaar
  questsdata[32037] = {nil, "Kun-Lai Summit",nil,nil,{809, 57.4, 59.9},nil,1}--Z.KUN_LAI_SUMMIT One Keg
  questsdata[32051] = {nil, "Kun-Lai Summit",nil,nil,{809, 62.3, 29  },nil,1}--Z.KUN_LAI_SUMMIT Zouchin Village
  questsdata[32026] = {nil, "The Veiled Stair",nil,nil,{873, 55.0, 72.2},nil,1}--Z.THE_VEILED_STAIR Tavern in the Mists
  questsdata[32043] = {nil, "Townlong Steppes",nil,nil,{810, 71.1, 57.8},nil,1}--Z.TOWNLONG_STEPPES Longying Outpost
  questsdata[32044] = {nil, "Vale of Eternal Blossoms",nil,nil,{811, 35.1, 77.7},nil,1}--Z.VALE_OF_ETERNAL_BLOSSOMS Mistfall Village
  questsdata[32048] = {nil, "Valley of the four winds",nil,nil,{807, 83.6, 20.1},nil,1}--Z.VALLEY_OF_THE_FOUR_WINDS Pang's Stead
  questsdata[32046] = {nil, "Valley of the four winds",nil,nil,{807, 19.8, 55.7},nil,1}--Z.VALLEY_OF_THE_FOUR_WINDSStoneplow
end

list.Initialize = setup_faction_orders
list.GenerateData = GenerateQuestsData
DailyGlobalCheck:LoadPlugin(list, questsdata)
