-- Daily Global Check - Garrison Work Orders plugin
-- Vildiesel EU-Well of Eternity

local tinsert, min, max, sort = table.insert, math.min, math.max, table.sort

local addonName, addonTable = ...

local LE_GARRISON_TYPE_6_0 = 2
local LE_GARRISON_TYPE_7_0 = 3

local getcharname = DailyGlobalCheck.GetModCharName

local pID
local pTable
local classIndex = select(3, UnitClass("player"))
local questsdata = {}
local order_cache = { wod = {}, legion_follower = {}, legion_loose = {}, legion_talent = {} }
local order_index = {wod = 1, legion_follower = 2, legion_loose = 3, legion_talent = 4}
local order = {{}}

local questID_pref = "workorders_"

local plugintitle = "Work Orders"
local pluginicon = "Interface\\Icons\\Garrison_Building_Lumbermill"
local plugin_data

local wo_per_type = {wod_small = 3, wod_medium = 2, wod_large = 2, legion_follower = 4, legion_loose = 2}
local buildings = { 
                   wod_garden   = {29,136,137},
				   wod_mine     = {61,62,63},
				   wod_shipyard = {12},
                   wod_large    = {8,9,10,37,38,39,162,163,164},
				   wod_medium   = {24,25,133,40,41,138,159,160,161,111,144,145},
				   wod_small    = {60,117,118,76,119,120,90,121,122,91,123,124,93,125,126,94,127,128,95,129,130,96,131,132},
                  }
local building_counters

local tmp = {}
local function ResolveTimer(s)
 local hours, mins, secs

 wipe(tmp)
 for n in s:gmatch("%d+") do tmp[#tmp + 1] = n end

 if not tmp[1] then 
  return 0
 elseif tmp[2] then
  hours = tmp[1]
  mins  = tmp[2]
 else
  mins = tmp[1]
 end

 secs = (hours and hours * 3600 or 0) + mins * 60

 return secs
end

local function formattime(s)
 --return string.format("%.2d:%.2d:%.2d", s/(60*60), s/60%60, s%60)
 --return string.format("%.2dh:%.2dm", s/(3600), s/60%60)
 return SecondsToTime(s)
end

local function isquestcompleted(questID)
 local current_pID = DailyGlobalCheck.selectedpID

 local t = pTable[current_pID] and pTable[current_pID].data and pTable[current_pID].data[questID]

 if not t then return false end
 
 local queue = t.WOqueue or 0
 local ready = t.WOready or 0
 local tot = (t.WOtot or 0) > 1 and (HIGHLIGHT_FONT_COLOR_CODE.." ("..(t.WOtot or 0)..")|r") or ""
 local real_ready = min(ready + (t.plus or 0), ready + queue)
 local result = GREEN_FONT_COLOR_CODE..real_ready.." / "..(ready + queue)..tot
 local now = time()
 local suff
 if (t.t or 0) - now > 0 then
  suff = " "..RED_FONT_COLOR_CODE..formattime((t.t or 0) - now).."|r"
 else
  suff = ""
 end
 if real_ready > 0 then
  return true, result..suff
 else
  return false, result..suff
 end
end

local found = {}
local function update()
 local pID = DailyGlobalCheck.selectedpID
 wipe(order[1])
 for _,v in pairs(order_cache) do
  wipe(v)
 end
 
 order_cache.wod[1]  = GARRISON_LOCATION_TOOLTIP
 order_cache.legion_follower[1] = ORDER_HALL_FOLLOWERS
 order_cache.legion_loose[1]  = OTHER
 order_cache.legion_talent[1]  = TALENT

 if not pTable[pID] or not pTable[pID].data then
  return
 end
 
 wipe(found)

 for k,v in pairs(questsdata) do
  questsdata[2] = k
  questsdata[4] = nil
 end

 local now = time()
 for k,v in pairs(pTable[pID].data) do
  if questsdata[k] then
   questsdata[k][2] = v.name
   questsdata[k][4] = v.icon
   if v.cat then found[v.cat] = true end
   if (v.t or 0) > 0 and v.WOduration then
    local p = math.floor((now - v.checktime) / v.WOduration)
    v.plus = p > 0 and p or nil
   end
   
   for s,c in pairs(order_cache) do
    if k:find(s) then
     tinsert(c, k)
    end
   end
  end
 end

 local function sort_order(a, b)
  if not pTable[pID].data[a] or not pTable[pID].data[b] then return end
  return (pTable[pID].data[a].name or "") < (pTable[pID].data[b].name or "")
 end
 
 for k in pairs(found) do
  tinsert(order[1], order_cache[k])
  sort(order_cache[k], sort_order)
 end
end

local function setupShipment(questID, now, id, cat, isBuilding)
 local name, icon, maxWO, completedWO, currentWO, creation, WOduration, currWOtimeleft
 if isBuilding then
  name, icon, maxWO, completedWO, currentWO, _, WOduration, currWOtimeleft = C_Garrison.GetLandingPageShipmentInfo(id)
 else
  name, icon, maxWO, completedWO, currentWO, creation, WOduration, currWOtimeleft = C_Garrison.GetLandingPageShipmentInfoByContainerID(id)
 end

 if maxWO and maxWO > 0 then
  if not pTable[pID].data[questID] then pTable[pID].data[questID] = {} end

  pTable[pID].data[questID].cat = cat

  local secsleft
  if creation and creation > 0 then
   local queue = currentWO - completedWO
   local nextWOs = max(0, queue * WOduration)

   secsleft = creation + nextWOs
   pTable[pID].data[questID].WOduration = WOduration
   pTable[pID].data[questID].WOqueue = queue
  elseif currWOtimeleft then
   currWOtimeleft = ResolveTimer(currWOtimeleft)
 
   local queue = currentWO - completedWO
   local nextWOs = max(0, (queue - 1) * WOduration)

   secsleft = currWOtimeleft + nextWOs + now
   pTable[pID].data[questID].WOduration = WOduration
   pTable[pID].data[questID].WOqueue = queue
  else
   pTable[pID].data[questID].WOqueue = nil
   pTable[pID].data[questID].WOduration = nil
  end
 
  local WOavailable = maxWO - (completedWO or 0)
  pTable[pID].data[questID].WOtot = maxWO
 
  pTable[pID].data[questID].plus = nil
  pTable[pID].data[questID].name = name
  pTable[pID].data[questID].t = secsleft
  pTable[pID].data[questID].checktime = now
  pTable[pID].data[questID].WOready = completedWO
  pTable[pID].data[questID].icon = icon and ("|T"..icon..":12|t") or ""
 end
end

local function setupTalent(questID, now, talent, cat)
 local name, icon, completed = talent.name, talent.icon, not talent.isBeingResearched

 if not pTable[pID].data[questID] then pTable[pID].data[questID] = {} end
 
 pTable[pID].data[questID].cat = cat

 local secsleft
 if not completed then
  secsleft = talent.researchStartTime + talent.researchDuration
  pTable[pID].data[questID].WOduration = talent.researchDuration
  pTable[pID].data[questID].WOqueue = 1
  pTable[pID].data[questID].WOready = 0
 else
  pTable[pID].data[questID].WOqueue = nil
  pTable[pID].data[questID].WOduration = nil
  pTable[pID].data[questID].WOready = 1
 end
 
 local WOavailable = 0
 pTable[pID].data[questID].WOtot = 1
 
 pTable[pID].data[questID].plus = nil
 pTable[pID].data[questID].name = name
 pTable[pID].data[questID].t = secsleft
 pTable[pID].data[questID].checktime = now
 pTable[pID].data[questID].icon = icon and ("|T"..icon..":12|t") or ""
end

local function updatePlayer()
 local now = time()

 wipe(pTable[pID].data)
 
 -- wod garrison buildings
 for k in pairs(buildings) do
  building_counters[k] = 1
 end

 for _,b in pairs(C_Garrison.GetBuildings(LE_GARRISON_TYPE_6_0)) do
  for k,v in pairs(buildings) do
   if tContains(v, b.buildingID) then
	setupShipment(questID_pref..k..building_counters[k], now, b.buildingID, "wod", true)
	building_counters[k] = building_counters[k] + 1
   end
  end
 end

 for k in pairs(buildings) do
  local i = building_counters[k]
  while i <= (wo_per_type[k] or 1) do
   pTable[pID].data[questID_pref..k..i] = nil
   i = i + 1
  end
 end
 --

 -- class hall followers
 local counter = 1
 
 for k,v in pairs(C_Garrison.GetFollowerShipments(LE_GARRISON_TYPE_7_0)) do
  setupShipment(questID_pref.."legion_follower"..counter, now, v, "legion_follower")
  counter = counter + 1
 end
 
 for i = counter, wo_per_type.legion_follower do
  pTable[pID].data[questID_pref.."legion_follower"..i] = nil
 end
 
 -- loose shipments
 counter = 1
 
 for k,v in pairs(C_Garrison.GetLooseShipments(LE_GARRISON_TYPE_7_0)) do
  setupShipment(questID_pref.."legion_loose"..counter, now, v, "legion_loose")
  counter = counter + 1
 end
 
 for i = counter, wo_per_type.legion_loose do
  pTable[pID].data[questID_pref.."legion_loose"..i] = nil
 end

 -- class hall talents
 counter = false
 --local talentTrees = C_Garrison.GetTalentTrees(LE_GARRISON_TYPE_7_0, classIndex)
 local talentTrees = C_Garrison.GetTalentTreeInfoForID(LE_GARRISON_TYPE_7_0, 0)
 local completeTalentID = C_Garrison.GetCompleteTalent(LE_GARRISON_TYPE_7_0)
 if talentTrees then
  for treeIndex, tree in ipairs(talentTrees) do
   for talentIndex, talent in ipairs(tree) do
 	local showTalent = talent.isBeingResearched or talent.id == completeTalentID
 	if showTalent then
	 counter = true
 	 setupTalent(questID_pref.."legion_talent1", now, talent, "legion_talent")
 	end
   end
  end
 end
 
 if not counter then
  pTable[pID].data[questID_pref.."legion_talent1"] = nil
 end
 
 update()
end

local function GenerateData()
 for k in pairs(buildings) do
  for i = 1, wo_per_type[k] or 1 do
   local questID = questID_pref..k..i
   questsdata[questID] = {nil, questID, [7] = 14, [10] = isquestcompleted}
  end
 end
 
 for i = 1, wo_per_type.legion_follower do
  local questID = questID_pref.."legion_follower"..i
  questsdata[questID] = {nil, questID, [7] = 14, [10] = isquestcompleted}
 end
 
 for i = 1, wo_per_type.legion_loose do
  local questID = questID_pref.."legion_loose"..i
  questsdata[questID] = {nil, questID, [7] = 14, [10] = isquestcompleted}
 end
 
 local questID = questID_pref.."legion_talent1"
 questsdata[questID] = {nil, questID, [7] = 14, [10] = isquestcompleted}
end

local function onDraw(list)
 if list ~= plugin_data then return end
 if DailyGlobalCheck.selectedpID == pID then
  updatePlayer()
 else
  update()
 end
end

local function option_changed(opt, value, list)
 if list ~= plugin_data then return end
 pTable[pID].Options[opt] = value
end

-- work order zone names
-- Z[1014] dalaran
local garrison_names = {DailyGlobalCheck.Z[971], DailyGlobalCheck.Z[976]}

local function inGarrison()
 return C_Garrison.IsPlayerInGarrison(LE_GARRISON_TYPE_7_0) or tContains(garrison_names, GetZoneText()) or GetCurrentMapAreaID() == 1014
end

local function Initialize()
 local pName = GetUnitName("player")
 local pRealm = GetRealmName()
 pID = pName.."-"..pRealm

 if not DGC_WOSaves  then DGC_WOSaves = {} end
 if not DGC_WOSaves[pID] then DGC_WOSaves[pID] = {} end
 
 pTable = DGC_WOSaves
 if not pTable[pID].data then pTable[pID].data = {} end
 if not pTable[pID].Options then pTable[pID].Options = {} end
 
 C_Garrison.RequestLandingPageShipmentInfo()

 building_counters = {}

 local t = time()
 local eventframe = CreateFrame("FRAME")
 eventframe:RegisterEvent("GARRISON_FOLLOWER_ADDED")
 eventframe:RegisterEvent("GARRISON_LANDINGPAGE_SHIPMENTS")
 eventframe:RegisterEvent("SHIPMENT_CRAFTER_CLOSED")
 eventframe:RegisterEvent("CHAT_MSG_LOOT")
 eventframe:RegisterEvent("CHAT_MSG_CURRENCY")
 local function eventhandler(self, event, ...)
  if event == "CHAT_MSG_LOOT" or event == "CHAT_MSG_CURRENCY" or event == "GARRISON_FOLLOWER_ADDED" then
   currenttime = time()
   if inGarrison() and currenttime > t + 1 then
    C_Garrison.RequestLandingPageShipmentInfo()
   end
   t = currenttime
  elseif event == "GARRISON_LANDINGPAGE_SHIPMENTS" then
   updatePlayer()
  elseif event == "SHIPMENT_CRAFTER_CLOSED" then
   C_Garrison.RequestLandingPageShipmentInfo()
  end
 end

 eventframe:SetScript("OnEvent", eventhandler)
 
 DGCEventFrame:Hook("ON_DRAW", onDraw)
 
  local function enhance_completion(questID, data)
  local svar = DailyGlobalCheck_PluginData[plugintitle] and DailyGlobalCheck_PluginData[plugintitle].options
  if (svar and svar[1] == false) or
     DailyGlobalCheck.SelectedList ~= plugin_data or not DailyGlobalCheck.cs or type(questID) ~= "string" or 
     questID:sub(1, 6) ~= "oview_" then return end
  local id = questID:sub(7, #questID)
 
  if not pTable[id] then return end

  local now = time()
  local t, found = 0
  for _,wo in pairs(pTable[id].data) do
   if wo.t and wo.t - now > t then
    t = wo.t - now
    found = true
   end
  end

  if found then
   DailyGlobalCheck.cs = "|cffff0000"..SecondsToTime(t).."|r - "..DailyGlobalCheck.cs
  end
 end

 DGCEventFrame:Hook("ON_DRAW_COMPLETION", enhance_completion)
end

plugin_data = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = order,
 ["Initialize"] = Initialize,
 ["GenerateData"] = GenerateData,
 ["Options"] = {
				{"Checkbox","Show longest timer in Overview mode",true},
			   },
 }

DailyGlobalCheck:LoadPlugin(plugin_data, questsdata)

