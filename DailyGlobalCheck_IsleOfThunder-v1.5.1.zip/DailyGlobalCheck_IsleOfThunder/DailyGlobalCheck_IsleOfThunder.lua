﻿-- Daily Global Check - Isle of Thunder plugin
-- Jadya - EU-Well of Eternity

local questsdata = {}

local list = {
  ["Title"] = "Isle of Thunder",
  ["Icon"]  = "Interface\\ICONS\\inv_qiraj_jewelglyphed",
  ["Version"] = 1004,
  ["Order"] = {{{"General",32626,32610,32609,32708,32640,32641,32505,32611,32518}}},
 }

local function GenerateData()
 local Z = DailyGlobalCheck.Z
 local l = DailyGlobalCheck.LocalizeSection
 
 local nalak_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Nalak:14|t"
 
 questsdata[32626] = {Z[928],l(questsdata, 32626, 2, "Key to the Palace of Lei Shen", "item", 94222, 1)                                      ,nil,nil,nil,nil,3}
 questsdata[32610] = {Z[928],l(questsdata, 32610, 2, "Shan'ze Ritual Stone", "item", 94221, 1,nil," ("..EXAMPLE_TARGET_MONSTER..")") ,nil,nil,nil,nil,3}
 questsdata[32609] = {Z[928],l(questsdata, 32609, 2, "Shan'ze Ritual Stone", "item", 94221, 1,nil," (Chest)")                        ,nil,nil,nil,nil,3}
 questsdata[32708] = {Z[928],l(questsdata, 32708, 2, "Setting the Trap", "quest", 32708)                                                        ,nil,nil,{928, 51, 46},nil,1,nil,function() return not IsQuestFlaggedCompleted(32708) end}
 questsdata[32640] = {Z[928],l(questsdata, 32640, 2, "Champions of the Thunder King","quest", 32640)                                            ,nil,nil,{928, 51, 46},nil,3,nil,function() return IsQuestFlaggedCompleted(32708) and UnitFactionGroup("player") == "Horde" end}
 questsdata[32641] = {Z[928],l(questsdata, 32641, 2, "Champions of the Thunder King","quest", 32641)                                            ,nil,nil,{928, 51, 46},nil,3,nil,function() return IsQuestFlaggedCompleted(32708) and UnitFactionGroup("player") == "Alliance" end}
 questsdata[32505] = {Z[928],l(questsdata, 32505, 2, "The Crumbled Chamberlain", "quest", 32505)                                                ,nil,nil,nil,nil,3}

 questsdata[32611] = {Z[928],"Incantation",nil,nil,nil,nil,3}
 questsdata[32518] = {Z[928],EJ_GetEncounterInfo(814),nalak_icon,nil,{928, 61, 36},nil,3}
end

list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)