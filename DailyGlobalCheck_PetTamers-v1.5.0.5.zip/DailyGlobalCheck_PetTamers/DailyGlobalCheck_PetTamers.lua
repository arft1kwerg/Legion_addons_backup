-- Daily Global Check - Pet Tamers plugin
-- Vildiesel EU-Well of Eternity
local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z
local WQ = DailyGlobalCheck.WorldQuests

--
local epspecial = "#elitepets#"
local ep_quest_missing = "|cffFF0000"..string.format(ITEM_MISSING,BATTLE_PET_SOURCE_2).."|r"

---------- elite pets methods -----------
local ep_books = { { index = -1, qname = "", completed = false, pets = {1,2,3,4}, questID = 32604},
				   { index = -1, qname = "", completed = false, pets = {5,6,7},   questID = 32868},
                   { index = -1, qname = "", completed = false, pets = {8,9,10},  questID = 32869}
                 }
				 
local function EP_resetbooks()
 table.foreach(ep_books, function(k,v)
  v.index = -1
  v.completed = false
 end)
end

local function EP_GetBook_pet(pet)
 if type(pet) ~= "number" then
  pet = tonumber(pet)
 end

 if pet < 1 or pet > 10 then return nil end
 
 if pet <= 4 then
  return ep_books[1] 
 elseif pet <= 7 then
  return ep_books[2]
 else
  return ep_books[3]
 end
end

local function EP_iscriteriacompleted(pet)
 local result = false
 local book = EP_GetBook_pet(pet)
 if book and not book.completed and book.index > -1 then
  local _,_,done = GetQuestLogLeaderBoard(pet - (book.pets[1] - 1), book.index)
  result = done
 end
 return result
end

local function getelitepetname(pet)
 local desc
 local book = EP_GetBook_pet(pet)
 if book and book.index > -1 then
  desc,_,_ = GetQuestLogLeaderBoard(pet - (book.pets[1] - 1),book.index)
  return desc
 end
end

local function isquestcompleted(questID)
 if tostring(questID):find(epspecial) then
  return EP_iscriteriacompleted(string.gsub(tostring(questID), epspecial, ""))
 elseif questID == "book1c" or questID == "book2c" or questID == "book3c" then
  return true
 elseif questID == "tamers_pvpH" or questID == "tamers_pvpA" then
  return IsQuestFlaggedCompleted(32863)
 end
end
---------------------
local questsdata = {}

local plugin_data = {
 ["Title"] = "Pet Tamers",
 ["Icon"]  = "Interface\\ICONS\\INV_MISC_PETMOONKINTA",
 ["Version"] = 1004,
 ["Order"] = {
            -- page 1
                {
                 -- legion
                 {EXPANSION_NAME6,40310,45083,45539,46292},
                 {Z[962],37201,37203,37205,37208,37206,37207},
				 {Z[945],39157,39160,39161,39162,39163,39164,39165,39166,39167,39168,39169,39170,39171,39172,39173},
				 {GARRISON_LOCATION_TOOLTIP,40329,36483,36662,38299,38300},
				 {BATTLE_PET_SOURCE_7,32175,36471}},
            -- page 2
               {{"Pandaren Spirits",32434,32439,32441,32440},
                {"Pandaria Satchels",31957,31991,31956,31955,31954,31953,31958},
                {Z[951],33137,33222},
                {"Other Satchels",31916,31909,31926,31935,31971},
                {CALENDAR_TYPE_PVP,"tamers_pvpA","tamers_pvpH"}},
		 	-- page 3
		 	   {{Z[13].." ("..string.format(RACE_CLASS_ONLY, FACTION_HORDE)..")",31818,31819,31854,31862,31872,31904,31871,31905,31906,31907,31908},
		 	    {Z[14].." ("..string.format(RACE_CLASS_ONLY, FACTION_ALLIANCE)..")",31693,31780,31781,31850,31852,31851,31910,31911,31912,31913,31914}},
		    -- page 4
			   {{Z[466],31922,31923,31924,31925},
			    {Z[485],31931,31934,31932,31933},
			    {EXPANSION_NAME3,31973,31972,31974},
			    {"",epspecial..1,epspecial..2,epspecial..3,epspecial..4,"book1c"},
			    {"",epspecial..5,epspecial..6,epspecial..7,"book2c"},
			    {"",epspecial..8,epspecial..9,epspecial..10,"book3c"}}
			 },
}

local playerfaction = UnitFactionGroup("PLAYER")
local function showhorde()
 return playerfaction == "Horde"
end

local function showally()
 return playerfaction == "Alliance"
end

local WEfound = {}
local function GenerateQuestsData()
 local l = DailyGlobalCheck.LocalizeSection

 -- pet family icons
 local pfme  = "|TInterface\\icons\\Icon_PetFamily_Mechanical:12|t"
 local pfbe  = "|TInterface\\icons\\Icon_PetFamily_Beast:12|t"
 local pfhu  = "|TInterface\\icons\\Icon_PetFamily_Humanoid:12|t"
 local pfdr  = "|TInterface\\icons\\Icon_PetFamily_Dragon:12|t"
 local pffl  = "|TInterface\\icons\\Icon_PetFamily_Flying:12|t"
 local pfcr  = "|TInterface\\icons\\Icon_PetFamily_Critter:12|t"
 local pfma  = "|TInterface\\icons\\Icon_PetFamily_Magical:12|t"
 local pfun  = "|TInterface\\icons\\Icon_PetFamily_Undead:12|t"
 local pfwa  = "|TInterface\\icons\\Icon_PetFamily_Water:12|t"
 local pfel  = "|TInterface\\icons\\Icon_PetFamily_Elemental:12|t"
 --
 local icon_firespirit  = "Interface\\icons\\INV_Pet_PandarenElemental_Fire"
 local icon_waterspirit = "Interface\\icons\\Inv_pet_PandarenElemental"
 local icon_earthspirit = "Interface\\icons\\INV_Pet_PandarenElemental_Earth"
 local icon_airspirit   = "Interface\\icons\\INV_Pet_PandarenElemental_Air"
 --
 local tx_bagicon = "Interface\\icons\\INV_Misc_Bag_CenarionHerbBag"
 local ep_icon    = "Interface\\icons\\Ability_Mount_WhiteDireWolf"

 local function ep_show1()
  return not isquestcompleted(ep_books[1].questID)
 end
 
 local function ep_show2()
  return not isquestcompleted(ep_books[2].questID)
 end
 
 local function ep_show3()
  return not isquestcompleted(ep_books[3].questID)
 end
 
 -- order localization
 plugin_data.Order[4][4][1] = l(plugin_data.Order[4][4], nil, 1, "Beasts of Fable Book I", "quest", 32604)
 plugin_data.Order[4][5][1] = l(plugin_data.Order[4][5], nil, 1, "Beasts of Fable Book II", "quest", 32868)
 plugin_data.Order[4][6][1] = l(plugin_data.Order[4][6], nil, 1, "Beasts of Fable Book III", "quest", 32869)
 
 -- Legion --
 -- Sternfathom's Pet Journal
 questsdata[45083] = {Z[11]  ,l(questsdata, 45083, 2, "Crysa's Flyers", "quest", 45083)                       ,25,pffl..pffl..pffl,{11, 63.58, 35.81},nil,15}
 questsdata[40310] = {Z[1015],l(questsdata, 40310, 2, "Sternfathom's Pet Journal", "item", 122681, 1)         ,25,nil,nil,nil,16}
 questsdata[45539] = {Z[11]  ,l(questsdata, 45539, 2, "Pet Battle Challenge: Wailing Caverns", "quest", 45539),25,nil,{11, 38.95, 68.11},nil,16}
 questsdata[46292] = {Z[39]  ,l(questsdata, 46292, 2, "Pet Battle Challenge: Deadmines", "quest", 46292),25,nil,{39, 41.54, 71.12},nil,16}

  -- Tanaan Jungle --
 questsdata[39157] = {Z[945],"Felsworn Sentry"      ,25,pfme,{945, 26.1, 31.6},nil,nil,tx_wod_bagicon} -- felsworn sentry
 questsdata[39160] = {Z[945],"Corrupted Thundertail",25,pfbe,{945, 53  , 65.2},nil,nil,tx_wod_bagicon} -- corrupted thundertail
 questsdata[39161] = {Z[945],"Chaos Pup"            ,25,pfbe,{945, 25  , 76.4},nil,nil,tx_wod_bagicon} -- chaos pup
 questsdata[39162] = {Z[945],"Cursed Spirit"        ,25,pfun,{945, 31.2, 38.2},nil,nil,tx_wod_bagicon} -- cursed spirit
 questsdata[39163] = {Z[945],"Felfly"               ,25,pffl,{945, 55.9, 80.8},nil,nil,tx_wod_bagicon} -- felfly
 questsdata[39164] = {Z[945],"Tainted Maulclaw"     ,25,pfwa,{945, 43.2, 84.5},nil,nil,tx_wod_bagicon} -- tainted maulclaw
 questsdata[39165] = {Z[945],"Direflame"            ,25,pfel,{945, 57.6, 37.2},nil,nil,tx_wod_bagicon} -- direflame
 questsdata[39166] = {Z[945],"Mirecroak"            ,25,pfwa,{945, 42.3, 71.8},nil,nil,tx_wod_bagicon} -- mirecroak
 questsdata[39167] = {Z[945],"Dark Gazer"           ,25,pfma,{945, 54  , 30  },nil,nil,tx_wod_bagicon} -- dark gazer  pfma..pffl..pfwa?
 questsdata[39168] = {Z[945],"Bleakclaw"            ,25,pffl,{945, 16  , 44.6},nil,nil,tx_wod_bagicon} -- bleakclaw
 questsdata[39169] = {Z[945],"Vile Blood of Draenor",25,pfma,{945, 43.8, 45.8},nil,nil,tx_wod_bagicon} -- vile blood of draenor
 questsdata[39170] = {Z[945],"Dreadwalker"          ,25,pfme,{945, 47.2, 52.6},nil,nil,tx_wod_bagicon} -- dreadwalker
 questsdata[39171] = {Z[945],"Netherfist"           ,25,pfhu,{945, 48.4, 35.6},nil,nil,tx_wod_bagicon} -- netherfist
 questsdata[39172] = {Z[945],"Skrillix"             ,25,pfhu,{945, 48.6, 31.2},nil,nil,tx_wod_bagicon} -- skrillix
 questsdata[39173] = {Z[945],"Defiled Earth"        ,25,pfel,{945, 75.4, 37.4},nil,nil,tx_wod_bagicon} -- defiled earth
 
 -- Garrison --
 questsdata[40329] = {Z[showally() and 971 or 976],l(questsdata, 40329, 2, "Garrison" , "quest", 40329),25,nil,nil,nil,16}
 questsdata[36483] = {Z[971]                      ,GARRISON_LOCATION_TOOLTIP,25,nil,{971, 28.9 , 42.8 },nil,nil,tx_wod_bagicon,showally}
 questsdata[36662] = {Z[976]                      ,GARRISON_LOCATION_TOOLTIP,25,nil,{976, 32.06, 43.59},nil,nil,tx_wod_bagicon,showhorde}
 questsdata[38299] = {Z[971]                      ,"Erris"                  ,25,nil,{971, 28.9 , 42.8 },nil,15,tx_wod_bagicon,showally}
 questsdata[38300] = {Z[976]                      ,"Kura"                   ,25,nil,{976, 32.06, 43.59},nil,15,tx_wod_bagicon,showhorde}

 -- Draenor --
 questsdata[37203] = {Z[947],l(questsdata, 37203, 2, "Ashlei"           , "quest", 37203),25,pfma..pfma..pfbe,{947, 50  , 30  },nil,15} -- ashlei
 questsdata[37205] = {Z[941],l(questsdata, 37205, 2, "Gargra"           , "quest", 37205),25,pfbe..pfbe..pfbe,{941, 68.6, 64.7},nil,15} -- gargra
 questsdata[37206] = {Z[950],l(questsdata, 37206, 2, "Tarr the Terrible", "quest", 37206),25,pfhu..pfhu..pfhu,{950, 56.2, 9.8 },nil,15} -- tarr
 questsdata[37208] = {Z[946],l(questsdata, 37208, 2, "Taralune"         , "quest", 37208),25,pffl..pffl..pffl,{946, 49.1, 80.4},nil,15} -- taralune
 questsdata[37201] = {Z[949],l(questsdata, 37201, 2, "Cymre Brightblade", "quest", 37201),25,pfun..pfma..pfme,{949, 51  , 71  },nil,15} -- cymre
 questsdata[37207] = {Z[948],l(questsdata, 37207, 2, "Vesharr"          , "quest", 37207),25,pffl..pfme..pffl,{948, 46.3, 45.3},nil,15} -- vesharr

 -- Pandaren Spirits --
 questsdata[32434] = {Z[810],l(questsdata, 32434, 2, "Pandaren Fire Spirit" , "quest", 32434),"|T"..icon_firespirit..":12|t25",pfdr..pfel..pffl ,{810, 57, 42},nil,15,icon_firespirit}
 questsdata[32439] = {Z[858],l(questsdata, 32439, 2, "Pandaren Water Spirit", "quest", 32439),"|T"..icon_waterspirit..":12|t25",pfwa..pfcr..pfel,{858, 61, 88},nil,15,icon_waterspirit}
 questsdata[32441] = {Z[809],l(questsdata, 32441, 2, "Pandaren Earth Spirit", "quest", 32441),"|T"..icon_earthspirit..":12|t25",pfel..pfma..pfbe,{809, 65, 94},nil,15,icon_earthspirit}
 questsdata[32440] = {Z[806],l(questsdata, 32440, 2, "Pandaren Air Spirit"  , "quest", 32440),"|T"..icon_airspirit..":12|t25",pffl..pfdr..pfel  ,{806, 29, 36},nil,15,icon_airspirit}
 -- Pandaria --
 questsdata[31953] = {Z[806],l(questsdata, 31953, 2, "Grand Master Hyuna" , "quest", 31953),25,pffl..pfbe..pfwa,{806, 48, 54},nil,15,tx_bagicon}
 questsdata[31955] = {Z[807],l(questsdata, 31955, 2, "Grand Master Nishi" , "quest", 31955),25,pfel..pfel..pfbe,{807, 46, 44},nil,15,tx_bagicon}
 questsdata[31954] = {Z[857],l(questsdata, 31954, 2, "Grand Master Mo'ruk", "quest", 31954),25,pfbe..pffl..pfwa,{857, 62, 45},nil,15,tx_bagicon}
 questsdata[31956] = {Z[809],l(questsdata, 31956, 2, "Grand Master yon"   , "quest", 31956),25,pffl..pfcr..pfbe,{809, 36, 74},nil,15,tx_bagicon}
 questsdata[31991] = {Z[810],l(questsdata, 31991, 2, "Grand Master Zusshi", "quest", 31991),25,pfel..pfcr..pfwa,{810, 36, 52},nil,15,tx_bagicon}
 questsdata[31957] = {Z[858],l(questsdata, 31957, 2, "Grand Master Shu"   , "quest", 31957),25,pfwa..pfel..pfbe,{858, 55, 38},nil,15,tx_bagicon}
 questsdata[31958] = {Z[811],l(questsdata, 31958, 2, "Grand Master Aki"   , "quest", 31958),25,pfcr..pfdr..pfwa,{811, 31, 74},nil,15,tx_bagicon}
 -- Outlands --
 questsdata[31922] = {Z[465],l(questsdata, 31922, 2, "Nicki Tinytech"     , "quest", 31922),20,pfme..pfme..pfme,{465, 64, 49},nil,15}
 questsdata[31923] = {Z[467],l(questsdata, 31923, 2, "Ras'an"             , "quest", 31923),21,pffl..pfhu..pfma,{467, 17, 50},nil,15}
 questsdata[31924] = {Z[477],l(questsdata, 31924, 2, "Narrok"             , "quest", 31924),22,pfwa..pfcr..pfbe,{477, 61, 49},nil,15}
 questsdata[31925] = {Z[481],l(questsdata, 31925, 2, "Morulu The Elder"   , "quest", 31925),23,pfwa..pfwa..pfwa,{481, 59, 70},nil,15}
 questsdata[31926] = {Z[473],l(questsdata, 31926, 2, "Grand Master Antari", "quest", 31926),24,pfma..pfel..pfdr,{473, 31, 42},nil,15,tx_bagicon}
 -- Northrend --
 questsdata[31931] = {Z[491],l(questsdata, 31931, 2, "Beegle Blastfuse"     , "quest", 31931),25,pffl..pfwa..pffl,{491, 29, 34},nil,15}
 questsdata[31933] = {Z[488],l(questsdata, 31933, 2, "Okrut Dragonwaste"    , "quest", 31933),25,pfdr..pfun..pfun,{488, 59, 77},nil,15}
 questsdata[31934] = {Z[496],l(questsdata, 31934, 2, "Gutretch"             , "quest", 31934),25,pfbe..pfbe..pfcr,{496, 13, 67},nil,15}
 questsdata[31932] = {Z[510],l(questsdata, 31932, 2, "Nearly Headless Jacob", "quest", 31932),25,pfun..pfun..pfun,{510, 50, 59},nil,15}
 questsdata[31935] = {Z[492],l(questsdata, 31935, 2, "Grand Master Payne"   , "quest", 31935),25,pfbe..pfme..pfel,{492, 77, 20},nil,15,tx_bagicon}
 -- Cataclysm --
 questsdata[31972] = {Z[606],l(questsdata, 31972, 2, "Brok"               , "quest", 31972),25,pfma..pfbe..pfcr,{606, 61, 33},nil,15}
 questsdata[31973] = {Z[640],l(questsdata, 31973, 2, "Bordin Steadyfist"  , "quest", 31973),25,pfel..pfcr..pfel,{640, 50, 57},nil,15}
 questsdata[31974] = {Z[700],l(questsdata, 31974, 2, "Goz Banefury"       , "quest", 31974),25,pfel..pfma..pfbe,{700, 57, 57},nil,15}
 questsdata[31971] = {Z[720],l(questsdata, 31971, 2, "Grand Master Obalis", "quest", 31971),25,pfbe..pffl..pfcr,{720, 57, 42},nil,15,tx_bagicon}
 -- Kalimdor --
 questsdata[31818] = {Z[4]  ,l(questsdata, 31818, 2, "Zunta"              , "quest", 31818),2 ,pfbe..pfcr      ,{4  , 44, 28},nil,15,nil}
 questsdata[31819] = {Z[11] ,l(questsdata, 31819, 2, "Dagra the Fierce"   , "quest", 31819),3 ,pfbe..pfbe..pfcr,{11 , 58, 53},nil,15,nil}
 questsdata[31909] = {Z[281],l(questsdata, 31909, 2, "Grand Master Trixxy", "quest", 31909),19,pfdr..pfbe..pffl,{281, 66, 65},nil,15,tx_bagicon}
 questsdata[31904] = {Z[607],l(questsdata, 31904, 2, "Cassandra Kaboom"   , "quest", 31904),11,pfme..pfme..pfme,{607, 39, 79},nil,15,nil}
 questsdata[31854] = {Z[43] ,l(questsdata, 31854, 2, "Analynn"            , "quest", 31854),5 ,pfwa..pfcr..pffl,{43 , 20, 29},nil,15,nil}
 questsdata[31906] = {Z[61] ,l(questsdata, 31906, 2, "Kela Grimtotem"     , "quest", 31906),15,pfbe..pfcr..pfcr,{61 , 32, 33},nil,15,nil}
 questsdata[31862] = {Z[81] ,l(questsdata, 31862, 2, "Zonya the Sadist"   , "quest", 31862),7 ,pfbe..pfbe..pfcr,{81 , 59, 71},nil,15,nil}
 questsdata[31872] = {Z[101],l(questsdata, 31872, 2, "Merda Stronghoof"   , "quest", 31872),9 ,pfwa..pfcr..pfel,{101, 57, 45},nil,15,nil}
 questsdata[31905] = {Z[141],l(questsdata, 31905, 2, "Grazzle the Great"  , "quest", 31905),14,pfdr..pfdr..pfdr,{141, 53, 74},nil,15,nil}
 questsdata[31871] = {Z[121],l(questsdata, 31871, 2, "Traitor Gluk"       , "quest", 31871),13,pfbe..pfcr..pfdr,{121, 60, 50},nil,15,nil}
 questsdata[31907] = {Z[182],l(questsdata, 31907, 2, "Zoltan"             , "quest", 31907),16,pfma..pfma..pfme,{182, 40, 56},nil,15,nil}
 questsdata[31908] = {Z[241],l(questsdata, 31908, 2, "Elena Flutterfly"   , "quest", 31908),17,pfdr..pffl..pfma,{241, 46, 60},nil,15,nil}
    -- Eastern Kingdoms --
 questsdata[31693] = {Z[30] ,l(questsdata, 31693, 2, "Julia Stevens"             , "quest", 31693),2 ,pfbe..pfbe      ,{30 , 42, 84},nil,15,nil}
 questsdata[31914] = {Z[29] ,l(questsdata, 31914, 2, "Durin Darkhammer"          , "quest", 31914),17,pffl..pfcr..pfel,{29 , 25, 47},nil,15,nil}
 questsdata[31850] = {Z[34] ,l(questsdata, 31850, 2, "Eric Davidson"             , "quest", 31850),7 ,pfbe..pfbe..pfbe,{34 , 20, 44},nil,15,nil}
 questsdata[31781] = {Z[36] ,l(questsdata, 31781, 2, "Lindsay"                   , "quest", 31781),5 ,pfcr..pfcr..pfcr,{36 , 33, 52},nil,15,nil}
 questsdata[31912] = {Z[28] ,l(questsdata, 31912, 2, "Kortas Darkhammer"         , "quest", 31912),15,pfdr..pfdr..pfdr,{28 , 35, 27},nil,15,nil}
 questsdata[31852] = {Z[37] ,l(questsdata, 31852, 2, "Steven Lisbane"            , "quest", 31852),9 ,pfbe..pfbe..pfma,{37 , 46, 40},nil,15,nil}
 questsdata[31851] = {Z[673],l(questsdata, 31851, 2, "Bill Buckler"              , "quest", 31851),11,pfhu..pffl..pffl,{673, 51, 73},nil,15,nil}
 questsdata[31913] = {Z[38] ,l(questsdata, 31913, 2, "Everessa"                  , "quest", 31913),16,pffl..pfwa..pfbe,{38 , 76, 41},nil,15,nil}
 questsdata[31910] = {Z[26] ,l(questsdata, 31910, 2, "David Kosse"               , "quest", 31910),13,pfcr..pfbe..pfma,{26 , 62, 54},nil,15,nil}
 questsdata[31780] = {Z[39] ,l(questsdata, 31780, 2, "Old MacDonald"             , "quest", 31780),3 ,pfme..pffl..pfcr,{39 , 61, 19},nil,15,nil}
 questsdata[31916] = {Z[32] ,l(questsdata, 31916, 2, "Grand Master Lydia Accoste", "quest", 31916),19,pfel..pfun..pfun,{32 , 40, 77},nil,15,tx_bagicon}
 questsdata[31911] = {Z[23] ,l(questsdata, 31911, 2, "Deiza Plaguehorn"          , "quest", 31911),14,pfbe..pfbe..pfun,{23 , 67, 54},nil,15,nil}
 
    -- Timeless Isle --
 questsdata[33137] = {Z[951],l(questsdata, 33137, 2, "The Celestial Tournament","quest", 33137),"25+",nil,{951, 35, 59},nil,16}
 -- PvP Weekly
 questsdata["tamers_pvpA"] = {Z[811],l(questsdata, "tamers_pvpA", 2, "What We've Been Training For","quest", 32863),nil,nil,{811, 86, 60},nil,16,nil,showally,isquestcompleted}
 questsdata["tamers_pvpH"] = {Z[811],l(questsdata, "tamers_pvpH", 2, "What We've Been Training For","quest", 32863),nil,nil,{811, 61, 23},nil,16,nil,showhorde,isquestcompleted}
 -- Elite Pets --
 questsdata[epspecial..1]  = {Z[806],l(questsdata, epspecial..1, 2, "Kawi"    , "quest", 32604, 1),"25+",pfcr,{806, 48, 71},nil,15,ep_icon,ep_show1,isquestcompleted} -- Kawi I
 questsdata[epspecial..2]  = {Z[809],l(questsdata, epspecial..2, 2, "Kafi"    , "quest", 32604, 2),"25+",pfbe,{809, 35, 56},nil,15,ep_icon,ep_show1,isquestcompleted} -- kafi I
 questsdata[epspecial..3]  = {Z[809],l(questsdata, epspecial..3, 2, "Dos Ryga", "quest", 32604, 3),"25+",pfwa,{809, 68, 85},nil,15,ep_icon,ep_show1,isquestcompleted} -- dos ryga I
 questsdata[epspecial..4]  = {Z[806],l(questsdata, epspecial..4, 2, "Nitun"   , "quest", 32604, 4),"25+",pfcr,{806, 57, 29},nil,15,ep_icon,ep_show1,isquestcompleted} -- Nitun I
 questsdata["book1c"]      = {"",DONE,nil,nil,nil,nil,nil,nil,function() return isquestcompleted(ep_books[1].questID) end,isquestcompleted}
 questsdata[epspecial..5]  = {Z[807],l(questsdata, epspecial..5, 2, "Greyhoof", "quest", 32868, 1),"25+",pfbe,{807, 25, 78},nil,15,ep_icon,ep_show2,isquestcompleted} -- Greyhoof II
 questsdata[epspecial..6]  = {Z[807],l(questsdata, epspecial..6, 2, "Lucky Yi", "quest", 32868, 2),"25+",pfcr,{807, 40, 43},nil,15,ep_icon,ep_show2,isquestcompleted} -- Lucky Yi II
 questsdata[epspecial..7]  = {Z[857],l(questsdata, epspecial..7, 2, "Xia"     , "quest", 32868, 3),"25+",pfwa,{857, 36, 37},nil,15,ep_icon,ep_show2,isquestcompleted} -- xia II
 questsdata["book2c"]      = {"",DONE,nil,nil,nil,nil,nil,nil,function() return isquestcompleted(ep_books[2].questID) end,isquestcompleted}
 questsdata[epspecial..8]  = {Z[858],l(questsdata, epspecial..8, 2, "Gorespine", "quest", 32869, 1),"25+",pfbe,{858, 26, 50},nil,15,ep_icon,ep_show3,isquestcompleted} -- Gorespine III
 questsdata[epspecial..9]  = {Z[811],l(questsdata, epspecial..9, 2, "No-No"    , "quest", 32869, 2),"25+",pfwa,{811, 11, 70},nil,15,ep_icon,ep_show3,isquestcompleted} -- no-no III
 questsdata[epspecial..10] = {Z[810],l(questsdata, epspecial..10, 2, "Ti'un"   , "quest", 32869, 3),"25+",pfwa,{810, 72, 80},nil,15,ep_icon,ep_show3,isquestcompleted} -- ti'un III
 questsdata["book3c"]      = {"",DONE,nil,nil,nil,nil,nil,nil,function() return isquestcompleted(ep_books[3].questID) end,isquestcompleted}
 questsdata[33222] = {Z[951],l(questsdata, 33222, 2, "Little Tommy Newcomer"  , "quest", 33222),"25+",pfbe,{951, 35, 60},nil,15}
 -- Events
 -- Darkmoon Fairie
 questsdata[32175] = {CALENDAR_FILTER_DARKMOON,l(questsdata, 32175, 2, "Darkmoon Pet Battle!"      , "quest", 32175),"|TInterface\\icons\\INV_Misc_Eye_01:12|t 25",pfma..pfme..pfbe,{823, 47, 60},nil, 15, nil, function() return tContains(WEfound, CALENDAR_FILTER_DARKMOON) end}
 questsdata[36471] = {CALENDAR_FILTER_DARKMOON,l(questsdata, 36471, 2, "A New Darkmoon Challenger!", "quest", 36471),"|TInterface\\icons\\INV_Misc_Eye_01:12|t 25",pfma..pfbe..pfbe,{823, 47, 60},nil, 15, nil, function() return tContains(WEfound, CALENDAR_FILTER_DARKMOON) end}
end

local WEtable = {CALENDAR_FILTER_DARKMOON}

-- check for active world events
local function CheckWorldEventTamers()
 local i
 local accessible
 wipe(WEfound)
 C_Calendar.OpenCalendar()

 local cdate = C_Calendar.GetDate()
 for i = 1,C_Calendar.GetNumDayEvents(0,cdate.monthDay) do
  local title = C_Calendar.GetDayEvent(0, cdate.monthDay, i)
  if title then accessible = true end
  for k,v in pairs(WEtable) do
   if title == v then
    WEfound[#WEfound + 1] = k
   end
  end
 end

 plugin_data["Order"][1][4][1] = #WEfound > 0 and BATTLE_PET_SOURCE_7 or ""
end

-------- world quests --------
local function sortfunc(a, b)
 if type(a) == "string" then return true end
 if type(b) == "string" then return false end
 return C_TaskQuest.GetQuestTimeLeftMinutes(a or 0) < C_TaskQuest.GetQuestTimeLeftMinutes(b or 0)
end

local wq_count
local function setup_wq_order()

 for i = 6, #plugin_data.Order[1][1] do
  plugin_data.Order[1][1][i] = nil
 end

 wq_count = 0
 for k,v in pairs(WQ.Data) do
  local info = WQ.TagInfo[k]
  if info and info[3] == LE_QUEST_TAG_TYPE_PET_BATTLE then
   wq_count = wq_count + 1
   questsdata[k] = v
   plugin_data.Order[1][1][5 + wq_count] = k
  end
 end
end

local function world_quests_update()
 setup_wq_order()
 DailyGlobalCheck:Refresh(plugin_data)
end
------------------------------

local function Initialize()
 C_Timer.After(2, CheckWorldEventTamers)
 if WQ then
  DGCEventFrame:Hook("WORLD_QUESTS_UPDATE", world_quests_update)
 end
end

if WQ then
 WQ:Initialize(plugin_data)
end

plugin_data.Initialize = Initialize
plugin_data.GenerateData = GenerateQuestsData
DailyGlobalCheck:LoadPlugin(plugin_data, questsdata)

