# BigWigs [Mists of Pandaria]

## [v7.3.4-6-g55e1bc2](https://github.com/BigWigsMods/BigWigs_MistsOfPandaria/tree/55e1bc24551748d91b2bdf8657290308fd7bc03f) (2018-07-17)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_MistsOfPandaria/compare/v7.3.4...55e1bc24551748d91b2bdf8657290308fd7bc03f)

- Fix using self in local functions  
- Feng: Split register event calls  
- Update colors and sounds  
- Fix some keys  
- Update for UnitBuff/UnitDebuff  
- Mogushan/WillOfTheEmperor: Fix showing a number instead of text  