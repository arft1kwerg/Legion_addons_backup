# BigWigs [Warlords of Draenor]

## [v7.3.1-3-g083e29d](https://github.com/BigWigsMods/BigWigs_WarlordsOfDraenor/tree/083e29de9113fefddfebc5e07a80c35cf6a2562f) (2018-04-09)
[Full Changelog](https://github.com/BigWigsMods/BigWigs_WarlordsOfDraenor/compare/v7.3.1...083e29de9113fefddfebc5e07a80c35cf6a2562f)

- Update colors and sounds  
- Fix some keys  
- Update for UnitBuff/UnitDebuff  
