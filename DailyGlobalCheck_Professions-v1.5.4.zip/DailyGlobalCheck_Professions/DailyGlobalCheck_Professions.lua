-- Daily Global Check - Professions plugin
-- Vildiesel EU-Well of Eternity

local addonName, addonTable = ...

local low, sfind, sgsub, tinsert = string.lower, string.find, string.gsub, table.insert

DGC_ProfSaves = {}

local pID
local plugintitle = "Professions"
local pluginicon = "Interface\\Icons\\Trade_Alchemy"
local pTable
local plugin_data
local profession_cd_ids = {}

-- seal weekly quests
local seal_quests = {["seal_of_tempered_fate"] = {36055,36058,36060,37452,37453,36057,37458,37459,36054,37454,37455,36056,37456,37457},
                     ["seal_of_broken_fate"]   = {43510,43894,43895,43897,43892,43896,43893,47851,47864,47865}}
-- jewelcrafting garrison dailies
local jc_quests   = {37319,37320,37321,37323,37324,37325}

local function get_cache_reset(pid)
 if DGC_ProfSaves[pid] then 
  return DGC_ProfSaves[pid].garrison_cache_reset
 end
end

local function calculate_garrison_cache_quantity(pid)
 local t = get_cache_reset(pid)
 
 if not t or t == 0 then return "|cffFF0000"..GM_SURVEY_NOT_APPLICABLE.."|r" end
  
 local cap = DGC_ProfSaves[DailyGlobalCheck.selectedpID].garrison_cache_cap or 500
 local result = math.floor((time() - t) / 600)
 if result >= cap then 
  result = cap.." |cffFF0000("..LOC_TYPE_FULL..")|r"
 else
  result = result .. " / "..cap
 end
 return result
end

local function getMaxNodes(s)
 if s == "garrison_herbs" then
  local bID = C_Garrison.GetOwnedBuildingInfo(63)
  return (bID == 137 and 15 or -- herb garden level 3
         (bID == 136 and 10 or -- herb garden level 2
         (bID == 29 and 7 or   -- herb garden level 1
		 0)))
 elseif s == "garrison_mines" then
  local bID = C_Garrison.GetOwnedBuildingInfo(59)
  return (bID == 63 and 18 or -- mine level 3
         (bID == 62 and 13 or -- mine level 2
         (bID == 61 and 8 or  -- mine level 1
         0)))
 end
end

local function isquestcompleted(questID)
 if type(questID) == "number" then
  return IsQuestFlaggedCompleted(questID)
 elseif questID == "seal_of_tempered_fate" or questID == "seal_of_broken_fate" then
  local counter = 0
  for _,v in pairs(seal_quests[questID]) do
   if IsQuestFlaggedCompleted(v) then counter = counter + 1 end
   if counter == 3 then break end
  end
  return true, counter.." / 3"
 elseif questID == "garrison_cache" then
  local quantity = calculate_garrison_cache_quantity(DailyGlobalCheck.selectedpID)
  return true, quantity
 elseif questID == "garrison_herbs" or questID == "garrison_mines" then
  local data = DGC_ProfSaves[pID]
  local maxnodes = getMaxNodes(questID)
  if maxnodes > 0 then
   local result
   if not data or not data[questID] then 
    result = 0
   elseif time() > (data[questID].reset or 0) then
    data[questID] = nil
    result = 0
   else
    result = data[questID].count
   end
   return true, result.." / "..maxnodes
  else
   return false, GM_SURVEY_NOT_APPLICABLE
  end
 elseif questID == "weekly_follower" then
  local data = DGC_ProfSaves[pID]
  if not data then return end
  if not data.weekly_follower or time() > data.weekly_follower.reset then
   data.weekly_follower = nil
   return false
  else
   return true
  end
 elseif questID == "inscription_daily" then
  local result = GetSpellCooldown(176513)
  return result > 0
 elseif questID == "profession1" or questID == "profession2" or
        questID == "secret1"     or questID == "secret2" then
  local length = strlen(questID)
  local k = questID:sub(1, length - 1)  -- "profession" or "secret"
  local i = tonumber(questID:sub(length, length)) -- 1 or 2
  local t = profession_cd_ids[i]

  if not t then return false, NONE end

  local result = GetSpellCooldown(t[k])
  return result > 0, k == "profession" and t.name or nil
 end
end

-- this function is fired just before dgc draws the quests list
-- it sets the right cache quantity for an alt in its dgc savedvariables
local function onDraw(list)
 if list ~= plugin_data then return end
 
 if DailyGlobalCheck.selectedpID == pID then 
  DGC_ProfSaves[pID].garrison_cache_cap = IsQuestFlaggedCompleted(37485) and 1000 or 500
  return
 end

 local data = DailyGlobalCheck_CharData[DailyGlobalCheck.selectedpID] and DailyGlobalCheck_CharData[DailyGlobalCheck.selectedpID].data
 
 if not data then return end
 
 local t = type(data["garrison_cache"])

 if t == "table" then -- DGC old character save format
  data["garrison_cache"][2] = calculate_garrison_cache_quantity(DailyGlobalCheck.selectedpID)
 else -- DGC new character save format
  data["garrison_cache"] = calculate_garrison_cache_quantity(DailyGlobalCheck.selectedpID).."~"
 end
end

plugin_data = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = {
              { -- page 1
               {EXPANSION_NAME6,"seal_of_broken_fate",43510},
               {GARRISON_LOCATION_TOOLTIP.." ("..EXPANSION_NAME5..")","garrison_cache","weekly_follower"},
			   {"",37319,37270,"inscription_daily"},
			   {"","garrison_herbs","garrison_mines"},
			   {BATTLE_PET_SOURCE_4..1,"profession1","secret1"},
			   {BATTLE_PET_SOURCE_4..2,"profession2","secret2"},
			  },
             },
}

local questsdata = {}

local function GenerateData()

 
 questsdata["garrison_cache"]        = {GARRISON_LOCATION_TOOLTIP,GARRISON_CACHE,nil,nil,nil,nil,1,nil,nil,isquestcompleted}
 
 -- seal localization
 local Sname, _, Sicon  = GetCurrencyInfo(994)
 Sicon = "|T"..Sicon..":12|t"
 questsdata["seal_of_tempered_fate"] = {GARRISON_LOCATION_TOOLTIP,Sname,Sicon,nil,nil,nil,3,nil,nil,isquestcompleted}
 questsdata[36058]                   = {GARRISON_LOCATION_TOOLTIP,DailyGlobalCheck.LocalizeSection(questsdata, 36058, 2, "Seal of Tempered Fate: Armory", "quest", 36058),Sicon,nil,nil, nil,3}
 
 -- seal localization
 Sname, _, Sicon  = GetCurrencyInfo(1273)
 Sicon = "|T"..Sicon..":12|t"
 questsdata["seal_of_broken_fate"]   = {"",Sname,Sicon,nil,nil,nil,3,nil,nil,isquestcompleted}
 questsdata[43510]                   = {"",DailyGlobalCheck.LocalizeSection(questsdata, 43510, 2, "Seal of Broken Fate: Class Hall", "quest", 43510),Sicon,nil,nil, nil,3}
 questsdata["weekly_follower"]       = {GARRISON_LOCATION_TOOLTIP,"Weekly Follower",nil,nil,nil,nil,3,nil,nil,isquestcompleted}
 questsdata["profession1"]           = {nil,PROFESSIONS_USED_IN_COOKING, [10] = isquestcompleted}
 questsdata["secret1"]               = {nil,"Secret", [10] = isquestcompleted}
 questsdata["profession2"]           = {nil,PROFESSIONS_USED_IN_COOKING, [10] = isquestcompleted}
 questsdata["secret2"]               = {nil,"Secret", [10] = isquestcompleted}
 questsdata["garrison_herbs"]        = {GARRISON_LOCATION_TOOLTIP, "Garrison Herbs", [10] = isquestcompleted}
 questsdata["garrison_mines"]        = {GARRISON_LOCATION_TOOLTIP, "Garrison Mines", [10] = isquestcompleted}
 questsdata[37270]                   = {GARRISON_LOCATION_TOOLTIP, "Alchemy Daily"}
 questsdata[37319]                   = {GARRISON_LOCATION_TOOLTIP, "Gem Boutique Daily"}
 questsdata["inscription_daily"]     = {GARRISON_LOCATION_TOOLTIP, "Inscription Daily", [10] = isquestcompleted}
end

local function setWeeklyFollowerTrue()
 local calcResets = DailyGlobalCheck.CharFunctions.CalculateResets
 if not calcResets then return end
 
 local wr = calcResets()
 DGC_ProfSaves[pID].weekly_follower = {reset = wr}
end

local function checkLoot(s)
 local function CounterPlusPlus(key)
  
  local data = DGC_ProfSaves[pID]
  local now = time()

  if not data[key] or data[key].reset < now then
   data[key] = {}
  end
  
  if not data[key].count then
   -- I need to reset them manually since they're stored in the professions savedvariables
   data[key].reset = now + GetQuestResetTime()
   data[key].count = 1
  else
   data[key].count = data[key].count + 1
  end
 end
 
 local LOOT_SELF_REGEX = gsub(LOOT_ITEM_SELF, "%%s", "(.+)")
 local _, _, itemlink = s:find(LOOT_SELF_REGEX)
 if not itemlink then return end
 local _, _, itemID = itemlink:find("item:(%d+):")
 
 if itemID == "116053" then
  CounterPlusPlus("garrison_herbs")
 elseif itemID == "115508" then
  CounterPlusPlus("garrison_mines")
 end
end

local function Initialize()
 local pName = GetUnitName("player")
 local pRealm = GetRealmName()
 pID = pName.."-"..pRealm
 if not DGC_ProfSaves[pID] then DGC_ProfSaves[pID] = {} end

 pTable = DailyGlobalCheck_CharData
 
 DGCEventFrame:Hook("ON_DRAW", onDraw)

 local function addProfession(p, index)
  if p == GetSpellInfo(158758) then -- tailoring
   profession_cd_ids[index] = { profession = 168835, secret = 176058, name = select(1, GetSpellInfo(168835)) }
  elseif p == GetSpellInfo(158716) then -- enchanting
   profession_cd_ids[index] = { profession = 169092, secret = 177043, name = select(1, GetSpellInfo(169092)) }
  elseif p == GetSpellInfo(156606) then -- alchemy
   profession_cd_ids[index] = { profession = 156587, secret = 175880, name = select(1, GetSpellInfo(156587)) }
  elseif p == GetSpellInfo(158748) then -- inscription
   profession_cd_ids[index] = { profession = 169081, secret = 177045, name = select(1, GetSpellInfo(169081)) }
  elseif p == GetSpellInfo(110403) then -- engineering
   profession_cd_ids[index] = { profession = 169080, secret = 177054, name = select(1, GetSpellInfo(169080)) }
  elseif p == GetSpellInfo(110423) then -- leatherworking
   profession_cd_ids[index] = { profession = 171391, secret = 176089, name = select(1, GetSpellInfo(171391)) }
  elseif p == GetSpellInfo(158737) then -- blacksmithing
   profession_cd_ids[index] = { profession = 171690, secret = 176090, name = select(1, GetSpellInfo(171690)) }
  elseif p == GetSpellInfo(158750) then -- jewelcrafting
   profession_cd_ids[index] = { profession = 170700, secret = 176087, name = select(1, GetSpellInfo(170700)) }
  else
  --profession_cd_ids[index] = -1
  --prof_names[index] = NONE
  end
 end

 local p1, p2 = GetProfessions()
 local pname
 if p1 then
  pname = GetProfessionInfo(p1)
  addProfession(pname, 1)
 end
 if p2 then
  pname = GetProfessionInfo(p2)
  addProfession(pname, 2)
 end

 hooksecurefunc(C_Garrison, "RecruitFollower", setWeeklyFollowerTrue)
 
 local eventframe = CreateFrame("Frame")
 eventframe:RegisterEvent("SHOW_LOOT_TOAST")
 eventframe:RegisterEvent("CHAT_MSG_LOOT")
 local function eventhandler(self, event, ...)
  if event == "CHAT_MSG_LOOT" then
   if C_Garrison.IsOnGarrisonMap() then checkLoot(...) end
  elseif event == "SHOW_LOOT_TOAST" then
   local z = GetZoneText()
   -- not in garrison
   if z ~= DailyGlobalCheck.Z[971] and z ~= DailyGlobalCheck.Z[976] then
    return
   end
   
   local typeIdentifier, itemLink, _, _, _, _, lootSource = ...
   
   if not typeIdentifier or low(typeIdentifier) ~= low(CURRENCY) then return end
   
   local _, _, _, _, ID = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*):?(%d*):?(%-?%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
   
   if lootSource == 10 and ID == "824" then
    DGC_ProfSaves[pID].garrison_cache_reset = time()
   end
  end
 end
 eventframe:SetScript("OnEvent", eventhandler)
end

plugin_data.Initialize = Initialize
plugin_data.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(plugin_data, questsdata)
