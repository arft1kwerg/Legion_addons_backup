﻿-- Daily Global Check - Timeless Isle plugin
-- Jadya EU-Well of Eternity
local addonName, addonTable = ...

local tdcicon = "Interface\\ICONS\\Spell_Nature_TimeStop"
local plugintitle = "Timeless Isle"
local pluginicon = "Interface\\Icons\\Ability_Monk_LeeroftheOx"
local nalak_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Nalak:12|t"
local ordos_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Ordos:12|t"
local celestials_icon = "|TInterface\\Icons\\INV_CelestialSerpentMount:12|t"
local shafear_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Sha of Fear:12|t"
local galleon_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Chief Salyis:12|t"
local oondasta_icon = "|TInterface\\EncounterJournal\\UI-EJ-BOSS-Oondasta:12|t"
local rares_icon = "Interface\\Icons\\INV_Misc_Bone_Skull_02"
 
local pirates_special, ropechests_special = "timeless_pirates_group","timeless_ropechests_group"

local function isquestcompleted(questID)
 if questID == pirates_special then
  return (IsQuestFlaggedCompleted(32956) and IsQuestFlaggedCompleted(32957) and IsQuestFlaggedCompleted(32970))
 elseif questID == ropechests_special then
  return (IsQuestFlaggedCompleted(32969) and IsQuestFlaggedCompleted(32968) and IsQuestFlaggedCompleted(32971))
 end
end
	 
local questsdata = {}

local list = {
 ["Title"] = plugintitle,
 ["Icon"]  = tdcicon,
 ["Version"] = 1004,
 ["Order"] = {
             -- page 1
             {{BOSSES,33118,33117},
              {PETS,33137,33222},
			  {select(2, GetAchievementInfo(8727)),pirates_special,32956,32957,32970},
			  {select(2, GetAchievementInfo(8726)),ropechests_special,32969,32968,32971},
			  {BATTLE_PET_SOURCE_2,33338,33334,33374,33211}},
			 -- page 2
			 {{DAILY.." "..ELITE,33312,33301,33299,32966,33310,32967,33314,33295,33313,33309,33300,33315,
						         33297,33294,33311,33303,33296,33306,33292,33298,33302,33307,33293,33305,
								 33304,33308,33322,33316,32959}}},
 }

local function GenerateData()
 local l = DailyGlobalCheck.LocalizeSection
 local zone = DailyGlobalCheck.Z[951]

 questsdata[33118]              = {zone, EJ_GetEncounterInfo(861)                                           ,ordos_icon      ,nil, {951, 54, 20}, nil, 3}
 questsdata[33117]              = {zone, select(2, GetAchievementInfo(8535))                                ,celestials_icon ,nil, {951, 38, 55}, nil, 3}
 questsdata[33137]              = {zone, l(questsdata, 33137, 2, "The Celestial Tournament", "quest", 33137),nil             ,nil, {951, 35, 59}, nil, 3}
 questsdata[33222]              = {zone, l(questsdata, 33222, 2, "Little Tommy Newcomer", "quest", 33222)   ,nil             ,nil, {951, 35, 60}}
 questsdata[pirates_special]    = {nil , select(2, GetAchievementInfo(8727))                                ,nil             ,nil, nil          , nil, 3, nil, function() return isquestcompleted(pirates_special) end,isquestcompleted}
 questsdata[32956]              = {zone, GetAchievementCriteriaInfo(8727,2)                                 ,nil             ,nil, {951, 17, 58}, nil, 3, nil, function() return not isquestcompleted(pirates_special) end}
 questsdata[32957]              = {zone, GetAchievementCriteriaInfo(8727,1)                                 ,nil             ,nil, {951, 40, 92}, nil, 3, nil, function() return not isquestcompleted(pirates_special) end}
 questsdata[32970]              = {zone, GetAchievementCriteriaInfo(8727,3)                                 ,nil             ,nil, {951, 71, 80}, nil, 3, nil, function() return not isquestcompleted(pirates_special) end}
 questsdata[ropechests_special] = {nil , select(2, GetAchievementInfo(8726))                                ,nil             ,nil, nil          , nil, 3, nil, function() return isquestcompleted(ropechests_special) end,isquestcompleted}
 questsdata[32969]              = {zone, GetAchievementCriteriaInfo(8726,1)                                 ,nil             ,nil, {951, 49, 69}, nil, 3, nil, function() return not isquestcompleted(ropechests_special) end}
 questsdata[32968]              = {zone, GetAchievementCriteriaInfo(8726,2)                                 ,nil             ,nil, {951, 54, 47}, nil, 3, nil, function() return (not isquestcompleted(ropechests_special) and IsQuestFlaggedCompleted(32969)) end}
 questsdata[32971]              = {zone, GetAchievementCriteriaInfo(8726,3)                                 ,nil             ,nil, {951, 58, 60}, nil, 3, nil, function() return (not isquestcompleted(ropechests_special) and IsQuestFlaggedCompleted(32968)) end}
 questsdata[33338]              = {zone, l(questsdata, 33338, 2, "50 Epoch Stone", "item", 105715, 1, "50 "),nil             ,nil, {951, 34, 53}, nil, 3}
 questsdata[33334]              = {zone, l(questsdata, 33334, 2, "Strong Enough To Survive", "quest", 33334),nil             ,nil, {951, 34, 53}, nil, 3}
 questsdata[33374]              = {zone, l(questsdata, 33374, 2, "Path of the Mistwalker", "quest", 33374)  ,nil             ,nil, {951, 43, 55}}
 questsdata[33211]              = {zone, l(questsdata, 33211, 2, "A Timeless Question", "quest", 33211)     ,nil             ,nil, {951, 65, 50}}

 -- Rares
 questsdata[33312] = {zone, GetAchievementCriteriaInfo(8714,31) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33301] = {zone, GetAchievementCriteriaInfo(8714,14) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33299] = {zone, GetAchievementCriteriaInfo(8714,23) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[32966] = {zone, GetAchievementCriteriaInfo(8714,8)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33310] = {zone, GetAchievementCriteriaInfo(8714,24) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[32967] = {zone, GetAchievementCriteriaInfo(8714,10) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33314] = {zone, GetAchievementCriteriaInfo(8714,30) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33295] = {zone, GetAchievementCriteriaInfo(8714,1)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33313] = {zone, GetAchievementCriteriaInfo(8714,29) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33309] = {zone, GetAchievementCriteriaInfo(8714,26) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33300] = {zone, GetAchievementCriteriaInfo(8714,15) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33315] = {zone, GetAchievementCriteriaInfo(8714,28) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33297] = {zone, GetAchievementCriteriaInfo(8714,3)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33294] = {zone, GetAchievementCriteriaInfo(8714,4)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33311] = {zone, GetAchievementCriteriaInfo(8714,27) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33303] = {zone, GetAchievementCriteriaInfo(8714,18) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33296] = {zone, GetAchievementCriteriaInfo(8714,2)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33306] = {zone, GetAchievementCriteriaInfo(8714,22) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33292] = {zone, GetAchievementCriteriaInfo(8714,7)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33298] = {zone, GetAchievementCriteriaInfo(8714,13) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33302] = {zone, GetAchievementCriteriaInfo(8714,17) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33307] = {zone, GetAchievementCriteriaInfo(8714,20) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33293] = {zone, GetAchievementCriteriaInfo(8714,12) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33305] = {zone, GetAchievementCriteriaInfo(8714,19) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33304] = {zone, GetAchievementCriteriaInfo(8714,16) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33308] = {zone, GetAchievementCriteriaInfo(8714,25) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33322] = {zone, GetAchievementCriteriaInfo(8714,21) ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[33316] = {zone, GetAchievementCriteriaInfo(8714,5)  ,nil ,nil,nil,nil,nil,rares_icon}
 questsdata[32959] = {zone, GetAchievementCriteriaInfo(8714,6)  ,nil ,nil,nil,nil,nil,rares_icon}
end

list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)
