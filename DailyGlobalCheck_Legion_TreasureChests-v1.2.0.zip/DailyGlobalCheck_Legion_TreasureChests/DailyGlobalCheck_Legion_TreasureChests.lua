-- Daily Global Check - Legion Treasure Chests
-- Jadya EU-Well of Eternity

local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z

local questsdata = {}

local list = {
 ["Title"] = "Legion Treasure Chests",
 ["Icon"]  = "Interface\\Icons\\INV_TreasureChest_FelfireCitadel",
 ["Version"] = 1004,
 ["Order"] = {
			    -- Azsuna 1
				{
				 {Z[1015],37958,42289,38251,37830,38367,42273,42278,42958,42283,42297,40752,42272,40751,38419,42288,37831,37713,42292,44102,42295,44405,37828,38239,46967},
				},
                -- Azsuna 2
                {
				 {Z[1015],42282,37649,38316,42284,42285,37596,42290,42287,42281,42293,42294,37829,38370,42291,40711,44104,37980,44103,42339,42338,44105,37832,46970,46968},
				},
                -- Val'Sharah 1
			    {
				 {Z[1018],38861,39072,39069,39070,39080,44139,39089,38277,38886,39077,44135,38371,39108,39073,39088,39081,39079,44138,38387,44136,39074,38391,46954,46963},
				},
                -- Val'Sharah 2
                {
				 {Z[1018],38893,39102,38943,39071,38782,38355,38386,38783,39084,38369,39097,38359,39093,38363,38366,38388,39087,38390,39086,39085,38389,39083,46962,46956},
				},                
				-- Highmountain 1
   			    {
				{Z[1024],39606,40483,40505,39494,40487,40478,40499,39503,40473,40489,42453,40496,40481,40482,40506,39466,40507,40480,40494,40479,44731,39471,44280,46992},
                },
                -- Highmountain 2
                {
                {Z[1024],40477,40493,40476,40484,44279,40498,40497,40500,40488,40474,39824,40508,40510,39812,40509,46988,46994,46987,46993},
				-- Thunder Totem
				{Z[1080],40471,40475,40472,39531,40491}
				},
                -- Stormheim 1
			    {
				{Z[1017],38677,38676,38529,43196,38488,38483,38476,38474,38481,40093,40094,40095,40083,38637,40085,40089,40090,38477,38486,40088,38480,40099,43191,43237,43190,42632,42629,42628,43195,38498,38495,38487,43207,38681,38489},
				},
				-- Stormheim 2
				{
				{Z[1017],38475,38478,43239,38738,40091,43187,40082,43304,38485,38680,43208,38490,43189,43255,43240,38763,43306,43305,43194,43205,40086,43307,38744,43302,43238,43246,40108,43188,46982,46977,46975},
				{Z[1022],38516,38383,38510,38503}                                                                                                                         
				},
                -- Suramar 1
			    {
				{Z[1033],43853,43840,43854,43855,43838,43846,43847,43848,43849,43850,40767,43862,43863,43858,43856,43844,43842,43831,40902,43835,44325,43868,43834,44323,44324,43869,43864,43866,43839,43859,43861},
				},
                -- Suramar 2
				{
                {Z[1033],43865,43867,43875,43874,43873,43870,43871,43872,43876,43830,43857,43860,43845,44179, 42842,43988,43989,43986,43987},
                -- Suramar Scenario
				{Z[1033].." - "..TRACKER_HEADER_SCENARIO,43149,43071,43140,43111,43146,43144,43143,43134,43148,43128,43142,43135,43141,43145,43120},
				},
                -- Suramar 3 (portals)
                {
                {Z[1033].." - Portals",41575,42487,44084,43811,42230,43808,43809,43813,42889,44740},
                --{Z[1017].." - Vethir Landing Locations","veth_galebroken","veth_thorim_down","veth_thorim_top"},
                },
                -- Argus
                {
                {Z[1135],48884,48886,49156,48885,49154},
                {Z[1171],49018,49020,49017,49019,49021,49159},
                {Z[1170],48743,48745,48748,48750,49151,48744,48747,48749,48751,49129,49153},
                },       
		   },
 }
 
local function GenerateData()
 
 local arrowup = "Interface\\Minimap\\Vehicle-SilvershardMines-Arrow"
 local chests_icon = "Interface\\WorldMap\\TreasureChest_64"
 local invasion_icon = "Interface\\Addons\\DailyGlobalCheck_Legion_TreasureChests\\InvasionChest"
 local chests_icon2 = "Interface\\Icons\\INV_Misc_ancient_mana"
 local mana_cluster_icon = "spells\\crystal_02"
 --local portal_icon = "spells\\portal_suramar_moonguard"
 local portal_icon = "world\\generic\\activedoodads\\spellportals\\netherlighttemple_portal"
 local q = questsdata

 local azs  = Z[1015]
 local val  = Z[1018]
 local high = Z[1024]
 local sur  = Z[1033]
 local sto  = Z[1017]
 local dal  = Z[1014]
 local hel  = Z[1022]
  -- argus
 local kro = Z[1135]
 local ant = Z[1171]
 local mac = Z[1170]

 local cave_entrance = DailyGlobalCheck.template_cave_entrance
 
 local l = DailyGlobalCheck.LocalizeSection

			 -------- Argus ---------
			 -------- Krokuun ---------
 q[48884] = {kro,"Krokuul Emergency Cache"     ,nil,nil,{1135, 51.3 , 76.2 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:152098::::::::::::1:|h[warframe]|h~Lightforged Warframe required"}
 q[48886] = {kro,"Lost Krokul Chest"           ,nil,nil,{1135, 48.5 , 58.9 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[49156] = {kro,"Precious Augari Keepsakes"   ,nil,nil,{1135, 55.9 , 74.2 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}
 q[48885] = {kro,"Legion Tower Chest"          ,nil,nil,{1135, 62.8 , 37.6 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[49154] = {kro,"Long-Lost Augari Treasure"   ,nil,nil,{1135, 62.2 , 71.2 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}
			 -------- Antoraan Wastes ---------
 q[49018] = {ant,"Ancient Legion War Cache"    ,nil,nil,{1171, 65.9 , 39.8 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[49020] = {ant,"Legion Treasure Hoard"       ,nil,nil,{1171, 49   , 59.3 },nil,1,chests_icon}
 q[49017] = {ant,"Forgotten Legion Supplies"   ,nil,nil,{1171, 58.9 , 61.4 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:152098::::::::::::1:|h[warframe]|h~Lightforged Warframe required"}
 q[49019] = {ant,"Fel-Bound Chest"             ,nil,nil,{1171, 52.1 , 27.2 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[49021] = {ant,"Timeworn Fel Chest"          ,nil,nil,{1171, 75.7 , 52.6 },nil,1,chests_icon}
 q[49159] = {ant,"Missing Augari Chest"        ,nil,nil,{1171, 57.4 , 63.6 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}
             
			 -------- Mac'aree ---------
 q[48743] = {mac,"Eredar Treasure Cache"       ,nil,nil,{1170, 42.9 ,  5.5 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:152098::::::::::::1:|h[warframe]|h~Lightforged Warframe required"}
 q[48745] = {mac,"Student's Surprising Surplus",nil,nil,{1170, 62.2 , 71.2 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[48748] = {mac,"Augari Secret Stash"         ,nil,nil,{1170, 70.28, 59.74},nil,1,chests_icon}
 q[48750] = {mac,"Shattered House Chest"       ,nil,nil,{1170, 27.4 , 40.1 },nil,1,chests_icon}
 q[49151] = {mac,"Secret Augari Chest"         ,nil,nil,{1170, 62.2 , 22.4 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}
 q[48744] = {mac,"Chest of Ill-Gotten Gains"   ,nil,nil,{1170, 50.57, 38.36},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151830::::::::::::1:|h[judg]|h~Light's Judgment required"}
 q[48747] = {mac,"Void-Tinged Chest"           ,nil,nil,{1170, 40.2 , 51.4 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:152098::::::::::::1:|h[warframe]|h~Lightforged Warframe required"}
 q[48749] = {mac,"Desperate Eredar's Cache"    ,nil,nil,{1170, 57.05, 76.81},nil,1,chests_icon}
 q[48751] = {mac,"Doomseeker's Treasure"       ,nil,nil,{1170, 43.4 , 54.4 },nil,1,chests_icon}
 q[49129] = {mac,"Augari-Runed Chest"          ,nil,nil,{1170, 70.6 , 27.3 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}
 q[49153] = {mac,"Augari Goods"                ,nil,nil,{1170, 40.8 , 69.8 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:151912::::::::::::1:|h[shroud]|h~Shroud of Arcane Echoes required"}

             
			 -------- Azsuna ---------
 q[37958] = {azs,"Treasure Chest"           ,nil,nil,{1015, 57.9 , 12.2 },nil,1,chests_icon,nil,nil,nil,nil,"Ground floor"}
 q[42289] = {azs,"Treasure Chest"           ,nil,nil,{1015, 51.5 , 24.3, {desc="Cave entrance west of here"}, 1015, 47.8, 23.7, cave_entrance},nil,1,chests_icon}
 q[38251] = {azs,"Treasure Chest"           ,nil,nil,{1015, 56.4 , 34.8 },nil,1,chests_icon}
 q[37830] = {azs,"Glimmering Treasure Chest",nil,nil,{1015, 58.36, 43.78},nil,1,chests_icon}
 q[38367] = {azs,"Treasure Chest"           ,nil,nil,{1015, 42.6 , 8.1  },nil,1,chests_icon}
 q[42273] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 62.4 , 58.4 },nil,1,chests_icon}
 q[42278] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 63   , 54.2 ,{desc="Cave entrance east of here"},1015,64.28,52.83,cave_entrance},nil,1,chests_icon}
 q[42958] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 65.5 , 29.56},nil,1,chests_icon}
 q[42283] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 53.5 , 45.45},nil,1,chests_icon}
 q[42297] = {azs,"Glimmering Treasure Chest",nil,nil,{1015, 43.37, 22.39},nil,1,chests_icon}
 q[40752] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 58.64, 53.38},nil,1,chests_icon}
 q[42272] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 59.88, 63.19},nil,1,chests_icon}
 q[40751] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 66.05, 43.44},nil,1,chests_icon}
 q[38419] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 57.15, 31.06},nil,1,chests_icon}
 q[42288] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 55.36, 27.74},nil,1,chests_icon}
 q[37831] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 49.65, 34.47},nil,1,chests_icon}
 q[37713] = {azs,"Treasure Chest"           ,nil,nil,{1015, 44.46, 39.47},nil,1,chests_icon}
 q[42292] = {azs,"Treasure Chest"           ,nil,nil,{1015, 41.6 , 31.33},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[44102] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 34.34, 36.06},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[42295] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 47.85,  7.72},nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[44405] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 54.58, 52.54},nil,1,chests_icon,nil,nil,nil,nil,"In the cave, the pirates will attack you after looting"}
 q[37828] = {azs,"Treasure Chest"           ,nil,nil,{1015, 49.37, 45.35},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:122681:0:0:0:0:0:0:0:0:0:0:0:1:0|h[toy]|h~Requires quest 'The Prince is Going Down'"}
 q[42282] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 53.68, 43.95},nil,1,chests_icon}
 q[37649] = {azs,"Glimmering Treasure Chest",nil,nil,{1015, 50.39, 54.36, {level=18}, 1015, 50.71, 58.6, cave_entrance, 1015, 49, 58.9, cave_entrance},nil,1,chests_icon}
 q[38316] = {azs,"Treasure Chest"           ,nil,nil,{1015, 40.56, 57.66},nil,1,chests_icon}
 q[42284] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 53.64, 39.81,{level=17},1015,53.86, 40.65, cave_entrance},nil,1,chests_icon}
 q[42285] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 54.41, 34.87,{level=17},1015,53.86, 40.65, cave_entrance},nil,1,chests_icon}
 q[37596] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 53.03, 37.26},nil,1,chests_icon}
 q[42290] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 50.05, 48.71},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[42287] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 54.31, 36.33},nil,1,chests_icon,nil,nil,nil,nil,"Underwater"}
 q[42281] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 52, 42.1},nil,1,chests_icon}
 q[42293] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 63.63, 39.17},nil,1,chests_icon}
 q[42294] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 62.8 , 44.8},nil,1,chests_icon}
 q[37829] = {azs,"Treasure Chest"           ,nil,nil,{1015, 53.16, 64.44},nil,1,chests_icon}
 q[38370] = {azs,"Treasure Chest"           ,nil,nil,{1015, 49.41, 57.97},nil,1,chests_icon}
 q[42291] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 48, 56.23, {level=18},1015, 50.71, 58.6, cave_entrance, 1015, 49, 58.9, cave_entrance},nil,1,chests_icon}
 q[40711] = {azs,"Treasure Chest"           ,nil,nil,{1015, 55.53, 18.61},nil,1,chests_icon,nil,nil,nil,nil,"Use Ley Portal inside"}
 q[44104] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 53.96, 17.89},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[37980] = {azs,"Treasure Chest"           ,nil,nil,{1015, 58.38, 12.27,{desc="Ley portal at 58.6, 14.1"},1015,58.68,14.13,cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"Use Ley Portal"}
 q[44103] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 68.86, 29.72,nil,1015, 69.77, 29.52,cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"Underwater"}
 q[42339] = {azs,"Treasure Chest"           ,nil,nil,{1015, 52.83, 20.59, nil, 1015, 53.86, 22.39, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"Don't touch the bears"}
 q[42338] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 57.19, 25.23, nil, 1015, 55.69, 25.47, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[44105] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 26.66, 47.09},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[37832] = {azs,"Treasure Chest"           ,nil,nil,{1015, 63.23, 15.21},nil,1,chests_icon}
 q[46970] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 49.1 , 45.11},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46967] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 45.59, 8.35 },nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46968] = {azs,"Small Treasure Chest"     ,nil,nil,{1015, 38.15, 30.67},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}

 q[38239] = {azs,"Seemingly Unguarded Treasure",nil,nil,{1015, 65.1, 69.8},nil,1,chests_icon}
 
		 -------- Val'Sharah ---------
 q[38861] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 55.38, 84.1 },nil,1,chests_icon,nil,nil,nil,nil,"In the cave, under the tree"}
 q[39072] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 56.22, 57.30},nil,1,chests_icon}
 q[39069] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 62.7 , 70.4 },nil,1,chests_icon,nil,nil,nil,nil,"Second floor balcony"}
 q[39070] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 63   , 77, nil, 1018, 62.16, 76.02, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[39080] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 38.45, 65.3 },nil,1,chests_icon,nil,nil,nil,nil,"|cffffff00|Hquest:38644:-1|h[The Farmsteads]|h|r quest~Requires completion of this quest~Downstairs in the cellar"}
 q[44139] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 63.9 , 45.56},nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[39089] = {val,"Glimmering Treasure Chest"     ,nil,nil,{1018, 61.03, 79.16},nil,1,chests_icon,nil,nil,nil,nil,"Underneath"}
 q[38277] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 46.45, 86.31},nil,1,chests_icon} 
 q[38886] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 49.35, 85.53},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[39077] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 42.66, 58   },nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[44135] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 73   , 53.63},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[38371] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 73.78, 32.27},nil,1,chests_icon}
 q[39108] = {val,"Treasure Chest"                ,nil,nil,{1018, 66.6 , 40.9 },nil,1,chests_icon,nil,nil,nil,nil,"Up on the platform"}
 q[39073] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 68.32, 40.6 },nil,1,chests_icon,nil,nil,nil,nil,"In the housees"}
 q[39088] = {val,"Treasure Chest"                ,nil,nil,{1018, 61.07, 34.21},nil,1,chests_icon,nil,nil,nil,nil,"Underwater, halfway down"}
 q[39081] = {val,"Treasure Chest"                ,nil,nil,{1018, 33.8 , 58.25},nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[39079] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 38.62, 67.18},nil,1,chests_icon,nil,nil,nil,nil,"Up, beside the wheel"}
 q[44138] = {val,"Treasure Chest"                ,nil,nil,{1018, 43.7 , 90   },nil,1,chests_icon,nil,nil,nil,nil,"In the cave"} -- Ok
 q[38387] = {val,"Treasure Chest"                ,nil,nil,{1018, 44.34, 83.3 },nil,1,chests_icon,nil,nil,nil,nil,"In the cave under the house"}
 q[44136] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 62.7 , 85.26},nil,1,chests_icon,nil,nil,nil,nil,"Under the big tree"}
 q[39074] = {val,"Treasure Chest"                ,nil,nil,{1018, 65.38, 86.25},nil,1,chests_icon,nil,nil,nil,nil,"Under the big tree"}
 q[38893] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 60.48, 82.14, {desc="In the cave, entrance on the shore south of here"}, 1018, 62.13, 86.37, cave_entrance},nil,1,chests_icon}
 q[39102] = {val,"Treasure Chest"                ,nil,nil,{1018, 63.27, 74   },nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[38943] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 60.41, 71.2 },nil,1,chests_icon,nil,nil,nil,nil,"In the house, second floor"}
 q[39071] = {val,"Treasure Chest"                ,nil,nil,{1018, 62   , 68.35},nil,1,chests_icon,nil,nil,nil,nil,"Behind the Waterfall"}
 q[38782] = {val,"Treasure Chest"                ,nil,nil,{1018, 67.2 , 59.28,{desc="Cave entrance north-west of here"}, 1018, 65.83, 56.37,cave_entrance},nil,1,chests_icon}
 q[38355] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 64.7 , 51.26},nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[38386] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 67.39, 53.41},nil,1,chests_icon,nil,nil,nil,nil,"Second floor balcony"}
 q[38783] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 70.21, 57.04},nil,1,chests_icon}
 q[39084] = {val,"Treasure Chest"                ,nil,nil,{1018, 43.21, 54.87},nil,1,chests_icon,nil,nil,nil,nil,"Upstairs"}
 q[38369] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 39.94, 54.6 },nil,1,chests_icon}
 q[39097] = {val,"Treasure Chest"                ,nil,nil,{1018, 54.05, 61.1 },nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[38359] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 54.4 , 74.19},nil,1,chests_icon,nil,nil,nil,nil,"Behind the screen"}
 q[39093] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 54.18, 70.59},nil,1,chests_icon,nil,nil,nil,nil,"On the river edge"}
 q[38363] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 43.38, 75.89},nil,1,chests_icon}
 q[38366] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 48.68, 73.78},nil,1,chests_icon}
 q[38388] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 50.9 , 76.83},nil,1,chests_icon,nil,nil,nil,nil,"Go under the tree at this point, in the cave"}
 q[39087] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 61.63, 73.7 },nil,1,chests_icon}
 q[38390] = {val,"Glimmering Treasure Chest"     ,nil,nil,{1018, 54, 34.91, nil, 1018, 53.31, 38.04, cave_entrance},nil,1,chests_icon}
 q[39086] = {val,"Glimmering Treasure Chest"     ,nil,nil,{1018, 41, 42.68,{level=13},1018, 42.16, 45.75, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the prisons"}
 q[39085] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 40.51, 44.69, {level=13},1018, 42.16, 45.75, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the prisons"}
 q[38389] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 63.37, 88.41},nil,1,chests_icon}
 q[38391] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 65.85, 79.19},nil,1,chests_icon}
 q[39083] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 45.09, 61.13},nil,1,chests_icon,nil,nil,nil,nil,"On the tree"}

 q[46954] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 51.32, 78.45},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46962] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 63   , 63.99},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46963] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 35.64, 65.89},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46956] = {val,"Small Treasure Chest"          ,nil,nil,{1018, 42.45, 80.18},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}

			 -------- Highmountain ---------
 q[39606] = {high,"Glimmering Treasure Chest",nil,nil,{1024, 49.64, 71.28,{level=29},1024,48,85.35,cave_entrance,1024,44.62,72.35,cave_entrance,1024,48.3,77.16,{level=30,icon=arrowup,desc="This way"},1024,48.33,70.27,{level=29,icon=arrowup,desc="Use Titan Waygate"}},nil,1,chests_icon,nil,nil,nil,nil,"Use brazier then defeat waves to spawn chest nearby"}
 q[40483] = {high,"Glimmering Treasure Chest",nil,nil,{1024, 54.17, 41.59,nil,1024,55.13,44.3,cave_entrance},nil,1,chests_icon}
 q[40505] = {high,"Treasure Chest"           ,nil,nil,{1024, 52.02, 32.41},nil,1,chests_icon}
 q[39494] = {high,"Floating Treasure"        ,nil,nil,{1024, 39.7 , 48.3 },nil,1,chests_icon,nil,nil,nil,nil,"Drifting down the river"}
 q[40487] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 55.13, 49.65},nil,1,chests_icon}
 q[40478] = {high,"Treasure Chest"           ,nil,nil,{1024, 43.7 , 24.5,{level=31},1024,42.55, 25.43, cave_entrance},nil,1,chests_icon}
 q[40499] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 53.1 , 39.5 },nil,1,chests_icon}
 q[39503] = {high,"Treasure Chest"           ,nil,nil,{1024, 47.63, 44.06},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:131926:0:0:0:0:0:0:0:0:0:0:0:1:0|h[kite]|h"}
 q[40473] = {high,"Treasure Chest"           ,nil,nil,{1024, 39.28, 76.18},nil,1,chests_icon,nil,nil,nil,nil,"|cffffff00|Hquest:42104:-1|h[The Underking Comes]|h|r quest~Requires completion of this quest"}
 q[40489] = {high,"Treasure Chest"           ,nil,nil,{1024, 46.22, 73.41,{level=5},1024, 41.29, 72.43, cave_entrance},nil,1,chests_icon}
 q[42453] = {high,"Treasure Chest"           ,nil,nil,{1024, 52.54, 66.37},nil,1,chests_icon,nil,nil,nil,nil,"|cffffff00|Hquest:42512:-1|h[Highmountain Stands]|h|r quest~Requires completion of this quest"}
 q[40496] = {high,"Treasure Chest"           ,nil,nil,{1024, 50.98, 36.45},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[40481] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 45.54, 34.59},nil,1,chests_icon}
 q[40482] = {high,"Glimmering Treasure Chest",nil,nil,{1024, 46.66, 28.11},nil,1,chests_icon,nil,nil,nil,nil,"On the building's nose"}
 q[40506] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 50.8 , 35.05},nil,1,chests_icon}
 q[39466] = {high,"Treasure Chest"           ,nil,nil,{1024, 49.6 , 37.8 },nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:131927:0:0:0:0:0:0:0:0:0:0:0:1:0|h[kite]|h"}
 q[40507] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 46.8 , 40.1 },nil,1,chests_icon} 
 q[40480] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 42.5 , 35   },nil,1,chests_icon,nil,nil,nil,nil,"On the tree"}
 q[40494] = {high,"Treasure Chest"           ,nil,nil,{1024, 41.92, 39.9, {level=16},1024,41.65,47.02,cave_entrance,1024,38.35, 42.49,cave_entrance},nil,1,chests_icon}
 q[40479] = {high,"Treasure Chest"           ,nil,nil,{1024, 42.2 , 27.3 },nil,1,chests_icon} 
 q[40477] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 37.34, 33.79},nil,1,chests_icon} 
 q[40493] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 53.04, 52.21,nil,1024, 50, 53.8, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[40476] = {high,"Glimmering Treasure Chest",nil,nil,{1024, 37.1 , 57.7,{level=20}, 1024, 37.8, 57.9,{level=21,icon=arrowup,desc="This way"}, 1024, 38.38, 61.43, cave_entrance},nil,1,chests_icon}
 q[40484] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 53.46, 43.54,nil,1024,55.13, 44.3,cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[44279] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 45.81, 27.36},nil,1,chests_icon,nil,nil,nil,nil,"In the cave (underwater)"}
 q[40498] = {high,"Treasure Chest"           ,nil,nil,{1024, 50.98, 38.8 },nil,1,chests_icon}
 q[40497] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 50.24, 38.62,nil,1024,51.64,37.61,cave_entrance},nil,1,chests_icon}
 q[40500] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 53.4 , 48.6 },nil,1,chests_icon}
 q[40488] = {high,"Treasure Chest"           ,nil,nil,{1024, 36.6 , 62.1 },nil,1,chests_icon}
 q[40474] = {high,"Treasure Chest"           ,nil,nil,{1024, 39.38, 62.27},nil,1,chests_icon}
 q[39824] = {high,"Treasure Chest"           ,nil,nil,{1024, 53.61, 51.02},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:131810:0:0:0:0:0:0:0:0:0:0:0:1:0|h[kite]|h;Up very high on a tree trunk"}
 q[40508] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 49.29, 73.2,{level=29},1024,48,85.35,cave_entrance,1024,44.62,72.35,cave_entrance,1024,48.3,77.16,{level=30,icon=arrowup,desc="This way"}},nil,1,chests_icon}
 q[40510] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 43.73, 72.74},nil,1,chests_icon}
 q[39812] = {high,"Treasure Chest"           ,nil,nil,{1024, 40, 57.8},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[40509] = {high,"Treasure Chest"           ,nil,nil,{1024, 47, 72.7,{level=29},1024,48,85.35,cave_entrance,1024,44.62,72.35,cave_entrance},nil,1,chests_icon}
 q[44731] = {high,"Treasure Chest"           ,nil,nil,{1024, 38.95, 54.48},nil,1,chests_icon}
 q[39471] = {high,"Glimmering Treasure Chest",nil,nil,{1024, 51.18, 53.05},nil,1,chests_icon}
 q[44280] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 46.36, 21.63},nil,1,chests_icon,nil,nil,nil,nil,"On the summit"}
 
 q[46988] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 44.64, 48.88, nil, 1024, 45.5, 48.64, cave_entrance},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46994] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 31.7 , 62.34},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46987] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 47.73, 24.15},nil,1,invasion_icon,nil,nil,nil,nil,"In the cave@Only available during Legion Assault"}
 q[46992] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 47.58, 55.6 },nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46993] = {high,"Small Treasure Chest"     ,nil,nil,{1024, 38.42, 51.98 },nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}

 -- Thunder Totem
 q[40471] = {Z[1080],"Treasure Chest"        ,nil,nil,{1080, 47.3 , 52.4,{level=6},1024, 47.1, 61.31},nil,1,chests_icon,nil,nil,nil,nil,"Inside Thunder Totem"}
 q[40475] = {Z[1080],"Small Treasure Chest"  ,nil,nil,{1080, 32.33, 41.76},nil,1,chests_icon}
 q[40472] = {Z[1080],"Small Treasure Chest"  ,nil,nil,{1080, 50.6, 75.4},nil,1,chests_icon} 
 q[39531] = {Z[1080],"A Steamy Jewelry Box"  ,nil,nil,{1080, 63.5, 59.3},nil,1,chests_icon}
 q[40491] = {Z[1080],"Small Treasure Chest"  ,nil,nil,{1080, 13.7, 55.4},nil,1,chests_icon}
 --
 
			 -------- Stormheim ---------
 q[38677] = {sto,"Treasure Chest"           ,nil,nil,{1017, 35.72, 54.07},nil,1,chests_icon} 
 q[38676] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 31.1 , 56   },nil,1,chests_icon} 
 q[38529] = {sto,"Treasure Chest"           ,nil,nil,{1017, 27.33, 57.49,{level=9},1017,31.43, 57.15, cave_entrance},nil,1,chests_icon}
 q[43196] = {sto,"Treasure Chest"           ,nil,nil,{1017, 32.9 , 48.1 },nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[38488] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 41.74, 46.04},nil,1,chests_icon} 
 q[38483] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 50.08, 42.37},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[38476] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 48.13, 74.21},nil,1,chests_icon} 
 q[38474] = {sto,"Treasure Chest"           ,nil,nil,{1017, 42.61, 65.79},nil,1,chests_icon} 
 q[38481] = {sto,"Treasure Chest"           ,nil,nil,{1017, 46.76, 80.4 },nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the stone"} 
 q[40093] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 61.4 , 44.4 },nil,1,chests_icon} 
 q[40094] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 60.83, 42.73},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the wooden beam"} 
 q[40095] = {sto,"Treasure Chest"           ,nil,nil,{1017, 55   , 47.16},nil,1,chests_icon} 
 q[40083] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 67.93, 57.74},nil,1,chests_icon} 
 q[38637] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 69.14, 44.78},nil,1,chests_icon} 
 q[40085] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 73.33, 41.5 },nil,1,chests_icon} 
 q[40089] = {sto,"Treasure Chest"           ,nil,nil,{1017, 61.83, 62.89},nil,1,chests_icon} 
 q[40090] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 57.94, 63.21},nil,1,chests_icon} 
 q[38477] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 42.34, 61.12},nil,1,chests_icon} 
 q[38486] = {sto,"Treasure Chest"           ,nil,nil,{1017, 39.48, 65.17},nil,1,chests_icon} 
 q[40088] = {sto,"Treasure Chest"           ,nil,nil,{1017, 59.31, 58.44},nil,1,chests_icon}
 q[38480] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 52.02, 80.57},nil,1,chests_icon}
 q[40099] = {sto,"Treasure Chest"           ,nil,nil,{1017, 81.86, 67.51},nil,1,chests_icon}
 q[43191] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 82.38, 54.53},nil,1,chests_icon}
 q[43237] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 73.97, 58.58},nil,1,chests_icon}
 q[43190] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 53.21, 93.15},nil,1,chests_icon}
 q[42632] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 73.95, 52.22},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the stone"}
 q[42629] = {sto,"Treasure Chest"           ,nil,nil,{1017, 75.15, 49.46},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the mast"}
 q[42628] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 72.12, 54.88},nil,1,chests_icon}
 q[43195] = {sto,"Treasure Chest"           ,nil,nil,{1017, 50.05, 18.16},nil,1,chests_icon}
 q[38498] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 39.56, 19.33},nil,1,chests_icon}
 q[38495] = {sto,"Treasure Chest"           ,nil,nil,{1017, 33.13, 36.06},nil,1,chests_icon,nil,nil,nil,nil,"On top of the Cliffs"}
 q[38487] = {sto,"Treasure Chest"           ,nil,nil,{1017, 34.82, 34.19},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[43207] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 49.08, 60   },nil,1,chests_icon}
 q[38681] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 48.15, 65.19},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[38489] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 44.15, 69.97},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the rooftop"}
 q[38475] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 40.64, 68.52},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top floor of the tower"}
 q[38478] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 35.17, 68.98},nil,1,chests_icon,nil,nil,nil,nil,"Top floor"}
 q[43239] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 43.7 , 80.08},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the stone"}
 q[38738] = {sto,"Treasure Chest"           ,nil,nil,{1017, 48   , 62.4 },nil,1,chests_icon,nil,nil,nil,nil,"Under the waterfall"}
 q[40091] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 62.66, 73.61},nil,1,chests_icon}
 q[43187] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 65.58, 57.37},nil,1,chests_icon}
 q[40082] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 58.03, 47.51},nil,1,chests_icon,nil,nil,nil,nil,"Top floor of the building"}
 q[43304] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 75.66, 60.59},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the stone"}
 q[38485] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 49.76, 77.98},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the cliff edge"}
 q[38680] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 35.92, 47.92},nil,1,chests_icon}
 q[43208] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 37.2 , 38.66},nil,1,chests_icon}
 q[38490] = {sto,"Treasure Chest"           ,nil,nil,{1017, 33.73, 27.21},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[43189] = {sto,"Glimmering Treasure Chest",nil,nil,{1017, 42.17, 34.99, nil, 1017, 42.1, 35.8, cave_entrance},nil,1,chests_icon,nil,nil,nil,nil,"Ascend to the top of the tower"}
 q[43255] = {sto,"Treasure Chest"           ,nil,nil,{1017, 47.45, 34.1},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the cliff"}
 q[43240] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 44.98, 38.22},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the cliff"}
 q[38763] = {sto,"Glimmering Treasure Chest",nil,nil,{1017, 49.72, 49.49},nil,1,chests_icon,nil,nil,nil,nil,"In the cave, two keepers spawn.@Open treasure again after defeating them."}
 q[43306] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 74.4 , 41.82},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the cliff, then jump down to ledge"}
 q[43305] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 71.92, 44.24},nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the cliff"}
 q[43194] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 73.12, 45.67},nil,1,chests_icon}
 q[43205] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 65.36, 43.11},nil,1,chests_icon}
 q[40086] = {sto,"Treasure Chest"           ,nil,nil,{1017, 68.97, 41.83,nil,1017, 69.99, 42.71, cave_entrance},nil,1,chests_icon} -- OR  AP 
 q[43307] = {sto,"Treasure Chest"           ,nil,nil,{1017, 78.42, 71.38},nil,1,chests_icon,nil,nil,nil,nil,"Series of grapples from inland side"} 
 q[38744] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 61.93, 32.24},nil,1,chests_icon}
 q[43302] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 64.3 , 39.6 },nil,1,chests_icon}
 q[43238] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 43.2 , 40.5 },nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the stone"} 
 q[43246] = {sto,"Treasure Chest"           ,nil,nil,{1017, 50.6 , 41.2 },nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the top of the cliff"} 
 q[40108] = {sto,"Glimmering Treasure Chest",nil,nil,{1017, 68.5 , 29.6 },nil,1,chests_icon,nil,nil,nil,nil,"Grapple to the island starting from the smaller northern island"}
 q[43188] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 69.98, 67.17},nil,1,chests_icon}
 
 q[46982] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 37.78, 34.98},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46977] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 38.4 , 44.03},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}
 q[46975] = {sto,"Small Treasure Chest"     ,nil,nil,{1017, 50.4 , 38.72},nil,1,invasion_icon,nil,nil,nil,nil,"Only available during Legion Assault"}

 -- helheim
 q[38516] = {hel,"Treasure Chest"      ,nil,nil,{1022, 19.57, 46.93},nil,1,chests_icon}
 q[38383] = {hel,"Small Treasure Chest",nil,nil,{1022, 60.85, 53.31},nil,1,chests_icon}
 q[38510] = {hel,"Small Treasure Chest",nil,nil,{1022, 79.8, 24.7},nil,1,chests_icon}
 q[38503] = {hel,"Treasure Chest"      ,nil,nil,{1022, 83.31, 24.58},nil,1,chests_icon,nil,nil,nil,nil,"In the wreckage"}
 
			 -------- Suramar ---------
 q[43853] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 48.17, 33.96},nil,1,chests_icon}
 q[43840] = {sur,"Treasure Chest"           ,nil,nil,{1033, 23.35, 48.14, {level=33}, 1033, 20.4, 50.31, cave_entrance},nil,1,chests_icon}
 q[43854] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 52.27, 29.89, nil, 1033, 49.5, 33.93, cave_entrance},nil,1,chests_icon}
 q[43838] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 21.62, 33.86, {level=32}, 1033, 22.82, 35.9, cave_entrance},nil,1,chests_icon}
 q[43846] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 16.6 , 29.74},nil,1,chests_icon}
 q[43847] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 26.82, 16.95},nil,1,chests_icon}
 q[43848] = {sur,"Treasure Chest"           ,nil,nil,{1033, 29.26, 16.21},nil,1,chests_icon}
 q[43849] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 42.04, 19.67},nil,1,chests_icon,nil,nil,nil,nil,"On the platform, climb on the rocks to the right"}
 q[43850] = {sur,"Treasure Chest"           ,nil,nil,{1033, 44.28, 22.86},nil,1,chests_icon}
 q[40767] = {sur,"Dusty Coffer"             ,nil,nil,{1033, 52.63, 31.3, nil, 1033, 49.46, 33.97, cave_entrance},nil,1,chests_icon}
 q[43862] = {sur,"Treasure Chest"           ,nil,nil,{1033, 83.97, 57.63},nil,1,chests_icon}
 q[43863] = {sur,"Treasure Chest"           ,nil,nil,{1033, 83.12, 69.33},nil,1,chests_icon,nil,nil,nil,nil,"In the cave"}
 q[43858] = {sur,"Treasure Chest"           ,nil,nil,{1033, 67.31, 55.09},nil,1,chests_icon,nil,nil,nil,nil,"In the building"}
 q[43856] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 42.16, 29.97},nil,1,chests_icon,nil,nil,nil,nil,"In the cave behind the waterfall"}
 q[43844] = {sur,"Treasure Chest"           ,nil,nil,{1033, 17.26, 54.62},nil,1,chests_icon}
 q[43842] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 23.4 , 48.77},nil,1,chests_icon}
 q[40902] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 37.81, 75.38, {level=23},1033, 36.39, 76.79, cave_entrance},nil,1,chests_icon}
 q[43835] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 39.38, 76.39, {level=23},1033, 36.39, 76.79, cave_entrance},nil,1,chests_icon}
 q[44325] = {sur,"Treasure Chest"           ,nil,nil,{1033, 50.06, 80.6 },nil,1,chests_icon,nil,nil,nil,nil,"Second floor"}
 q[43868] = {sur,"Treasure Chest"           ,nil,nil,{1033, 51.89, 82.13},nil,1,chests_icon}
 q[43834] = {sur,"Treasure Chest"           ,nil,nil,{1033, 32.27, 77.08,{desc="Use Legion Portal at 31, 85"},1033,31.01,85.11,{desc="Legion Portal",icon = cave_entrance.icon}},nil,1,chests_icon,nil,nil,nil,nil,"Requires completion of |cffffff00"..select(1, GetAchievementCriteriaInfo(11124, 7)).."|r storyline"}
 q[44323] = {sur,"Treasure Chest"           ,nil,nil,{1033, 48.58, 72.16},nil,1,chests_icon,nil,nil,nil,nil,"Second floor"}
 q[44324] = {sur,"Treasure Chest"           ,nil,nil,{1033, 48.29, 71.21},nil,1,chests_icon,nil,nil,nil,nil,"Second floor, behind a blocked door.@seems impossible to reach without jumping tricks"}
 q[43869] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 44.38, 75.86},nil,1,chests_icon}
 q[43864] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 49.98, 84.92},nil,1,chests_icon,nil,nil,nil,nil,"Grapple on the edge of the building"}
 q[43866] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 48.27, 82.61},nil,1,chests_icon,nil,nil,nil,nil,"Grapple on the edge of the building"}
 q[43865] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 48.11, 73.2 },nil,1,chests_icon,nil,nil,nil,nil,"Grapple on the edge of the building"}
 q[43867] = {sur,"Treasure Chest"           ,nil,nil,{1033, 48.94, 73.78},nil,1,chests_icon,nil,nil,nil,nil,"Second floor"}
 q[43875] = {sur,"Treasure Chest"           ,nil,nil,{1033, 54.31, 60.31},nil,1,chests_icon}
 q[43874] = {sur,"Treasure Chest"           ,nil,nil,{1033, 57.68, 61.96},nil,1,chests_icon}
 q[43873] = {sur,"Treasure Chest"           ,nil,nil,{1033, 57.32, 60.37},nil,1,chests_icon}
 q[43870] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 42.57, 76.66},nil,1,chests_icon}
 q[43871] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 55.68, 54.8 },nil,1,chests_icon,nil,nil,nil,nil,"Behind the house"}
 q[43872] = {sur,"Treasure Chest"           ,nil,nil,{1033, 61.34, 55.49},nil,1,chests_icon,nil,nil,nil,nil,"In the house"}
 q[43876] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 60.34, 68.49},nil,1,chests_icon}
 q[43830] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 38.13, 87.12},nil,1,chests_icon}
 q[43839] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 21.23, 42.18, {level=33}, 1033, 21.23, 42.18},nil,1,chests_icon,nil,nil,nil,nil, "Up on the column"}
 q[43859] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 71.46, 49.75},nil,1,chests_icon,nil,nil,nil,nil, "On top of the tower"}
 q[43861] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 81.96, 57.45,{desc="Cave entrance west of here"},1033,79.26,57.44,cave_entrance},nil,1,chests_icon,nil,nil,nil,nil, "Underwater"}
 q[43855] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 51.5 , 38.6 },nil,1,chests_icon}
 q[43857] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 63.65, 49.1},nil,1,chests_icon,nil,nil,nil,nil, "In the cave"}
 q[43860] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 76.85, 61.5},nil,1,chests_icon,nil,nil,nil,nil, "In the wreckage (underwater)"}
 q[43845] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 19.78, 16.04,{desc="Cave entrance south of here"},1033,19.38,19.43,cave_entrance},nil,1,chests_icon}
 q[44179] = {sur,"Protected Treasure Chest" ,nil,nil,{1033, 34.64,86.43,{level=24},1033,34.4,84.07,cave_entrance},nil,1,chests_icon}
 q[43831] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 25.95, 85.45,{desc="Cave entrance east of here"},1033,29.17,84.1,cave_entrance},nil,1,chests_icon}
 --q[43831] = {sur,"Small Treasure Chest"     ,nil,nil,{1033, 31.95, 62.51},nil,1,chests_icon}
 
 q[42842] = {sur,"Kel'danath's Manaflask"   ,nil,nil,{1033, 21.41, 54.46},nil,1,chests_icon2,nil,nil,nil,nil,"|Hitem:136269:0:0:0:0:0:0:0:0:0:0:0:1:0|h[am]|h"}
 q[43988] = {sur,"Volatile Leyline Crystal" ,nil,nil,{1033, 21.24, 33.7 , {level=32}, 1033, 22.82, 35.9,  {icon=chests_icon2, desc="Cave Entrance"}},nil,1,chests_icon2,nil,nil,nil,nil,"|Hitem:140328:0:0:0:0:0:0:0:0:0:0:0:1:0|h[am]|h"}
 q[43989] = {sur,"Infinite Stone"           ,nil,nil,{1033, 35.56, 12.08},nil,1,chests_icon2,nil,nil,nil,nil,"|Hitem:140329:0:0:0:0:0:0:0:0:0:0:0:1:0|h[am]|h"}
 q[43986] = {sur,"Enchanted Burial Urn"     ,nil,nil,{1033, 44.82, 31   },nil,1,chests_icon2,nil,nil,nil,nil,"|Hitem:140326:0:0:0:0:0:0:0:0:0:0:0:1:0|h[am]|h"}
 q[43987] = {sur,"Kyrtos's Research Notes"  ,nil,nil,{1033, 26.86, 70.71,nil,1033,27.3,72.96,cave_entrance},nil,1,chests_icon2,nil,nil,nil,nil,"|Hitem:140327:0:0:0:0:0:0:0:0:0:0:0:1:0|h[am]|h"}

 --q[43747] = {sur, "Crystalline Mana Cluster",nil,nil,{1033, 18.39, 39.98,{level=33},1033, 20.4, 50.31, cave_entrance},nil,1,mana_cluster_icon}--   18.39, 39.98 --{level=33}, 1033, 20.4, 50.31, cave_entrance wowhead Currency Treasure - Falanaar
 --q[43748] = {sur, "Crystalline Mana Cluster",nil,nil,{1033, 29.78, 88.1},nil,1,mana_cluster_icon}--   29.78, 88.1  wowhead Currency Treasure - Felsoul Hold
 --q[43741] = {sur, "Crystalline Mana Cluster",nil,nil,{1033, 79.71, 72.74},nil,1,mana_cluster_icon}-- 79.71, 72.74 wowhead Currency Treasure - Azuregale
 --q[43743] = {sur, "Crystalline Mana Cluster",nil,nil,{1033, 64.91, 34.75,{level=34}, 1033,65.95, 42.08,cave_entrance},nil,1,mana_cluster_icon}-- 64.91, 34.75 -- (cave entrance 65.95, 42.08) wowhead Currency Treasure - Crimson Thicket
 --q[43744] = {sur, "Shimmering Mana Cluster", nil,nil,{1033, 46.55, 26.01},nil,1,mana_cluster_icon}--     46.55, 26.01 -- wowhead Currency Treasure - Telanor
 
 -- Suramar Collapse Scenario
 q[43149] = {sur,"Treasure Chest"           ,nil,nil,{1033, 20.54, 32.29, {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139010:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43071] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 21.88, 29.06, {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139011:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43140] = {sur,"Treasure Chest"           ,nil,nil,{1033, 21.63, 33.77, {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:140778:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43111] = {sur,"Treasure Chest"           ,nil,nil,{1033, 21.81, 39.45, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139017:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 --q[43146] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 20.48, 36.94, {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:140451:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43146] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 20.9 , 36.1 , {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:140451:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 --q[43144] = {sur,"Treasure Chest"           ,nil,nil,{1033, 23.31, 44.22, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:141296:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43144] = {sur,"Treasure Chest"           ,nil,nil,{1033, 25.31, 44.22, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:141296:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43143] = {sur,"Treasure Chest"           ,nil,nil,{1033, 20.65, 43   , {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:141313:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43134] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 20.27, 44.53, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139027:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43148] = {sur,"Treasure Chest"           ,nil,nil,{1033, 23.72, 48.56, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:140448:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43128] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 24.18, 46.36, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139019:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h~Miniboss in the room"}
 q[43142] = {sur,"Treasure Chest"           ,nil,nil,{1033, 24.3 , 52.53, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:141314:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43135] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 18.51, 39.86, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139028:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43141] = {sur,"Treasure Chest"           ,nil,nil,{1033, 21.38, 50.35, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:136914:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43145] = {sur,"Glimmering Treasure Chest",nil,nil,{1033, 17.68, 47.05, {level=2}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:140450:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 q[43120] = {sur,"Treasure Chest"           ,nil,nil,{1033, 26.03, 30.83, {level=1}},nil,1,chests_icon,nil,nil,nil,nil,"|Hitem:139018:0:0:0:0:0:0:0:0:0:0:0:1:0|h[cs]|h"}
 
 -- Dalaran
 q[39846] = {dal,"Treasure Chest",nil,nil,{1014, 38.4, 30.1,{level=10}},nil,1,chests_icon}

 -- suramar portals 
 local function portalfunc()
  return false, " "
 end

 local function portalshow(questID)
  if questID == 42487 and IsQuestFlaggedCompleted(42889) then
   return false
  end
  return IsQuestFlaggedCompleted(questID)
 end

 q[41575] = {sur,GetSpellInfo(222550),nil,nil,{1033, 39.13, 76.26},nil,1,portal_icon,portalshow, portalfunc} -- fel
 q[42487] = {sur,GetSpellInfo(224670),nil,nil,{1033, 47.74, 81.37},nil,1,portal_icon,portalshow, portalfunc} -- waning
 q[42889] = {sur,GetSpellInfo(231400),nil,nil,{1033, 51.98, 78.76},nil,1,portal_icon,portalshow, portalfunc} -- evermoon
 q[44084] = {sur,GetSpellInfo(224674),nil,nil,{1033, 64, 60.4},nil,1,portal_icon,portalshow, portalfunc} -- vineyards
 q[43811] = {sur,GetSpellInfo(222545),nil,nil,{1033, 43.68, 79.24},nil,1,portal_icon,portalshow, portalfunc} -- lunastre
 q[42230] = {sur,GetSpellInfo(224669),nil,nil,{1033, 21.89, 29,nil,1033, 21.89, 29,{level=32}},nil,1,portal_icon,portalshow, portalfunc} -- falanaar
 q[43808] = {sur,GetSpellInfo(222548),nil,nil,{1033, 30.82, 11},nil,1,portal_icon,portalshow, portalfunc} -- moon
 q[43809] = {sur,GetSpellInfo(222547),nil,nil,{1033, 42.16, 35.37},nil,1,portal_icon,portalshow, portalfunc} -- tel
 q[43813] = {sur,GetSpellInfo(222549),nil,nil,{1033, 43.34, 60.57},nil,1,portal_icon,portalshow, portalfunc} -- sanc
 q[44740] = {sur,GetSpellInfo(229432),nil,nil,{1033, 54.46, 69.45},nil,1,portal_icon,portalshow, portalfunc} -- harbor
 
 --local vethir_icon = "interface\\icons\\inv_misc_head_dragon_blue"
 --q["veth_galebroken"] = {sto,"Galebroken Path",nil,nil,{1017, 44.82, 77.38},nil,1,vethir_icon, vethirshow} -- galebroken
 --q["veth_thorim_down"] = {sto,"Thorim's Peak (Thorignir Refuge)",nil,nil,{1017, 42.78, 82.67},nil,1,vethir_icon, vethirshow} -- thorim's peak down
 --q["veth_thorim_top"] = {sto,"Thorim's Peak (top)",nil,nil,{1017, 41.29, 80.09},nil,1,vethir_icon, vethirshow} -- thorim's peak top
 

 -- ley line feeds
 -- kel'balor 43588 59.38, 43.05
 -- moonwhisper gulch 43590 35.98, 19.55  cave entrance 35.68, 24.29
 -- falanaar south 43593 23.25, 49.11, level=33 (cave entrance 20.4, 50.31)
 -- elor'shan 43587 64.69, 37.69, level=34, 65.95, 42.08
 -- 43741 mana cluster 79.66, 72.86
end

list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)
