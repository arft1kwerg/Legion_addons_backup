-- Daily Global Check - Garrison Follower Missions plugin
-- Jadya EU-Well of Eternity

local isBeta = C_Garrison.HasGarrison

local tinsert, format, tsort, lower = tinsert, string.format, table.sort, string.lower

local addonName, addonTable = ...

local getcharname = DailyGlobalCheck.GetModCharName

local pID, pTable
local plugin_data
local order_cache = {{},{},{}}
local questsdata = {}
local order = {{}}
 
local textures = {"Interface\\Garrison\\Portraits\\FollowerPortrait_NoPortrait", -- normal
                  "Interface\\Garrison\\ShipsCargoShipMap"} -- naval
local questID_pref = "missions_"

-- mission types
local group_titles = {GARRISON_LOCATION_TOOLTIP, GARRISON_SHIPYARD_FLEET_TITLE, nil, ORDER_HALL_MISSIONS or "Order Hall Missions"}
local groups_pref  = {"Garrison","Ships",nil,"ClassHall"}
local missions_per_type = {25,10,nil,10}

local plugintitle = "Follower Missions"
local pluginicon = "Interface\\Icons\\Achievement_General_CityAttacker2"

local function formattime(s)
 --return format("%.2d:%.2d:%.2d", s/(60*60), s/60%60, s%60)
 return SecondsToTime(s)
end

local function isquestcompleted(questID)
 if not questsdata[questID].missionTimer then return false, NOT_APPLICABLE end

 local now = time()
 if questsdata[questID].missionTimer > now then
  return false, formattime(questsdata[questID].missionTimer - now)
 else
  return true
 end
end

local function sortfunc(a, b)
 return a.timer < b.timer
end

local tmp = {}
local sorted_missions = {}
local function sort(t)
 wipe(sorted_missions)
 wipe(tmp)
 for _,v in pairs(t) do
  tmp[#tmp + 1] = v
 end
 tsort(tmp, sortfunc)
 for k,v in pairs(tmp) do
  sorted_missions[k] = v
 end
end

local function update()
 local pID = DailyGlobalCheck.selectedpID

 wipe(order[1])

 local found
 local group = 1
 
 for followerTypeID,title in pairs(group_titles) do
  local i = 1
  local maxMissions = missions_per_type[followerTypeID]
  wipe(order_cache[group])
  tinsert(order_cache[group], title)
  local found
  if (not DGC_GarrMSaves[pID] or not DGC_GarrMSaves[pID].Options or DGC_GarrMSaves[pID].Options[followerTypeID] ~= false) and pTable[pID] and pTable[pID].missions[followerTypeID] then
   sort(pTable[pID].missions[followerTypeID])
   for k,v in pairs(sorted_missions) do
    local questID = questID_pref..groups_pref[followerTypeID]..i
    questsdata[questID].missionTimer = v.timer
	questsdata[questID][2] = v.name
	order_cache[group][#order_cache[group] + 1] = questID
	i = i + 1
	found = true
    if i > maxMissions then break end
   end
  end
  if found then
   tinsert(order[1], order_cache[group])
  end
  group = group + 1
  while i <= maxMissions do
   questsdata[questID_pref..groups_pref[followerTypeID]..i][2] = "<mission - "..groups_pref[followerTypeID]..i..">"
   questsdata[questID_pref..groups_pref[followerTypeID]..i].missionTimer = nil
   i = i + 1
  end
 end 
end

local function GenerateData()
 for followerTypeID,title in pairs(group_titles) do
  for i = 1,missions_per_type[followerTypeID] do
   questsdata[questID_pref..groups_pref[followerTypeID]..i] = {nil,"", [7] = 14, [10] = isquestcompleted}
  end
 end
end

local function updateMissions()
 if DailyGlobalCheck.selectedpID == pID then
  for followerTypeID in pairs(group_titles) do
   if pTable[pID].missions[followerTypeID] then
    local in_progress = C_Garrison.GetInProgressMissions(followerTypeID)
    local completed = C_Garrison.GetCompleteMissions(followerTypeID)
    for k,m in pairs(pTable[pID].missions[followerTypeID]) do
     local found
     for _,v in pairs(in_progress) do
      if k == v.missionID then found = true end
     end
     for _,v in pairs(completed) do
      if k == v.missionID then found = true end
     end
     if not found then
      pTable[pID].missions[followerTypeID][k] = nil
     end
    end
   end
  end
 end

 update()
end

local function onDraw(list, isPlugin)
 if list ~= plugin_data and isPlugin then return end
 updateMissions()
end

local function option_changed(opt, value, list)
 if list ~= plugin_data or not group_titles[opt] then return end
 DGC_GarrMSaves[pID].Options[opt] = value
end

local function Initialize()
 local pName = GetUnitName("player")
 local pRealm = GetRealmName()
 pID = pName.."-"..pRealm
 
 DGCEventFrame:Hook("ON_DRAW", onDraw)
 DGCEventFrame:Hook("OPTION_CHANGED_PLUGIN", option_changed)
 
 if not DGC_GarrMSaves then DGC_GarrMSaves = {} end
 if not DGC_GarrMSaves[pID] then DGC_GarrMSaves[pID] = {} end
 if not DGC_GarrMSaves[pID].Options then DGC_GarrMSaves[pID].Options = {} end
 
 pTable = DGC_GarrMSaves
 
 -- options shuffled, make sure they reflect changes
 if not pTable.Pversion then
  local svar = DailyGlobalCheck_PluginData and DailyGlobalCheck_PluginData[plugintitle]
  local opt = svar and svar.options
  if opt then
   opt[1] = opt[2]
   opt[2] = opt[3]
  end
  pTable.Pversion = 1
 end

 if not pTable[pID].missions then pTable[pID].missions = {} end

 local eventframe = CreateFrame("FRAME")
 eventframe:RegisterEvent("GARRISON_MISSION_STARTED")
 eventframe:RegisterEvent("GARRISON_MISSION_COMPLETE_RESPONSE")

 local function eventhandler(self, event, ...)
   if event == "GARRISON_MISSION_COMPLETE_RESPONSE" then
   updateMissions()
  elseif event == "GARRISON_MISSION_STARTED" then
   local followerTypeID, missionID
   if isBeta then
    followerTypeID, missionID = ...
   else
    missionID = ...
    for tID,gt in pairs(group_titles) do
	 local missions = C_Garrison.GetInProgressMissions(tID)
	 if missions then
      for _,v in pairs(missions) do
	   if v.missionID == missionID then
	    followerTypeID = v.followerTypeID
	    break
	   end
	  end
	 end
	end
   end

   local name = C_Garrison.GetMissionName(missionID)
   local _, st, _, _, et = C_Garrison.GetMissionTimes(missionID)
   local t = time() + st + et
   if not pTable[pID].missions[followerTypeID] then
    pTable[pID].missions[followerTypeID] = {}
   end
   pTable[pID].missions[followerTypeID][missionID] = { name = name, timer = t }
   updateMissions()
  end
 end
 eventframe:SetScript("OnEvent", eventhandler)
 
 local function enhance_completion(questID, data)
  local svar = DailyGlobalCheck_PluginData[plugintitle] and DailyGlobalCheck_PluginData[plugintitle].options
  if (svar and svar[3] == false) or
     DailyGlobalCheck.SelectedList ~= plugin_data or not DailyGlobalCheck.cs or type(questID) ~= "string" or 
     questID:sub(1, 6) ~= "oview_" then return end
  local id = questID:sub(7, #questID)
  
  if not pTable[id] then return end
  
  local now = time()
  local t, found = 0
  for _,v in pairs(pTable[id].missions) do
   for _,mission in pairs(v) do
    if mission.timer and mission.timer - now > t then
     t = mission.timer - now
	 found = true
    end
   end
  end

  if found then
   DailyGlobalCheck.cs = "|cffff0000"..SecondsToTime(t).."|r - "..DailyGlobalCheck.cs
  end
 end

 DGCEventFrame:Hook("ON_DRAW_COMPLETION", enhance_completion)
end

plugin_data = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Order"] = order,
 ["Initialize"] = Initialize,
 ["GenerateData"] = GenerateData,
 ["Options"] = {{"Checkbox","Show Garrison Follower Missions",true},
				{"Checkbox","Show Garrison Naval Missions",true},
				{"Checkbox","Show longest timer in Overview mode",true},
			   },
}

DailyGlobalCheck:LoadPlugin(plugin_data, questsdata)
