﻿-- Daily Global Check - WoD Rare Mobs plugin
-- Jadya EU-Well of Eternity
local addonName, addonTable = ...

local Z = DailyGlobalCheck.Z
local l = DailyGlobalCheck.LocalizeSection

local plugintitle = "WoD Rare Mobs"
local pluginicon = "Interface\\Icons\\INV_Misc_Bone_Skull_02"
local mobs_icon = "Interface\\WorldMap\\Skull_64Red"
local mobs_icon_d = "Interface\\WorldMap\\Skull_64Blue"
local mobs_icon_r = "Interface\\WorldMap\\Skull_64Purple"
local mobs_icon_g = "Interface\\WorldMap\\Skull_64Green"

local questsdata = {}
local list

local function onOptionChanged(i)
 local svar = DailyGlobalCheck_PluginData[plugintitle]

 local order = list.Order
 local maps = DailyGlobalCheck.MapFunctions

 if i == 1 then -- hide 6.0 assault rares
  if not svar or not svar.options or not svar.options[i] then
   -- frostfire
   order[1][2] = {nil,37382,34361,37378,37379}
   order[1][2][1] = l(order[1][2], nil, 1, "Assault on Magnarok", "quest", 37626)
   order[1][3] = {nil,37402,37404,37525,37401,37556}
   order[1][3][1] = l(order[1][3], nil, 1, "Assault on the Iron Siegeworks", "quest", 36823)
   order[1][4] = {nil,37386,37383,37384}
   order[1][4][1] = l(order[1][4], nil, 1, "Assault on Stonefury Cliffs", "quest", 36669)
   -- talador
   order[2][2] = {Z[481],37338,37341,37340,37312,37348,37346,37342,37337,37343,37349,37350,37345,37347}
   -- shadowmoon
   order[3][2] = {nil,37356,37351,37355,37353,37352,37354}
   order[3][2][1] = l(order[3][2], nil, 1, "Assault on Socrethar's Rise", "quest", 36347)
   order[3][3] = {nil,37410}
   order[3][3][1] = l(order[3][3], nil, 1, "Assault on Darktide Roost", "quest", 37633)
   -- spires
   order[4][2] = {nil,37394}
   order[4][2][1] = l(order[4][2], nil, 1, "Assault on Skettis", "quest", 36683)
   order[4][3] = {nil,37357,37359}
   order[4][3][1] = l(order[4][3], nil, 1, "Assault on Pillars of Fate", "quest", 36490)
   -- gorgrond
   order[5][2] = {nil,37374,37376,37369,37372,37371,37370,37373,37375,37377}
   order[5][2][1] = l(order[5][2], nil, 1, "Assault on the Everbloom Wilds", "quest", 36815)
   order[5][3] = {nil,37363,37362,37366,37367,37368,37365,37364}
   order[5][3][1] = l(order[5][3], nil, 1, "Assault on the Pit", "quest", 36701)
   -- nagrand
   order[6][3] = {nil,37399,37400}
   order[6][3][1] = l(order[6][3], nil, 1, "Assault on Mok'gol Watchpost", "quest", 36819)
   order[6][4] = {nil,37637}
   order[6][4][1] = l(order[6][4], nil, 1, "Challenge at the Ring of Blood", "quest", 36700)
  else
   -- frostfire
   order[1][2] = nil
   order[1][3] = nil
   order[1][4] = nil
   -- talador
   order[2][2] = nil
   -- shadowmoon
   order[3][2] = nil
   order[3][3] = nil
   -- spires
   order[4][2] = nil
   order[4][3] = nil
   -- gorgrond
   order[5][2] = nil
   order[5][3] = nil
   -- nagrand
   order[6][3] = nil
   order[6][4] = nil
  end
  maps:UpdateList("worldmap", list, true)
  maps:UpdateList("minimap", list, true)
 elseif i == 2 then
  maps:UpdateList("worldmap", list, true)
  maps:UpdateList("minimap", list, true)
 end
end

local questIDs_to_achi = addonTable.questIDs_to_achi

local function isquestcompleted(questID)
 if questID == "xemirkol" then
  local _, _, _, result = GetAchievementInfo(10334)
  return result
 else
  local svar = DailyGlobalCheck_PluginData[plugintitle]
  local achi_info = questIDs_to_achi[questID]

  if achi_info and svar and svar.options and svar.options[2] then -- check achievement for tanaan rares
   local achiID, criteria = unpack(achi_info)
   if not GetAchievementInfo(achiID) then return false end 

   return select(3, GetAchievementCriteriaInfo(achiID, criteria)) and true or false
  else
   return IsQuestFlaggedCompleted(questID)
  end
 end
end

local function xemirkol_showfunc()
 -- jungle stalker
 if not select(4, GetAchievementInfo(10070)) then return false end
 
 -- order of the awakened
 local _, _, standingID = GetFactionInfoByID(1849)
 
 return standingID and standingID >= 8 or false
end

list = {
 ["Title"] = plugintitle,
 ["Icon"]  = pluginicon,
 ["Version"] = 1004,
 ["Options"] = {{"Checkbox","Hide 6.0 Assault Rares",false},
                {"Checkbox","Track Achievement for Tanaan Jungle Rares",true}},
 ["Order"] = {
			    -- Frostfire Ridge
				{
				{Z[941],32918,32941,33014,33843,33504,34131,33938,34129,34132,34133,34130,34470,34477,34497,34522,34559,34825,34839,34843,34865},
				},
                -- Talador
			    {
				{Z[946],34134,34135,34142,34145,34165,34167,34185,34189,34196,34205,34208,35219,34498,34859,34668,34671,35018,34929,36919,36858,34221},
				},
				-- Shadowmoon Valley
   			    {
				{Z[947],33039,33055,33664,33642,33038,33389,33640,33064,33061,35906,35558,35281,35725,35448,35731,35523,35553,35555,35732,35688,35847,35909,36880,34068,33043,33383},
				},
                -- Spires of Arak
			    {
				{Z[948],36478,35599,36129,36396,36254,36265,36267,36268,36276,36278,36279,36283,36288,36291,36297,36298,36306,36470,36472,36887,36943,37390,37392},
				},
                -- Gorgrond
			    {
				{Z[949],35335,35503,36387,36391,36204,37413,36186,35908,36178,34726,36837,35910,36394,36656,36393,36794},
				},
                -- Nagrand
                {
				{Z[950],34862,34645,34727,36128,35623,35712,35714,35715,35717,35778,35784,35836,35865,35875,35735,35877,35893,35898,35900,35912,35920,35923,35931,35932,35943,36159,36229,37395},
				{"",40073,40074,40075}
				},
				-- Tanaan Jungle
                {
				{Z[945],38282,38209,38207,38211,38700,38726,38589,38597,38604,38605,38597,38620,38609,38628,38631,38632,38654,38709,38764,38775,39399,39400,39379,38696,38825,38812,38820,38749,37407,38430,38600,39287,39288,39290,39289,"xemirkol"},
				{"",40104,40105,40106,40107}
				},
				-- Tanaan Jungle Assault Rares
				{
				{Z[945]},
				{"",38026,38029,38030,38031,38032},
				{"",37990,37953,39045,39046},                         --Assault on Ironhold Harbor
				{"",37937,38034},                                     --Assault on the Ruins of Kra'nak
				{"",38557,38579,38580,38457},                         --Assault on the Throne of Kil'jaeden
				{"",38400,38411,38634},                               --Assault on the Fel Forge
				{"",38746,38747,38750,38752,38751},                   --Battle At The Iron Front
				{"",38262,38263,38265,38264,38266,38496,38736,38756}, --Bleeding the Bleeding Hollow
				},
			 },
 }
 

local function GenerateData()

  local function setup_tanaan_localization_and_icons()
   for k,achi_info in pairs(questIDs_to_achi) do
    local data = questsdata[k]
    local name = data[2]
    local icon = data[8]
  
    local achiID, criteria = unpack(achi_info)
    if GetAchievementInfo(achiID) then
     local description, _, completed = GetAchievementCriteriaInfo(achiID, criteria)
     name = description
     icon = completed and mobs_icon_d or mobs_icon_g
    end
    data[2] = name
    data[8] = icon
   end
  end
  
 local ffr = Z[941]
 local tal = Z[946]
 local smv = Z[947]
 local soa = Z[948]
 local gor = Z[949]
 local nag = Z[950]
 local tj  = Z[945]
 
 local q = questsdata

-------- Frostfire Ridge ---------
 q[32918] = {ffr,"Giant-Slayer Kul"     ,nil,nil,{941, 54.6 ,22.2},nil,1,mobs_icon}
 q[32941] = {ffr,"Canyon Icemother"     ,nil,nil,{941, 34   ,23.2},nil,1,mobs_icon}
 q[33014] = {ffr,"Cindermaw"            ,nil,nil,{941, 41.6 ,49  },nil,1,mobs_icon}
 q[33843] = {ffr,"Broodmother Reeg'ak"  ,nil,nil,{941, 66.4 ,31.4},nil,1,mobs_icon}
 q[33504] = {ffr,"Firefury Giant"       ,nil,nil,{941, 71.4 ,46.8},nil,1,mobs_icon}
 q[34131] = {ffr,"Coldtusk"             ,nil,nil,{941, 54.6 ,69.4},nil,1,mobs_icon}
 q[33938] = {ffr,"Primalist Mur'og"     ,nil,nil,{941, 36.8 ,34  },nil,1,mobs_icon}
 q[34129] = {ffr,"Coldstomp the Griever",nil,nil,{941, 26.6 ,55.6},nil,1,mobs_icon}
 q[34132] = {ffr,"Scout Goreseeker"     ,nil,nil,{941, 76.4 ,63.4},nil,1,mobs_icon}
 q[34133] = {ffr,"The Beater"           ,nil,nil,{941, 26.8 ,31.6},nil,1,mobs_icon}
 q[34130] = {ffr,"Huntmaster Kuang"     ,nil,nil,{941, 58   ,37.8},nil,1,mobs_icon}
 q[34470] = {ffr,"Pale Fishmonger"      ,nil,nil,{941, 28.2 ,66.4},nil,1,mobs_icon}
 q[34477] = {ffr,"Cyclonic Fury"        ,nil,nil,{941, 67.4 ,78.2},nil,1,mobs_icon}
 q[34497] = {ffr,"Breathless"           ,nil,nil,{941, 27.6 ,50  },nil,1,mobs_icon}
 q[34522] = {ffr,"Ug'lok the Frozen"    ,nil,nil,{941, 40.6 ,12.4},nil,1,mobs_icon}
 q[34559] = {ffr,"Yaga the Scarred"     ,nil,nil,{941, 40.6 ,27.8},nil,1,mobs_icon}
 q[34825] = {ffr,"Gruuk"                ,nil,nil,{941, 51.8 ,64.8},nil,1,mobs_icon}
 q[34839] = {ffr,"Gurun"                ,nil,nil,{941, 46   ,57  },nil,1,mobs_icon,nil,nil,"Cave entrance"}
 q[34843] = {ffr,"Chillfang"            ,nil,nil,{941, 41.2 ,68.2},nil,1,mobs_icon}
 q[34865] = {ffr,"Grutush the Pillager" ,nil,nil,{941, 38.6 ,63  },nil,1,mobs_icon}
 --[0] = {ffr,"Taskmaster Kullah","","",{[941] = {84.4,48.8}},941,1,mobs_icon}, 
-- daily assault zone rares
-- iron siegeworks
 q[37402] = {ffr,"Ogom the Mangler"     , nil, nil, {941, 83.6 ,47.2},nil, nil, mobs_icon_d}
 q[37404] = {ffr,"Kaga the Ironbender"  , nil, nil, {941, 87   ,46.4},nil, nil, mobs_icon_d}
 q[37525] = {ffr,"Ak'ox the Slaughterer", nil, nil, {941, 88.6 ,57.4},nil, nil, mobs_icon_d}
 q[37401] = {ffr,"Ragore Driftstalker"  , nil, nil, {941, 86.6 ,48.8},nil, nil, mobs_icon_d}
 q[37556] = {ffr,"Jaluk the Pacifist"   , nil, nil, {941, 85   ,52.2},nil, nil, mobs_icon_d}
-- magnarok
 q[37382] = {ffr,"Hoarfrost"       , nil, nil, {941, 68.8, 19.4},nil,nil,mobs_icon_d}
 q[34361] = {ffr,"The Bone Crawler", nil, nil, {941, 72.2, 33  },nil,nil,mobs_icon_d}
 q[37378] = {ffr,"Valkor"          , nil, nil, {941, 72.4, 24.2},nil,nil,mobs_icon_d}
 q[37379] = {ffr,"Vrok the Ancient", nil, nil, {941, 70.6, 39  },nil,nil,mobs_icon_d}
-- daggermaw ravine
 q[37386] = {ffr,"Jabberjaw"     ,nil,nil,{941, 49  , 24.2},nil,nil,mobs_icon_d}
 q[37384] = {ffr,"Tor'goroth"    ,nil,nil,{941, 43.6, 9.4 },nil,nil,mobs_icon_d} 
 q[37383] = {ffr,"Son of Goramal",nil,nil,{941, 38.2, 16  },nil,nil,mobs_icon_d} 

 -------- Talador ---------
 q[34134] = {tal,"Isaari"                  ,nil,nil,{946, 57.2, 75.4},nil,1,mobs_icon} 
 q[34135] = {tal,"Yazheera the Incinerator",nil,nil,{946, 53.8, 25.8},nil,1,mobs_icon} 
 q[34142] = {tal,"Dr. Gloom"               ,nil,nil,{946, 68.2, 15.8},nil,1,mobs_icon} 
 q[34145] = {tal,"Frenzied Golem"          ,nil,nil,{946, 46.5, 55.5},nil,1,mobs_icon} 
 q[34165] = {tal,"Cro Fleshrender"         ,nil,nil,{946, 37.6, 70.4},nil,1,mobs_icon} 
 q[34167] = {tal,"Hen-Mother Hami"         ,nil,nil,{946, 76.4, 51  },nil,1,mobs_icon} 
 q[34185] = {tal,"Hammertooth"             ,nil,nil,{946, 64.5, 45.5},nil,1,mobs_icon} 
 q[34189] = {tal,"Glimmerwing"             ,nil,nil,{946, 32  , 64  },nil,1,mobs_icon} 
 q[34196] = {tal,"Ra'kahn"                 ,nil,nil,{946, 59.4, 59.6},nil,1,mobs_icon} 
 q[34205] = {tal,"Wandering Vindicator"    ,nil,nil,{946, 69.8, 31.8},nil,1,mobs_icon} 
 q[34208] = {tal,"Lo'marg Jawcrusher"      ,nil,nil,{946, 49  , 92  },nil,1,mobs_icon} 
 q[35219] = {tal,"The Burning Front"       ,nil,nil,{946, 56.6, 63  },nil,1,mobs_icon} 
 q[34498] = {tal,"Klikixx"                 ,nil,nil,{946, 66.8, 85.4},nil,1,mobs_icon} 
 q[34859] = {tal,"No'losh"                 ,nil,nil,{946, 86.4, 30.4},nil,1,mobs_icon} 
 q[34668] = {tal,"Talonpriest Zorkra"      ,nil,nil,{946, 53.8, 91  },nil,1,mobs_icon} 
 q[34671] = {tal,"Shirzir"                 ,nil,nil,{946, 42.8, 54.2},nil,1,mobs_icon} 
 q[35018] = {tal,"Felbark"                 ,nil,nil,{946, 50  , 83  },nil,1,mobs_icon} 
 q[34929] = {tal,"Gennadian"               ,nil,nil,{946, 67.4, 80.6},nil,1,mobs_icon} 
 q[36919] = {tal,"Grrbrrgle"               ,nil,nil,{946, 22.2, 75.4},nil,1,mobs_icon} 
 q[36858] = {tal,"Steeltusk"               ,nil,nil,{946, 68  , 35  },nil,1,mobs_icon} 
 q[34221] = {tal,"Echo of Murmur"          ,nil,nil,{946, 34  , 57.2},nil,1,mobs_icon} 
 --[0] = {tal,"Soulbinder Naylana","","",{[946] = {47,30}},946,1,mobs_icon},
 -- daily assault zone rares

 -- shattrath
 q[37338] = {tal,"Avatar of Socrethar"     ,nil,nil,{946, 46.6, 35.2},nil,nil,mobs_icon_d}
 q[37341] = {tal,"Felfire Consort"         ,nil,nil,{946, 47.6, 33  },nil,nil,mobs_icon_d}
 q[37340] = {tal,"Gug'tol"                 ,nil,nil,{946, 47.6, 39  },nil,nil,mobs_icon_d}
 q[37312] = {tal,"Haakun the All-Consuming",nil,nil,{946, 48  , 25.4},nil,nil,mobs_icon_d}
 q[37348] = {tal,"Kurlosh Doomfang"        ,nil,nil,{946, 37.2, 37.6},nil,nil,mobs_icon_d}
 q[37346] = {tal,"Lady Demlash"            ,nil,nil,{946, 33.8, 37.8},nil,nil,mobs_icon_d}
 q[37342] = {tal,"Legion Vanguard"         ,nil,nil,{946, 37.8, 21.4},nil,nil,mobs_icon_d}
 q[37337] = {tal,"Strategist Ankor"        ,nil,nil,{946, 47  , 30  },nil,nil,mobs_icon_d}
 q[37343] = {tal,"Xothear, the Destroyer"  ,nil,nil,{946, 38  , 14.6},nil,nil,mobs_icon_d}
 q[37349] = {tal,"Matron of Sin"           ,nil,nil,{946, 39  , 49.6},nil,nil,mobs_icon_d}
 q[37350] = {tal,"Vigilant Paarthos"       ,nil,nil,{946, 37.8, 40.0},nil,nil,mobs_icon_d}
 q[37345] = {tal,"Lord Korinak"            ,nil,nil,{946, 31.0, 26.8},nil,nil,mobs_icon_d}
 q[37347] = {tal,"Shadowflame Terrorwalker",nil,nil,{946, 41.0, 42.2},nil,nil,mobs_icon_d}

-------- Shadowmoon Valley ---------
 q[33039] = {smv,"Ku'targ the Voidseer" ,nil,nil,{947, 32.2, 35  },nil,1,mobs_icon} --
 q[33055] = {smv,"Leaf-Reader Kurri"    ,nil,nil,{947, 37.6, 14.6},nil,1,mobs_icon} --
 q[33664] = {smv,"Gorum"                ,nil,nil,{947, 24.5, 33.2},nil,1,mobs_icon,nil,nil,"Cave entrance"} --
 q[33642] = {smv,"Mother Om'ra"         ,nil,nil,{947, 44  , 57.6},nil,1,mobs_icon} --
 q[33038] = {smv,"Windfang Matriarch"   ,nil,nil,{947, 42.8, 41  },nil,1,mobs_icon} --
 q[33389] = {smv,"Yggdrel"              ,nil,nil,{947, 48.6, 65.2},nil,1,mobs_icon} --
 q[33640] = {smv,"Veloss"               ,nil,nil,{947, 21.8, 21.6},nil,1,mobs_icon} --
 q[33064] = {smv,"Dark Emanation"       ,nil,nil,{947, 48.6, 43.6},nil,1,mobs_icon} --
 q[33061] = {smv,"Amaukwa"              ,nil,nil,{947, 37.2, 36.4},nil,1,mobs_icon} --
 q[35906] = {smv,"Mad 'King' Sporeon"   ,nil,nil,{947, 44.8, 20.8},nil,1,mobs_icon} --
 q[35558] = {smv,"Hypnocroak"           ,nil,nil,{947, 37.6, 49  },nil,1,mobs_icon} --
 q[35281] = {smv,"Bahameye"             ,nil,nil,{947, 30.2, 7.4 },nil,1,mobs_icon} --
 q[35725] = {smv,"Faebright"            ,nil,nil,{947, 61.6, 61.8},nil,1,mobs_icon} --
 q[35448] = {smv,"Darkmaster Go'vid"    ,nil,nil,{947, 40  , 81.6},nil,1,mobs_icon} --
 q[35731] = {smv,"Ba'ruun"              ,nil,nil,{947, 52.8, 16.8},nil,1,mobs_icon} --
 q[35523] = {smv,"Morva Soultwister"    ,nil,nil,{947, 38.6, 70.2},nil,1,mobs_icon} --
 q[35553] = {smv,"Rai'vosh"             ,nil,nil,{947, 48.6, 22.6},nil,1,mobs_icon} --
 q[35555] = {smv,"Darktalon"            ,nil,nil,{947, 49.6, 42  },nil,1,mobs_icon} --
 q[35732] = {smv,"Shinri"               ,nil,nil,{947, 60  , 55.2},nil,1,mobs_icon,nil,nil,"Patrols"} --
 q[35688] = {smv,"Enavra"               ,nil,nil,{947, 67.8, 63.8},nil,1,mobs_icon} --
 q[35847] = {smv,"Voidseer Kalurg"      ,nil,nil,{947, 32.6, 41.4},nil,1,mobs_icon} --
 q[35909] = {smv,"Insha'tar"            ,nil,nil,{947, 57.4, 48.6},nil,1,mobs_icon} --
 q[36880] = {smv,"Sneevel"              ,nil,nil,{947, 27.6, 43.6},nil,1,mobs_icon}
 q[34068] = {smv,"Rockhoof"             ,nil,nil,{947, 52  , 51  },nil,1,mobs_icon}
 q[33043] = {smv,"Killmaw"              ,nil,nil,{947, 40.8, 44.4},nil,1,mobs_icon}
 q[33383] = {smv,"Brambleking Fili"     ,nil,nil,{947, 44.8, 77.2},nil,1,mobs_icon} --
 -- daily assault zone rares
 -- socrethar's rise
 q[37356] = {smv,"Aqualir"               ,nil,nil,{947, 50.8, 78.8},nil,nil,mobs_icon_d}
 q[37351] = {smv,"Demidos"               ,nil,nil,{947, 46  , 71.6},nil,nil,mobs_icon_d} --
 q[37355] = {smv,"Lady Temptessa"        ,nil,nil,{947, 48  , 77.6},nil,nil,mobs_icon_d}
 q[37353] = {smv,"Master Sergeant Milgra",nil,nil,{947, 51.8, 79.2},nil,nil,mobs_icon_d} --
 q[37352] = {smv,"Quartermaster Hershak" ,nil,nil,{947, 50.2, 72.4},nil,nil,mobs_icon_d} --
 q[37354] = {smv,"Shadowspeaker Niir"    ,nil,nil,{947, 48.2, 81  },nil,nil,mobs_icon_d} --
 -- darktide roost
 q[37410] = {smv,"Avalanche"             ,nil,nil,{947, 67.2, 84.8},nil,nil,mobs_icon_d,nil,nil,"Cave entrance"}

 -------- Spires of Arak ---------
 q[36478] = {soa,"Shadowbark"             ,nil,nil,{948, 52  , 35.6},nil,1,mobs_icon} -- 
 q[35599] = {soa,"Blade-Dancer Aeryx"     ,nil,nil,{948, 46.8, 23  },nil,1,mobs_icon}
 q[36129] = {soa,"Nas Dunberlin"          ,nil,nil,{948, 36.4, 52.4},nil,1,mobs_icon}
 q[36396] = {soa,"Mutafen"                ,nil,nil,{948, 54.6, 89  },nil,1,mobs_icon}
 q[36254] = {soa,"Tesska the Broken"      ,nil,nil,{948, 57.4, 74  },nil,1,mobs_icon}
 q[36265] = {soa,"Stonespite"             ,nil,nil,{948, 33.4, 22  },nil,1,mobs_icon}
 q[36267] = {soa,"Durkath Steelmaw"       ,nil,nil,{948, 46.4, 28.6},nil,1,mobs_icon}
 q[36268] = {soa,"Kalos the Bloodbathed"  ,nil,nil,{948, 62.8, 37.6},nil,1,mobs_icon}
 q[36276] = {soa,"Sangrikass"             ,nil,nil,{948, 68.8, 49  },nil,1,mobs_icon}
 q[36278] = {soa,"Talonbreaker"           ,nil,nil,{948, 54.6, 63.2},nil,1,mobs_icon}
 q[36279] = {soa,"Poisonmaster Bortusk"   ,nil,nil,{948, 59.4, 37.4},nil,1,mobs_icon}
 q[36283] = {soa,"Blightglow"             ,nil,nil,{948, 65.2, 67.6},nil,1,mobs_icon}
 q[36288] = {soa,"Oskiira the Vengeful"   ,nil,nil,{948, 66  , 55  },nil,1,mobs_icon}
 q[36291] = {soa,"Betsi Boombasket"       ,nil,nil,{948, 58.4, 84.2},nil,1,mobs_icon}
 q[36297] = {soa,"Festerbloom"            ,nil,nil,{948, 54.8, 39.6},nil,1,mobs_icon}
 q[36298] = {soa,"Sunderthorn"            ,nil,nil,{948, 58.6, 45.2},nil,1,mobs_icon}
 q[36306] = {soa,"Jiasska the Sporegorger",nil,nil,{948, 56.6, 94.6},nil,1,mobs_icon}
 q[36470] = {soa,"Rotcap"                 ,nil,nil,{948, 38.4, 27.8},nil,1,mobs_icon}
 q[36472] = {soa,"Swarmleaf"              ,nil,nil,{948, 52.8, 55.6},nil,1,mobs_icon}
 q[36887] = {soa,"Hermit Palefur"         ,nil,nil,{948, 59.2, 15  },nil,1,mobs_icon}
 q[36943] = {soa,"Gaze"                   ,nil,nil,{948, 25.2, 24.2},nil,1,mobs_icon,nil,nil,"Click on Fel Grimoire"}
 q[37390] = {soa,"Gluttonous Giant"       ,nil,nil,{948, 74.4, 42.8},nil,1,mobs_icon}
 q[37392] = {soa,"Shadow Hulk"            ,nil,nil,{948, 71.2, 33.8},nil,1,mobs_icon}
 q[37394] = {soa,"Solar Magnifier"        ,nil,nil,{948, 51.8, 7.2 },nil,nil,mobs_icon_d} -- skettis
 q[37357] = {soa,"Malgosh Shadowkeeper"   ,nil,nil,{948, 72  , 26  },nil,nil,mobs_icon_d} -- assault on pillars of fate
 q[37359] = {soa,"Voidreaver Urnae"       ,nil,nil,{948, 74  , 32  },nil,nil,mobs_icon_d}	-- assault on pillars of fate

-------- Gorgrond ---------
 q[35335] = {gor,"Bashiok"                 ,nil,nil,{949, 40  , 79  },nil,1,mobs_icon} -- bashiok
 q[35503] = {gor,"Char the Burning"        ,nil,nil,{949, 53.6, 44.6},nil,1,mobs_icon} -- char
 q[36387] = {gor,"Fossilwood the Petrified",nil,nil,{949, 57.6, 68.2},nil,1,mobs_icon} -- fossil
 q[36391] = {gor,"Gelgor of the Blue Flame",nil,nil,{949, 43.5, 48.1},nil,1,mobs_icon,nil,nil,"Cave entrance"} -- gelgor
 q[36204] = {gor,"Glut"                    ,nil,nil,{949, 46.2, 50.8},nil,1,mobs_icon} -- glut
 q[37413] = {gor,"Gnarljaw"                ,nil,nil,{949, 52.8, 53.6},nil,1,mobs_icon} -- gnarljaw
 q[36186] = {gor,"Greldrok the Cunning"    ,nil,nil,{949, 46.8, 43.2},nil,1,mobs_icon} -- greldrok
 q[35908] = {gor,"Hive Queen Skrikka"      ,nil,nil,{949, 52.2, 70.2},nil,1,mobs_icon} -- skrikka
 q[36178] = {gor,"Mandrakor"               ,nil,nil,{949, 50.6, 53.2},nil,1,mobs_icon} -- mandrakor
 q[34726] = {gor,"Mother Araneae"          ,nil,nil,{949, 53.4, 78.2},nil,1,mobs_icon} -- araneae
 q[36837] = {gor,"Stompalupagus"           ,nil,nil,{949, 55.2, 71.2},nil,1,mobs_icon} -- stompa
 q[35910] = {gor,"Stomper Kreego"          ,nil,nil,{949, 38.2, 66.2},nil,1,mobs_icon} -- kreego
 q[36394] = {gor,"Sulfurius"               ,nil,nil,{949, 41  , 61  },nil,1,mobs_icon} -- sulfurius
 q[36656] = {gor,"Sunclaw"                 ,nil,nil,{949, 44.6, 92.2},nil,1,mobs_icon} -- sunclaw
 q[36393] = {gor,"Rolkor"                  ,nil,nil,{949, 47.8, 41.2},nil,1,mobs_icon} -- rolkor
 q[36794] = {gor,"Sylldross"               ,nil,nil,{949, 63.6, 61.0},nil,1,mobs_icon} -- sylldross
 -- daily assault zone rares
 -- everbloom wilds
 q[37374] = {gor,GetAchievementCriteriaInfo(9678,1),nil,nil,{949, 60  , 32.5},nil,nil,mobs_icon_d} -- swift onyx
 q[37376] = {gor,GetAchievementCriteriaInfo(9678,2),nil,nil,{949, 61.8, 39.3},nil,nil,mobs_icon_d} -- mogamago
 q[37369] = {gor,GetAchievementCriteriaInfo(9678,3),nil,nil,{949, 69.2, 44.6},nil,nil,mobs_icon_d} -- protectors
 q[37372] = {gor,GetAchievementCriteriaInfo(9678,4),nil,nil,{949, 63.8, 31.6},nil,nil,mobs_icon_d} -- venolasix
 q[37371] = {gor,GetAchievementCriteriaInfo(9678,5),nil,nil,{949, 57  , 41  },nil,nil,mobs_icon_d} -- alca
 q[37370] = {gor,GetAchievementCriteriaInfo(9678,6),nil,nil,{949, 57.6, 35.8},nil,nil,mobs_icon_d} -- depth
 q[37373] = {gor,GetAchievementCriteriaInfo(9678,7),nil,nil,{949, 57.8, 36.6},nil,nil,mobs_icon_d} -- firestarter
 q[37375] = {gor,GetAchievementCriteriaInfo(9678,8),nil,nil,{949, 59.6, 43  },nil,nil,mobs_icon_d} -- grove
 q[37377] = {gor,GetAchievementCriteriaInfo(9678,9),nil,nil,{949, 55  , 46.6},nil,nil,mobs_icon_d} -- hunter
 -- the pit
 q[37363] = {gor,GetAchievementCriteriaInfo(9655,1),nil,nil,{949, 49  , 33.8},nil,nil,mobs_icon_d} -- Maniacal
 q[37362] = {gor,GetAchievementCriteriaInfo(9655,2),nil,nil,{949, 48.2, 21  },nil,nil,mobs_icon_d} -- Defector
 q[37366] = {gor,GetAchievementCriteriaInfo(9655,3),nil,nil,{949, 50  , 23.8},nil,nil,mobs_icon_d} -- Durp
 q[37367] = {gor,GetAchievementCriteriaInfo(9655,4),nil,nil,{949, 47.6, 30.6},nil,nil,mobs_icon_d} -- Inventor
 q[37368] = {gor,GetAchievementCriteriaInfo(9655,6),nil,nil,{949, 46  , 33.6},nil,nil,mobs_icon_d} -- Blademaster
 q[37365] = {gor,GetAchievementCriteriaInfo(9655,5),nil} -- Horgg
 q[37364] = {gor,GetAchievementCriteriaInfo(9655,7),nil} -- Morgo
--------------------------

-------- Nagrand ---------
-- 6.2.2
 q[40073] = {nag,"Pugg"                            ,nil,nil,{950, 28.5, 30.3},nil,nil,mobs_icon_d} -- Pugg
 q[40074] = {nag,"Guk"                             ,nil,nil,{950, 23.8, 37.9},nil,nil,mobs_icon_d} -- Guk
 q[40075] = {nag,"Rukdug"                          ,nil,nil,{950, 26.2, 34.2},nil,nil,mobs_icon_d} -- Rukdug
 q[34862] = {nag,"Hyperious"                       ,nil,nil,{950, 87  , 55  },nil,1,mobs_icon} -- Hyperious
 q[34645] = {nag,"Warmaster Blugthol"              ,nil,nil,{950, 82.6, 76.2},nil,1,mobs_icon} --Warmaster Blugthol
 q[34727] = {nag,"Captain Ironbeard"               ,nil,nil,{950, 34.6, 77  },nil,1,mobs_icon} --Captain Ironbeard
 q[36128] = {nag,"Soulfang"                        ,nil,nil,{950, 75.6, 65  },nil,1,mobs_icon} --Soulfang
 q[35623] = {nag,"Explorer Nozzand"                ,nil,nil,{950, 89  , 41.2},nil,1,mobs_icon} --Explorer Nozzand
 q[35712] = {nag,"Redclaw the Feral"               ,nil,nil,{950, 73.6, 57.8},nil,1,mobs_icon} --Redclaw the Feral
 q[35714] = {nag,"Greatfeather"                    ,nil,nil,{950, 66.8, 51.2},nil,1,mobs_icon} --Greatfeather
 q[35715] = {nag,"Gar'lua"                         ,nil,nil,{950, 52.2, 55.8},nil,1,mobs_icon} --Gar'lua
 q[35717] = {nag,"Gnarlhoof the Rabid"             ,nil,nil,{950, 66.6, 56.6},nil,1,mobs_icon} --Gnarlhoof the Rabid
 q[35778] = {nag,"Ancient Blademaster"             ,nil,nil,{950, 84.6, 53.4},nil,1,mobs_icon} --Ancient Blademaster
 q[35784] = {nag,"Grizzlemaw"                      ,nil,nil,{950, 86.4, 72.6},nil,1,mobs_icon} --Grizzlemaw
 q[35836] = {nag,"Fangler"                         ,nil,nil,{950, 74.8, 11.8},nil,1,mobs_icon} --Fangler 
 q[35865] = {nag,"Netherspawn"                     ,nil,nil,{950, 47.6, 70.8},nil,1,mobs_icon} --Netherspawn
 q[35875] = {nag,"Ophiis"                          ,nil,nil,{950, 42.5, 49.4},nil,1,mobs_icon} --Ophiis
 q[35877] = {nag,"Windcaller Korast"               ,nil,nil,{950, 70.6, 29.4},nil,1,mobs_icon} --Windcaller Korast
 q[35893] = {nag,"Flinthide"                       ,nil,nil,{950, 70  , 41.8},nil,1,mobs_icon} --Flinthide
 q[35898] = {nag,"Gorepetal"                       ,nil,nil,{950, 93.2, 28.2},nil,1,mobs_icon} --Gorepetal
 q[35900] = {nag,"Ru'klaa"                         ,nil,nil,{950, 58  , 84  },nil,1,mobs_icon} --Ru'klaa
 q[35912] = {nag,"Sean Whitesea"                   ,nil,nil,{950, 61.8, 47.2},nil,1,mobs_icon} --Sean Whitesea
 q[35920] = {nag,"Tura'aka"                        ,nil,nil,{950, 65  , 39  },nil,1,mobs_icon} --Tura'aka
 q[35923] = {nag,"Hunter Blacktooth"               ,nil,nil,{950, 80.6, 30.4},nil,1,mobs_icon} --Hunter Blacktooth
 q[35931] = {nag,"Scout Pokhar"                    ,nil,nil,{950, 54.8, 61.2},nil,1,mobs_icon} --Scout Pokhar
 q[35932] = {nag,"Malroc Stonesunder"              ,nil,nil,{950, 81.2, 60  },nil,1,mobs_icon} --Malroc Stonesunder
 q[35943] = {nag,"Outrider Duretha"                ,nil,nil,{950, 61.8, 69  },nil,1,mobs_icon} --Outrider Duretha
 q[36159] = {nag,"Graveltooth"                     ,nil,nil,{950, 84  , 36.6},nil,1,mobs_icon} --Graveltooth
 q[36229] = {nag,"Mr. Pinchy Sr."                  ,nil,nil,{950, 45.6, 15  },nil,1,mobs_icon} --Mr. Pinchy Sr.
 q[37395] = {nag,GetAchievementCriteriaInfo(9571,1),nil,nil,{950, 36  , 23  },nil,1,mobs_icon} --Durg Spinecrusher
 q[35735] = {nag,"Berserk T-300 Series Mark II"    ,nil,nil,{950, 76.9, 64.3},nil,1,mobs_icon} --Pit Beast
 -- reputation
 q["raremobs_rep_1"] = {nag,"Bergruu"          ,nil,"(reputation)",{950, 62.6, 16.2},nil,nil,mobs_icon_r} --Bergruu
 q["raremobs_rep_2"] = {nag,"Dekorhan"         ,nil,"(reputation)",{950, 64  , 30  },nil,nil,mobs_icon_r} --Dekorhan
 q["raremobs_rep_3"] = {nag,"Thek'talon"       ,nil,"(reputation)",{950, 63  , 29  },nil,nil,mobs_icon_r} --Thek'talon
 q["raremobs_rep_4"] = {nag,"Gagrog the Brutal",nil,"(reputation)",{950, 48  , 22  },nil,nil,mobs_icon_r} --Gagrog the Brutal
 q["raremobs_rep_5"] = {nag,"Xelganak"         ,nil,"(reputation)",{950, 41  , 44  },nil,nil,mobs_icon_r} --Xelganak
 q["raremobs_rep_6"] = {nag,"Direhoof"         ,nil,"(reputation)",{950, 60  , 36  },nil,nil,mobs_icon_r} --direhoof
 q["raremobs_rep_7"] = {nag,"Aogexon"          ,nil,"(reputation)",{950, 50.2, 41.2},nil,nil,mobs_icon_r} -- aogexon
 q["raremobs_rep_8"] = {nag,"Mu'gra"           ,nil,"(reputation)",{950, 34  , 51  },nil,nil,mobs_icon_r} --mu'gra
 q["raremobs_rep_9"] = {nag,"Vileclaw"         ,nil,"(reputation)",{950, 37.6, 39.8},nil,nil,mobs_icon_r} --vileclaw

 -- daily assault zone rares
 -- mok'gol watchpost
 q[37399] = {nag,"Karosh Blackwind",nil,nil,{950, 46, 36},nil,nil,mobs_icon_d} --Karosh Blackwind
 q[37400] = {nag,"Brutag Grimblade",nil,nil,{950, 43, 36},nil,nil,mobs_icon_d} --Brutag Grimblade
 -- ring of blood
 q[37637] = {nag,"Pit Beast"       ,nil,nil,{950, 58, 18},nil,nil,mobs_icon_d} --Pit Beast
 -- broken precipice
 q[37396] = {nag,"Bonebreaker"     ,nil,nil,{950, 39, 16},nil,nil,mobs_icon_d} --Brutag Grimblade
 --
 
 -------- Tanaan Jungle ---------

 -- Xemirkol
 q["xemirkol"] = {tj,"Xemirkol",nil,nil,{945, 69, 38.2},nil,1,mobs_icon_r,xemirkol_showfunc,isquestcompleted,nil,nil,"Can be found using the crystal"}
 -- 6.2.2
 q[40104] = {tj,"Smashum Grabb"       ,nil,nil,{945, 87.5, 56.1},nil,nil,mobs_icon_d,nil,isquestcompleted} -- Smashum Grabb
 q[40105] = {tj,"Drakum"              ,nil,nil,{945, 83.9, 43.2},nil,nil,mobs_icon_d,nil,isquestcompleted} -- Drakum
 q[40106] = {tj,"Gondar"              ,nil,nil,{945, 80.7, 56.1},nil,nil,mobs_icon_d,nil,isquestcompleted} -- Gondar
 q[40107] = {tj,"Fel Overseer Mudlump",nil,nil,{945, 40.7, 56.3},nil,nil,mobs_icon_d,nil,isquestcompleted} -- Fel Overseer Mudlump
 q[38282] = {tj,nil                   ,nil,nil,{945, 17.1, 50.8},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- podlord
 q[38209] = {tj,nil                   ,nil,nil,{945, 41  , 68  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- bramblefell
 q[38207] = {tj,nil                   ,nil,nil,{945, 48.4, 28.8},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127340:0:0:0:0:0:0:0:0:0:0:0:1:0|h[reter]|h"} -- zeter
 q[38211] = {tj,nil                   ,nil,nil,{945, 52.7, 26.6},nil,nil,mobs_icon_d,nil,isquestcompleted} -- felspark
 q[38700] = {tj,nil                   ,nil,nil,{945, 65.5, 36.8},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127357:0:0:0:0:0:0:0:0:0:0:0:1:0|h[steel]|h"} -- steel
 q[38726] = {tj,nil                   ,nil,nil,{945, 52  , 66.5},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127332:0:0:0:0:0:0:0:0:0:0:0:1:0|h[magw]|h"} -- magw
 q[38589] = {tj,nil                   ,nil,nil,{945, 57.4, 67.9},nil,nil,mobs_icon_d,nil,isquestcompleted} -- ixkor
 q[38600] = {tj,nil                   ,nil,nil,{945, 62.6, 72  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127315:0:0:0:0:0:0:0:0:0:0:0:1:0|h[souls]|h"} -- soulslicer
 q[38604] = {tj,nil                   ,nil,nil,{945, 63.5, 80.5},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127306:0:0:0:0:0:0:0:0:0:0:0:1:0|h[gloon]|h"} -- gloom
 q[38605] = {tj,nil                   ,nil,nil,{945, 51  , 83  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- krell
 q[38597] = {tj,nil                   ,nil,nil,{945, 49  , 72  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127330:0:0:0:0:0:0:0:0:0:0:0:1:0|h[black]|h"} -- black
 q[38620] = {tj,nil                   ,nil,nil,{945, 34.1, 44.3},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127327:0:0:0:0:0:0:0:0:0:0:0:1:0|h[thromma]|h"} -- thro
 q[38609] = {tj,nil                   ,nil,nil,{945, 35.5, 46.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127650:0:0:0:0:0:0:0:0:0:0:0:1:0|h[belgork]|h"} -- bel
 q[38628] = {tj,nil                   ,nil,nil,{945, 41  , 79  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127311:0:0:0:0:0:0:0:0:0:0:0:1:0|h[sylissa]|h"} -- sylissa
 q[38631] = {tj,nil                   ,nil,nil,{945, 43  , 73.9},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Collect and use 10 Smelly Musk Gland"} -- ren
 q[38632] = {tj,nil                   ,nil,nil,{945, 43  , 74.4},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Gain 10 stacks of Marked by the Night Haunter"} -- haunter
 q[38654] = {tj,nil                   ,nil,nil,{945, 36.1, 72.4},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- claw
 q[38709] = {tj,nil                   ,nil,nil,{945, 33.3, 35.8},nil,nil,mobs_icon_d,nil,isquestcompleted} -- gora
 q[38764] = {tj,nil                   ,nil,nil,{945, 34.5, 77.7},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Open cache to summon it"} -- glub
 q[38775] = {tj,nil                   ,nil,nil,{945, 30.4, 52.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- fel
 q[39399] = {tj,nil                   ,nil,nil,{945, 54.3, 81  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- akr
 q[39400] = {tj,nil                   ,nil,nil,{945, 54.3, 81  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- ren
 q[39379] = {tj,nil                   ,nil,nil,{945, 54.3, 81  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- eye
 q[38696] = {tj,nil                   ,nil,nil,{945, 44.5, 77.5},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- blee
 q[38825] = {tj,nil                   ,nil,nil,{945, 40.6, 69.4},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- kris
 q[38812] = {tj,nil                   ,nil,nil,{945, 49.8, 60.7},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127665:0:0:0:0:0:0:0:0:0:0:0:1:0|h[shadow]|h"} -- shadowthrash
 q[38820] = {tj,nil                   ,nil,nil,{945, 48.6, 57.4},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127664:0:0:0:0:0:0:0:0:0:0:0:1:0|h[grok]|h"} -- captain grok
 q[38749] = {tj,nil                   ,nil,nil,{945, 50  , 45  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Patrols"} -- commander org
 q[38430] = {tj,nil                   ,nil,nil,{945, 52.6, 40.6},nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[37407] = {tj,"Keravnos"            ,nil,nil,{945, 40  , 81  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- kerav
 
 q[39287] = {tj,nil,nil,nil,{945, 22.6, 39.8},nil,nil,mobs_icon_d,nil,isquestcompleted} -- deathtalon
 q[39288] = {tj,nil,nil,nil,{945, 15.4, 63.6},nil,nil,mobs_icon_d,nil,isquestcompleted} -- terrorfist
 q[39290] = {tj,nil,nil,nil,{945, 32.5, 74  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- vengeance
 q[39289] = {tj,nil,nil,nil,{945, 47.3, 52.4},nil,nil,mobs_icon_d,nil,isquestcompleted} -- doomroller
 
-- Assault on the Temple of Sha'naar
 q[38026] = {tj,nil,nil,nil,{945, 31  , 73  },nil,nil,mobs_icon_d,nil,isquestcompleted} --imp master
 q[38029] = {tj,nil,nil,nil,{945, 32.5, 74  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- lady oran
 q[38030] = {tj,nil,nil,nil,{945, 29.6, 70.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- jax
 q[38031] = {tj,nil,nil,nil,{945, 31.4, 68  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- cerax
 q[38032] = {tj,nil,nil,nil,{945, 29.6, 70.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance"} -- mistress thavra
 
-- Assault on Ironhold Harbor
 q[37990] = {tj,nil,nil,nil,{945, 44.7, 37.7},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Kill remnants"} -- cindral
 q[37953] = {tj,nil,nil,nil,{945, 42  , 37  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127318:0:0:0:0:0:0:0:0:0:0:0:1:0|h[sergeant]|h"} -- sergeant
 q[39045] = {tj,nil,nil,nil,{945, 37  , 33  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127308:0:0:0:0:0:0:0:0:0:0:0:1:0|h[zoug]|h"}
 q[39046] = {tj,nil,nil,nil,{945, 39.6, 32.7},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127309:0:0:0:0:0:0:0:0:0:0:0:1:0|h[harbor]|h"}

-- Assault on the Ruins of Kra'nak
 q[37937] = {tj,nil,nil,nil,{945, 27.7, 32.8},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127351:0:0:0:0:0:0:0:0:0:0:0:1:0|h[varyx]|h"} -- varyx
 q[38034] = {tj,nil,nil,nil,{945, 16.8, 44.7},nil,nil,mobs_icon_d,nil,isquestcompleted} -- rasthe
 
-- Assault on the Throne of Kil'jaeden
 q[38557] = {tj,nil,nil,nil,{945, 53.6,  21.8},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Defeat mob waves"} -- painmist
 q[38579] = {tj,nil,nil,nil,{945, 60  ,  21  },nil,nil,mobs_icon_d,nil,isquestcompleted} -- xanzith
 q[38580] = {tj,nil,nil,nil,{945, 53.6,  20.6},nil,nil,mobs_icon_d,nil,isquestcompleted} -- xanzith
 q[38457] = {tj,nil,nil,nil,{945, 56.7,  24.7},nil,nil,mobs_icon_d,nil,isquestcompleted} -- xanzith
 
-- Assault on the Fel Forge
 q[38400] = {tj,nil,nil,nil,{945, 47.5, 42.3},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127299:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Nethekurse's Robe of Contempt]|h"} -- grand wa
 q[38411] = {tj,nil,nil,nil,{945, 50.1, 35.7},nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38634] = {tj,nil,nil,nil,{945, 45.8, 47  },nil,nil,mobs_icon_d,nil,isquestcompleted}
 
-- Battle At The Iron Front
 q[38746] = {tj,nil,nil,nil,{945, 15  , 54  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127319:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Krag'goth's Iron Gauntlets]|h"} -- commander krag
 q[38747] = {tj,nil,nil,nil,{945, 13.3, 57.1},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127310:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Sabatons of Radiating Ire]|h"} -- tho'gar
 q[38750] = {tj,nil,nil,nil,{945, 16  , 60  },nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38752] = {tj,nil,nil,nil,{945, 16.1, 57.4},nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38751] = {tj,nil,nil,nil,{945, 13.3, 57.1},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127321:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Iron Houndmaster's Pauldrons]|h"}
 
-- Bleeding the Bleeding Hollow
 q[38262] = {tj,nil,nil,nil,{945, 23.8, 51.9},nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38263] = {tj,nil,nil,nil,{945, 20.4, 49.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127314:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Rogond's Tracking Shoulderguards]|h"}
 q[38265] = {tj,nil,nil,nil,{945, 23  , 50  },nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38264] = {tj,nil,nil,nil,{945, 25.1, 46.6},nil,nil,mobs_icon_d,nil,isquestcompleted}
 q[38266] = {tj,nil,nil,nil,{945, 24  , 50  },nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127303:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Zulk's Sneaky Slippers]|h"}
 q[38496] = {tj,nil,nil,nil,{945, 26.4, 54.4},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"|Hitem:127335:0:0:0:0:0:0:0:0:0:0:0:1:0|h[Relgor's Master Glaive]|h"}
 q[38736] = {tj,nil,nil,nil,{945, 19.8, 53.6},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"On top of the tower"}
 q[38756] = {tj,nil,nil,nil,{945, 37.2, 75.9},nil,nil,mobs_icon_d,nil,isquestcompleted,nil,nil,"Cave entrance coordinates"}

 setup_tanaan_localization_and_icons()
end

local function Initialize()
-- order localization
 list.Order[8][2][1] = l(list.Order[8][2], nil, 1, "Assault on the Temple of Sha'naar", "quest", 38020)
 list.Order[8][3][1] = l(list.Order[8][3], nil, 1, "Assault on Ironhold Harbor", "quest", 37891)
 list.Order[8][4][1] = l(list.Order[8][4], nil, 1, "Assault on the Ruins of Kra'nak", "quest", 38252)
 list.Order[8][5][1] = l(list.Order[8][5], nil, 1, "Assault on the Throne of Kil'jaeden", "quest", 38585)
 list.Order[8][6][1] = l(list.Order[8][6], nil, 1, "Assault on the Fel Forge", "quest", 38441)
 list.Order[8][7][1] = l(list.Order[8][7], nil, 1, "Battle at The Iron Front", "quest", 38046)
 list.Order[8][8][1] = l(list.Order[8][7], nil, 1, "Bleeding the Bleeding Hollow", "quest", 38044)

 onOptionChanged(1)
 DGCEventFrame:Hook("OPTION_CHANGED_PLUGIN", onOptionChanged)
end

list.Initialize = Initialize
list.GenerateData = GenerateData
DailyGlobalCheck:LoadPlugin(list, questsdata)