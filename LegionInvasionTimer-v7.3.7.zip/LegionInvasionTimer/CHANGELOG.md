# LegionInvasionTimer

## [v7.3.7](https://github.com/funkydude/LegionInvasionTimer/tree/v7.3.7) (2018-05-17)
[Full Changelog](https://github.com/funkydude/LegionInvasionTimer/compare/v7.3.6...v7.3.7)

- Another BfA fix.  
